﻿namespace QuanLiThuVienUeh.admin
{
    partial class ffc_XemThongTinDocGiaChiTiet
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ffc_XemThongTinDocGiaChiTiet));
            this.label_NgaySinhInfo = new System.Windows.Forms.Label();
            this.label_NgaySinh = new System.Windows.Forms.Label();
            this.label_ChuyenNganhInfo = new System.Windows.Forms.Label();
            this.label_SoDienThoaiInfo = new System.Windows.Forms.Label();
            this.label_EmailInfo = new System.Windows.Forms.Label();
            this.label_LopInfo = new System.Windows.Forms.Label();
            this.label_GioiTinhInfo = new System.Windows.Forms.Label();
            this.label_IDInfo = new System.Windows.Forms.Label();
            this.label_ChuyenNganh = new System.Windows.Forms.Label();
            this.label_SoDienThoai = new System.Windows.Forms.Label();
            this.label_Email = new System.Windows.Forms.Label();
            this.label_Lop = new System.Windows.Forms.Label();
            this.label_GioiTinh = new System.Windows.Forms.Label();
            this.label_ID = new System.Windows.Forms.Label();
            this.label_NhanVienName = new System.Windows.Forms.Label();
            this.textBox_GioiThieu = new System.Windows.Forms.TextBox();
            this.pictureBox_UehLogoIcon = new System.Windows.Forms.PictureBox();
            this.guna2CirclePictureBox_Avatar = new Guna.UI2.WinForms.Guna2CirclePictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_UehLogoIcon)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.guna2CirclePictureBox_Avatar)).BeginInit();
            this.SuspendLayout();
            // 
            // label_NgaySinhInfo
            // 
            this.label_NgaySinhInfo.AutoSize = true;
            this.label_NgaySinhInfo.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label_NgaySinhInfo.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_NgaySinhInfo.ForeColor = System.Drawing.Color.Black;
            this.label_NgaySinhInfo.Location = new System.Drawing.Point(628, 375);
            this.label_NgaySinhInfo.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_NgaySinhInfo.Name = "label_NgaySinhInfo";
            this.label_NgaySinhInfo.Size = new System.Drawing.Size(29, 32);
            this.label_NgaySinhInfo.TabIndex = 41;
            this.label_NgaySinhInfo.Text = "...";
            // 
            // label_NgaySinh
            // 
            this.label_NgaySinh.AutoSize = true;
            this.label_NgaySinh.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label_NgaySinh.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_NgaySinh.ForeColor = System.Drawing.Color.Black;
            this.label_NgaySinh.Location = new System.Drawing.Point(376, 375);
            this.label_NgaySinh.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_NgaySinh.Name = "label_NgaySinh";
            this.label_NgaySinh.Size = new System.Drawing.Size(126, 32);
            this.label_NgaySinh.TabIndex = 40;
            this.label_NgaySinh.Text = "Ngày sinh:";
            // 
            // label_ChuyenNganhInfo
            // 
            this.label_ChuyenNganhInfo.AutoSize = true;
            this.label_ChuyenNganhInfo.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label_ChuyenNganhInfo.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_ChuyenNganhInfo.ForeColor = System.Drawing.Color.Black;
            this.label_ChuyenNganhInfo.Location = new System.Drawing.Point(628, 480);
            this.label_ChuyenNganhInfo.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_ChuyenNganhInfo.Name = "label_ChuyenNganhInfo";
            this.label_ChuyenNganhInfo.Size = new System.Drawing.Size(29, 32);
            this.label_ChuyenNganhInfo.TabIndex = 39;
            this.label_ChuyenNganhInfo.Text = "...";
            // 
            // label_SoDienThoaiInfo
            // 
            this.label_SoDienThoaiInfo.AutoSize = true;
            this.label_SoDienThoaiInfo.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label_SoDienThoaiInfo.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_SoDienThoaiInfo.ForeColor = System.Drawing.Color.Black;
            this.label_SoDienThoaiInfo.Location = new System.Drawing.Point(628, 583);
            this.label_SoDienThoaiInfo.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_SoDienThoaiInfo.Name = "label_SoDienThoaiInfo";
            this.label_SoDienThoaiInfo.Size = new System.Drawing.Size(29, 32);
            this.label_SoDienThoaiInfo.TabIndex = 38;
            this.label_SoDienThoaiInfo.Text = "...";
            // 
            // label_EmailInfo
            // 
            this.label_EmailInfo.AutoSize = true;
            this.label_EmailInfo.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label_EmailInfo.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_EmailInfo.ForeColor = System.Drawing.Color.Black;
            this.label_EmailInfo.Location = new System.Drawing.Point(628, 533);
            this.label_EmailInfo.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_EmailInfo.Name = "label_EmailInfo";
            this.label_EmailInfo.Size = new System.Drawing.Size(29, 32);
            this.label_EmailInfo.TabIndex = 37;
            this.label_EmailInfo.Text = "...";
            // 
            // label_LopInfo
            // 
            this.label_LopInfo.AutoSize = true;
            this.label_LopInfo.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label_LopInfo.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_LopInfo.ForeColor = System.Drawing.Color.Black;
            this.label_LopInfo.Location = new System.Drawing.Point(628, 430);
            this.label_LopInfo.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_LopInfo.Name = "label_LopInfo";
            this.label_LopInfo.Size = new System.Drawing.Size(29, 32);
            this.label_LopInfo.TabIndex = 36;
            this.label_LopInfo.Text = "...";
            // 
            // label_GioiTinhInfo
            // 
            this.label_GioiTinhInfo.AutoSize = true;
            this.label_GioiTinhInfo.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label_GioiTinhInfo.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_GioiTinhInfo.ForeColor = System.Drawing.Color.Black;
            this.label_GioiTinhInfo.Location = new System.Drawing.Point(628, 324);
            this.label_GioiTinhInfo.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_GioiTinhInfo.Name = "label_GioiTinhInfo";
            this.label_GioiTinhInfo.Size = new System.Drawing.Size(29, 32);
            this.label_GioiTinhInfo.TabIndex = 35;
            this.label_GioiTinhInfo.Text = "...";
            // 
            // label_IDInfo
            // 
            this.label_IDInfo.AutoSize = true;
            this.label_IDInfo.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label_IDInfo.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_IDInfo.ForeColor = System.Drawing.Color.Black;
            this.label_IDInfo.Location = new System.Drawing.Point(628, 277);
            this.label_IDInfo.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_IDInfo.Name = "label_IDInfo";
            this.label_IDInfo.Size = new System.Drawing.Size(29, 32);
            this.label_IDInfo.TabIndex = 33;
            this.label_IDInfo.Text = "...";
            // 
            // label_ChuyenNganh
            // 
            this.label_ChuyenNganh.AutoSize = true;
            this.label_ChuyenNganh.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label_ChuyenNganh.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_ChuyenNganh.ForeColor = System.Drawing.Color.Black;
            this.label_ChuyenNganh.Location = new System.Drawing.Point(376, 480);
            this.label_ChuyenNganh.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_ChuyenNganh.Name = "label_ChuyenNganh";
            this.label_ChuyenNganh.Size = new System.Drawing.Size(176, 32);
            this.label_ChuyenNganh.TabIndex = 32;
            this.label_ChuyenNganh.Text = "Chuyên ngành:";
            // 
            // label_SoDienThoai
            // 
            this.label_SoDienThoai.AutoSize = true;
            this.label_SoDienThoai.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label_SoDienThoai.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_SoDienThoai.ForeColor = System.Drawing.Color.Black;
            this.label_SoDienThoai.Location = new System.Drawing.Point(376, 583);
            this.label_SoDienThoai.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_SoDienThoai.Name = "label_SoDienThoai";
            this.label_SoDienThoai.Size = new System.Drawing.Size(161, 32);
            this.label_SoDienThoai.TabIndex = 31;
            this.label_SoDienThoai.Text = "Số điện thoại:";
            // 
            // label_Email
            // 
            this.label_Email.AutoSize = true;
            this.label_Email.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label_Email.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_Email.ForeColor = System.Drawing.Color.Black;
            this.label_Email.Location = new System.Drawing.Point(376, 533);
            this.label_Email.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_Email.Name = "label_Email";
            this.label_Email.Size = new System.Drawing.Size(76, 32);
            this.label_Email.TabIndex = 30;
            this.label_Email.Text = "Email:";
            // 
            // label_Lop
            // 
            this.label_Lop.AutoSize = true;
            this.label_Lop.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label_Lop.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_Lop.ForeColor = System.Drawing.Color.Black;
            this.label_Lop.Location = new System.Drawing.Point(376, 430);
            this.label_Lop.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_Lop.Name = "label_Lop";
            this.label_Lop.Size = new System.Drawing.Size(58, 32);
            this.label_Lop.TabIndex = 29;
            this.label_Lop.Text = "Lớp:";
            // 
            // label_GioiTinh
            // 
            this.label_GioiTinh.AutoSize = true;
            this.label_GioiTinh.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label_GioiTinh.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_GioiTinh.ForeColor = System.Drawing.Color.Black;
            this.label_GioiTinh.Location = new System.Drawing.Point(376, 324);
            this.label_GioiTinh.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_GioiTinh.Name = "label_GioiTinh";
            this.label_GioiTinh.Size = new System.Drawing.Size(110, 32);
            this.label_GioiTinh.TabIndex = 28;
            this.label_GioiTinh.Text = "Giới tính:";
            // 
            // label_ID
            // 
            this.label_ID.AutoSize = true;
            this.label_ID.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label_ID.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_ID.ForeColor = System.Drawing.Color.Black;
            this.label_ID.Location = new System.Drawing.Point(376, 277);
            this.label_ID.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_ID.Name = "label_ID";
            this.label_ID.Size = new System.Drawing.Size(42, 32);
            this.label_ID.TabIndex = 26;
            this.label_ID.Text = "ID:";
            // 
            // label_NhanVienName
            // 
            this.label_NhanVienName.AutoSize = true;
            this.label_NhanVienName.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label_NhanVienName.Font = new System.Drawing.Font("Segoe UI Semibold", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_NhanVienName.ForeColor = System.Drawing.Color.MediumBlue;
            this.label_NhanVienName.Location = new System.Drawing.Point(376, 106);
            this.label_NhanVienName.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_NhanVienName.Name = "label_NhanVienName";
            this.label_NhanVienName.Size = new System.Drawing.Size(161, 32);
            this.label_NhanVienName.TabIndex = 25;
            this.label_NhanVienName.Text = "Đào Gia Phúc";
            this.label_NhanVienName.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // textBox_GioiThieu
            // 
            this.textBox_GioiThieu.BackColor = System.Drawing.Color.White;
            this.textBox_GioiThieu.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox_GioiThieu.Enabled = false;
            this.textBox_GioiThieu.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox_GioiThieu.ForeColor = System.Drawing.Color.Black;
            this.textBox_GioiThieu.Location = new System.Drawing.Point(379, 153);
            this.textBox_GioiThieu.Margin = new System.Windows.Forms.Padding(4);
            this.textBox_GioiThieu.Multiline = true;
            this.textBox_GioiThieu.Name = "textBox_GioiThieu";
            this.textBox_GioiThieu.Size = new System.Drawing.Size(499, 121);
            this.textBox_GioiThieu.TabIndex = 24;
            this.textBox_GioiThieu.Text = "...";
            // 
            // pictureBox_UehLogoIcon
            // 
            this.pictureBox_UehLogoIcon.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox_UehLogoIcon.Image")));
            this.pictureBox_UehLogoIcon.Location = new System.Drawing.Point(71, 25);
            this.pictureBox_UehLogoIcon.Margin = new System.Windows.Forms.Padding(4);
            this.pictureBox_UehLogoIcon.Name = "pictureBox_UehLogoIcon";
            this.pictureBox_UehLogoIcon.Size = new System.Drawing.Size(88, 58);
            this.pictureBox_UehLogoIcon.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox_UehLogoIcon.TabIndex = 23;
            this.pictureBox_UehLogoIcon.TabStop = false;
            // 
            // guna2CirclePictureBox_Avatar
            // 
            this.guna2CirclePictureBox_Avatar.ImageRotate = 0F;
            this.guna2CirclePictureBox_Avatar.Location = new System.Drawing.Point(71, 106);
            this.guna2CirclePictureBox_Avatar.Margin = new System.Windows.Forms.Padding(4);
            this.guna2CirclePictureBox_Avatar.Name = "guna2CirclePictureBox_Avatar";
            this.guna2CirclePictureBox_Avatar.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle;
            this.guna2CirclePictureBox_Avatar.Size = new System.Drawing.Size(233, 215);
            this.guna2CirclePictureBox_Avatar.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.guna2CirclePictureBox_Avatar.TabIndex = 45;
            this.guna2CirclePictureBox_Avatar.TabStop = false;
            // 
            // ffc_XemThongTinDocGiaChiTiet
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1064, 667);
            this.Controls.Add(this.guna2CirclePictureBox_Avatar);
            this.Controls.Add(this.label_NgaySinhInfo);
            this.Controls.Add(this.label_NgaySinh);
            this.Controls.Add(this.label_ChuyenNganhInfo);
            this.Controls.Add(this.label_SoDienThoaiInfo);
            this.Controls.Add(this.label_EmailInfo);
            this.Controls.Add(this.label_LopInfo);
            this.Controls.Add(this.label_GioiTinhInfo);
            this.Controls.Add(this.label_IDInfo);
            this.Controls.Add(this.label_ChuyenNganh);
            this.Controls.Add(this.label_SoDienThoai);
            this.Controls.Add(this.label_Email);
            this.Controls.Add(this.label_Lop);
            this.Controls.Add(this.label_GioiTinh);
            this.Controls.Add(this.label_ID);
            this.Controls.Add(this.label_NhanVienName);
            this.Controls.Add(this.textBox_GioiThieu);
            this.Controls.Add(this.pictureBox_UehLogoIcon);
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "ffc_XemThongTinDocGiaChiTiet";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form_ThongTinDocGiaChiTiet";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_UehLogoIcon)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.guna2CirclePictureBox_Avatar)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label_NgaySinhInfo;
        private System.Windows.Forms.Label label_NgaySinh;
        private System.Windows.Forms.Label label_ChuyenNganhInfo;
        private System.Windows.Forms.Label label_SoDienThoaiInfo;
        private System.Windows.Forms.Label label_EmailInfo;
        private System.Windows.Forms.Label label_LopInfo;
        private System.Windows.Forms.Label label_GioiTinhInfo;
        private System.Windows.Forms.Label label_IDInfo;
        private System.Windows.Forms.Label label_ChuyenNganh;
        private System.Windows.Forms.Label label_SoDienThoai;
        private System.Windows.Forms.Label label_Email;
        private System.Windows.Forms.Label label_Lop;
        private System.Windows.Forms.Label label_GioiTinh;
        private System.Windows.Forms.Label label_ID;
        private System.Windows.Forms.Label label_NhanVienName;
        private System.Windows.Forms.TextBox textBox_GioiThieu;
        private System.Windows.Forms.PictureBox pictureBox_UehLogoIcon;
        private Guna.UI2.WinForms.Guna2CirclePictureBox guna2CirclePictureBox_Avatar;
    }
}