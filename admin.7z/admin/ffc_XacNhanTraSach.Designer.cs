﻿namespace QuanLiThuVienUeh.admin
{
    partial class ffc_XacNhanTraSach
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.button_SaveInsert = new System.Windows.Forms.Button();
            this.label_NgayTraSach = new System.Windows.Forms.Label();
            this.label_IDSach = new System.Windows.Forms.Label();
            this.textBox_IDSach = new System.Windows.Forms.TextBox();
            this.panel_IDSach = new System.Windows.Forms.Panel();
            this.label_IDMuonTra = new System.Windows.Forms.Label();
            this.textBox_IDMuonTra = new System.Windows.Forms.TextBox();
            this.button_ResetInsert = new System.Windows.Forms.Button();
            this.panel_IDMuonTra = new System.Windows.Forms.Panel();
            this.panel_IDNguoiDung = new System.Windows.Forms.Panel();
            this.textBox_IDNguoiDung = new System.Windows.Forms.TextBox();
            this.label_IDNguoiDung = new System.Windows.Forms.Label();
            this.label_XacNhanTraSach = new System.Windows.Forms.Label();
            this.panel_NgayTraSach = new System.Windows.Forms.Panel();
            this.dateTimePicker_NgayTraSach = new System.Windows.Forms.DateTimePicker();
            this.panel_HoTen = new System.Windows.Forms.Panel();
            this.textBox_HoTen = new System.Windows.Forms.TextBox();
            this.label_HoTen = new System.Windows.Forms.Label();
            this.label_TenSach = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.textBox_TenSach = new System.Windows.Forms.TextBox();
            this.panel_IDSach.SuspendLayout();
            this.panel_IDMuonTra.SuspendLayout();
            this.panel_IDNguoiDung.SuspendLayout();
            this.panel_NgayTraSach.SuspendLayout();
            this.panel_HoTen.SuspendLayout();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // button_SaveInsert
            // 
            this.button_SaveInsert.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(111)))), ((int)(((byte)(51)))));
            this.button_SaveInsert.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button_SaveInsert.FlatAppearance.BorderSize = 0;
            this.button_SaveInsert.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_SaveInsert.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_SaveInsert.ForeColor = System.Drawing.Color.White;
            this.button_SaveInsert.Location = new System.Drawing.Point(1099, 233);
            this.button_SaveInsert.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.button_SaveInsert.Name = "button_SaveInsert";
            this.button_SaveInsert.Size = new System.Drawing.Size(128, 59);
            this.button_SaveInsert.TabIndex = 48;
            this.button_SaveInsert.Text = "Save";
            this.button_SaveInsert.UseVisualStyleBackColor = false;
            this.button_SaveInsert.Click += new System.EventHandler(this.button_SaveInsert_Click);
            // 
            // label_NgayTraSach
            // 
            this.label_NgayTraSach.AutoSize = true;
            this.label_NgayTraSach.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label_NgayTraSach.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_NgayTraSach.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label_NgayTraSach.Location = new System.Drawing.Point(1092, 79);
            this.label_NgayTraSach.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_NgayTraSach.Name = "label_NgayTraSach";
            this.label_NgayTraSach.Size = new System.Drawing.Size(176, 32);
            this.label_NgayTraSach.TabIndex = 42;
            this.label_NgayTraSach.Text = "Ngày trả sách *";
            // 
            // label_IDSach
            // 
            this.label_IDSach.AutoSize = true;
            this.label_IDSach.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label_IDSach.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_IDSach.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label_IDSach.Location = new System.Drawing.Point(700, 79);
            this.label_IDSach.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_IDSach.Name = "label_IDSach";
            this.label_IDSach.Size = new System.Drawing.Size(111, 32);
            this.label_IDSach.TabIndex = 46;
            this.label_IDSach.Text = "ID Sách *";
            // 
            // textBox_IDSach
            // 
            this.textBox_IDSach.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(221)))), ((int)(((byte)(222)))), ((int)(((byte)(238)))));
            this.textBox_IDSach.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox_IDSach.Enabled = false;
            this.textBox_IDSach.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox_IDSach.Location = new System.Drawing.Point(3, 11);
            this.textBox_IDSach.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.textBox_IDSach.Name = "textBox_IDSach";
            this.textBox_IDSach.Size = new System.Drawing.Size(171, 32);
            this.textBox_IDSach.TabIndex = 2;
            // 
            // panel_IDSach
            // 
            this.panel_IDSach.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(221)))), ((int)(((byte)(222)))), ((int)(((byte)(238)))));
            this.panel_IDSach.Controls.Add(this.textBox_IDSach);
            this.panel_IDSach.ForeColor = System.Drawing.SystemColors.Control;
            this.panel_IDSach.Location = new System.Drawing.Point(707, 119);
            this.panel_IDSach.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.panel_IDSach.Name = "panel_IDSach";
            this.panel_IDSach.Size = new System.Drawing.Size(177, 55);
            this.panel_IDSach.TabIndex = 47;
            // 
            // label_IDMuonTra
            // 
            this.label_IDMuonTra.AutoSize = true;
            this.label_IDMuonTra.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label_IDMuonTra.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_IDMuonTra.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label_IDMuonTra.Location = new System.Drawing.Point(31, 79);
            this.label_IDMuonTra.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_IDMuonTra.Name = "label_IDMuonTra";
            this.label_IDMuonTra.Size = new System.Drawing.Size(153, 32);
            this.label_IDMuonTra.TabIndex = 43;
            this.label_IDMuonTra.Text = "ID Mượn trả*";
            // 
            // textBox_IDMuonTra
            // 
            this.textBox_IDMuonTra.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(221)))), ((int)(((byte)(222)))), ((int)(((byte)(238)))));
            this.textBox_IDMuonTra.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox_IDMuonTra.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox_IDMuonTra.Location = new System.Drawing.Point(3, 11);
            this.textBox_IDMuonTra.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.textBox_IDMuonTra.Name = "textBox_IDMuonTra";
            this.textBox_IDMuonTra.Size = new System.Drawing.Size(171, 32);
            this.textBox_IDMuonTra.TabIndex = 2;
            this.textBox_IDMuonTra.TextChanged += new System.EventHandler(this.textBox_IDMuonTra_TextChanged);
            // 
            // button_ResetInsert
            // 
            this.button_ResetInsert.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(95)))), ((int)(((byte)(105)))));
            this.button_ResetInsert.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button_ResetInsert.FlatAppearance.BorderSize = 0;
            this.button_ResetInsert.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_ResetInsert.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_ResetInsert.ForeColor = System.Drawing.Color.White;
            this.button_ResetInsert.Location = new System.Drawing.Point(1235, 231);
            this.button_ResetInsert.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.button_ResetInsert.Name = "button_ResetInsert";
            this.button_ResetInsert.Size = new System.Drawing.Size(128, 59);
            this.button_ResetInsert.TabIndex = 49;
            this.button_ResetInsert.Text = "Reset";
            this.button_ResetInsert.UseVisualStyleBackColor = false;
            this.button_ResetInsert.Click += new System.EventHandler(this.button_ResetInsert_Click);
            // 
            // panel_IDMuonTra
            // 
            this.panel_IDMuonTra.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(221)))), ((int)(((byte)(222)))), ((int)(((byte)(238)))));
            this.panel_IDMuonTra.Controls.Add(this.textBox_IDMuonTra);
            this.panel_IDMuonTra.ForeColor = System.Drawing.SystemColors.Control;
            this.panel_IDMuonTra.Location = new System.Drawing.Point(36, 119);
            this.panel_IDMuonTra.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.panel_IDMuonTra.Name = "panel_IDMuonTra";
            this.panel_IDMuonTra.Size = new System.Drawing.Size(177, 55);
            this.panel_IDMuonTra.TabIndex = 45;
            // 
            // panel_IDNguoiDung
            // 
            this.panel_IDNguoiDung.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(221)))), ((int)(((byte)(222)))), ((int)(((byte)(238)))));
            this.panel_IDNguoiDung.Controls.Add(this.textBox_IDNguoiDung);
            this.panel_IDNguoiDung.ForeColor = System.Drawing.SystemColors.Control;
            this.panel_IDNguoiDung.Location = new System.Drawing.Point(305, 119);
            this.panel_IDNguoiDung.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.panel_IDNguoiDung.Name = "panel_IDNguoiDung";
            this.panel_IDNguoiDung.Size = new System.Drawing.Size(237, 55);
            this.panel_IDNguoiDung.TabIndex = 41;
            // 
            // textBox_IDNguoiDung
            // 
            this.textBox_IDNguoiDung.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(221)))), ((int)(((byte)(222)))), ((int)(((byte)(238)))));
            this.textBox_IDNguoiDung.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox_IDNguoiDung.Enabled = false;
            this.textBox_IDNguoiDung.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox_IDNguoiDung.Location = new System.Drawing.Point(3, 11);
            this.textBox_IDNguoiDung.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.textBox_IDNguoiDung.Name = "textBox_IDNguoiDung";
            this.textBox_IDNguoiDung.Size = new System.Drawing.Size(231, 32);
            this.textBox_IDNguoiDung.TabIndex = 2;
            // 
            // label_IDNguoiDung
            // 
            this.label_IDNguoiDung.AutoSize = true;
            this.label_IDNguoiDung.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label_IDNguoiDung.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_IDNguoiDung.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label_IDNguoiDung.Location = new System.Drawing.Point(300, 79);
            this.label_IDNguoiDung.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_IDNguoiDung.Name = "label_IDNguoiDung";
            this.label_IDNguoiDung.Size = new System.Drawing.Size(94, 32);
            this.label_IDNguoiDung.TabIndex = 40;
            this.label_IDNguoiDung.Text = "MSSV *";
            // 
            // label_XacNhanTraSach
            // 
            this.label_XacNhanTraSach.AutoSize = true;
            this.label_XacNhanTraSach.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label_XacNhanTraSach.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_XacNhanTraSach.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(95)))), ((int)(((byte)(105)))));
            this.label_XacNhanTraSach.Location = new System.Drawing.Point(29, 20);
            this.label_XacNhanTraSach.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_XacNhanTraSach.Name = "label_XacNhanTraSach";
            this.label_XacNhanTraSach.Size = new System.Drawing.Size(215, 32);
            this.label_XacNhanTraSach.TabIndex = 38;
            this.label_XacNhanTraSach.Text = "Xác nhận trả sách";
            // 
            // panel_NgayTraSach
            // 
            this.panel_NgayTraSach.BackColor = System.Drawing.Color.White;
            this.panel_NgayTraSach.Controls.Add(this.dateTimePicker_NgayTraSach);
            this.panel_NgayTraSach.ForeColor = System.Drawing.SystemColors.Control;
            this.panel_NgayTraSach.Location = new System.Drawing.Point(1099, 119);
            this.panel_NgayTraSach.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.panel_NgayTraSach.Name = "panel_NgayTraSach";
            this.panel_NgayTraSach.Size = new System.Drawing.Size(308, 55);
            this.panel_NgayTraSach.TabIndex = 50;
            // 
            // dateTimePicker_NgayTraSach
            // 
            this.dateTimePicker_NgayTraSach.CalendarForeColor = System.Drawing.Color.White;
            this.dateTimePicker_NgayTraSach.CalendarTitleBackColor = System.Drawing.Color.White;
            this.dateTimePicker_NgayTraSach.CustomFormat = "dd/MM/yyyy";
            this.dateTimePicker_NgayTraSach.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dateTimePicker_NgayTraSach.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dateTimePicker_NgayTraSach.Location = new System.Drawing.Point(1, 7);
            this.dateTimePicker_NgayTraSach.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.dateTimePicker_NgayTraSach.Name = "dateTimePicker_NgayTraSach";
            this.dateTimePicker_NgayTraSach.Size = new System.Drawing.Size(305, 39);
            this.dateTimePicker_NgayTraSach.TabIndex = 3;
            this.dateTimePicker_NgayTraSach.Value = new System.DateTime(2024, 3, 8, 0, 0, 0, 0);
            // 
            // panel_HoTen
            // 
            this.panel_HoTen.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(221)))), ((int)(((byte)(222)))), ((int)(((byte)(238)))));
            this.panel_HoTen.Controls.Add(this.textBox_HoTen);
            this.panel_HoTen.ForeColor = System.Drawing.SystemColors.Control;
            this.panel_HoTen.Location = new System.Drawing.Point(305, 236);
            this.panel_HoTen.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.panel_HoTen.Name = "panel_HoTen";
            this.panel_HoTen.Size = new System.Drawing.Size(347, 55);
            this.panel_HoTen.TabIndex = 43;
            // 
            // textBox_HoTen
            // 
            this.textBox_HoTen.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(221)))), ((int)(((byte)(222)))), ((int)(((byte)(238)))));
            this.textBox_HoTen.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox_HoTen.Enabled = false;
            this.textBox_HoTen.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox_HoTen.Location = new System.Drawing.Point(3, 11);
            this.textBox_HoTen.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.textBox_HoTen.Name = "textBox_HoTen";
            this.textBox_HoTen.Size = new System.Drawing.Size(340, 32);
            this.textBox_HoTen.TabIndex = 2;
            // 
            // label_HoTen
            // 
            this.label_HoTen.AutoSize = true;
            this.label_HoTen.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label_HoTen.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_HoTen.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label_HoTen.Location = new System.Drawing.Point(300, 196);
            this.label_HoTen.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_HoTen.Name = "label_HoTen";
            this.label_HoTen.Size = new System.Drawing.Size(135, 32);
            this.label_HoTen.TabIndex = 42;
            this.label_HoTen.Text = "Họ và tên *";
            // 
            // label_TenSach
            // 
            this.label_TenSach.AutoSize = true;
            this.label_TenSach.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label_TenSach.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_TenSach.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label_TenSach.Location = new System.Drawing.Point(700, 196);
            this.label_TenSach.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_TenSach.Name = "label_TenSach";
            this.label_TenSach.Size = new System.Drawing.Size(123, 32);
            this.label_TenSach.TabIndex = 51;
            this.label_TenSach.Text = "Tên sách *";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(221)))), ((int)(((byte)(222)))), ((int)(((byte)(238)))));
            this.panel1.Controls.Add(this.textBox_TenSach);
            this.panel1.ForeColor = System.Drawing.SystemColors.Control;
            this.panel1.Location = new System.Drawing.Point(707, 236);
            this.panel1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(327, 55);
            this.panel1.TabIndex = 52;
            // 
            // textBox_TenSach
            // 
            this.textBox_TenSach.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(221)))), ((int)(((byte)(222)))), ((int)(((byte)(238)))));
            this.textBox_TenSach.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox_TenSach.Enabled = false;
            this.textBox_TenSach.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox_TenSach.Location = new System.Drawing.Point(3, 11);
            this.textBox_TenSach.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.textBox_TenSach.Name = "textBox_TenSach";
            this.textBox_TenSach.Size = new System.Drawing.Size(320, 32);
            this.textBox_TenSach.TabIndex = 2;
            // 
            // ffc_XacNhanTraSach
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1423, 306);
            this.Controls.Add(this.label_TenSach);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.panel_HoTen);
            this.Controls.Add(this.label_HoTen);
            this.Controls.Add(this.panel_NgayTraSach);
            this.Controls.Add(this.button_SaveInsert);
            this.Controls.Add(this.label_NgayTraSach);
            this.Controls.Add(this.label_IDSach);
            this.Controls.Add(this.panel_IDSach);
            this.Controls.Add(this.label_IDMuonTra);
            this.Controls.Add(this.button_ResetInsert);
            this.Controls.Add(this.panel_IDMuonTra);
            this.Controls.Add(this.panel_IDNguoiDung);
            this.Controls.Add(this.label_IDNguoiDung);
            this.Controls.Add(this.label_XacNhanTraSach);
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Name = "ffc_XacNhanTraSach";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "XacNhanTraSach";
            this.panel_IDSach.ResumeLayout(false);
            this.panel_IDSach.PerformLayout();
            this.panel_IDMuonTra.ResumeLayout(false);
            this.panel_IDMuonTra.PerformLayout();
            this.panel_IDNguoiDung.ResumeLayout(false);
            this.panel_IDNguoiDung.PerformLayout();
            this.panel_NgayTraSach.ResumeLayout(false);
            this.panel_HoTen.ResumeLayout(false);
            this.panel_HoTen.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button button_SaveInsert;
        private System.Windows.Forms.Label label_NgayTraSach;
        private System.Windows.Forms.Label label_IDSach;
        private System.Windows.Forms.TextBox textBox_IDSach;
        private System.Windows.Forms.Panel panel_IDSach;
        private System.Windows.Forms.Label label_IDMuonTra;
        private System.Windows.Forms.TextBox textBox_IDMuonTra;
        private System.Windows.Forms.Button button_ResetInsert;
        private System.Windows.Forms.Panel panel_IDMuonTra;
        private System.Windows.Forms.Panel panel_IDNguoiDung;
        private System.Windows.Forms.TextBox textBox_IDNguoiDung;
        private System.Windows.Forms.Label label_IDNguoiDung;
        private System.Windows.Forms.Label label_XacNhanTraSach;
        private System.Windows.Forms.Panel panel_NgayTraSach;
        private System.Windows.Forms.DateTimePicker dateTimePicker_NgayTraSach;
        private System.Windows.Forms.Panel panel_HoTen;
        private System.Windows.Forms.TextBox textBox_HoTen;
        private System.Windows.Forms.Label label_HoTen;
        private System.Windows.Forms.Label label_TenSach;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.TextBox textBox_TenSach;
    }
}