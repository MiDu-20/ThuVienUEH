﻿namespace QuanLiThuVienUeh.admin
{
    partial class ffc_ThemXoaNhanVien
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel_ThemNhanVienFunction = new System.Windows.Forms.Panel();
            this.guna2CirclePictureBox_Avatar = new Guna.UI2.WinForms.Guna2CirclePictureBox();
            this.button_ResetInsert = new System.Windows.Forms.Button();
            this.button_SaveInsert = new System.Windows.Forms.Button();
            this.label_Upload = new System.Windows.Forms.Label();
            this.button_Upload = new System.Windows.Forms.Button();
            this.panel_GioiThieuInput = new System.Windows.Forms.Panel();
            this.textBox_GioiThieuInput = new System.Windows.Forms.TextBox();
            this.label_GioiThieu = new System.Windows.Forms.Label();
            this.panel_NgayNhanViecInput = new System.Windows.Forms.Panel();
            this.dateTimePicker_NgayNhanViecInput = new System.Windows.Forms.DateTimePicker();
            this.panel_SoDienThoaiInput = new System.Windows.Forms.Panel();
            this.textBox_SoDienThoaiInput = new System.Windows.Forms.TextBox();
            this.label_NgayNhanViec = new System.Windows.Forms.Label();
            this.label_SoDienThoai = new System.Windows.Forms.Label();
            this.panel_GioiTinhInput = new System.Windows.Forms.Panel();
            this.comboBox_GioiTinhInput = new System.Windows.Forms.ComboBox();
            this.panel_NgaySinhInput = new System.Windows.Forms.Panel();
            this.dateTimePicker_NgaySinhInput = new System.Windows.Forms.DateTimePicker();
            this.label_NgaySinh = new System.Windows.Forms.Label();
            this.label_GioiTinh = new System.Windows.Forms.Label();
            this.panel_ChucVuInput = new System.Windows.Forms.Panel();
            this.comboBox_ChucVuInput = new System.Windows.Forms.ComboBox();
            this.label_ChucVu = new System.Windows.Forms.Label();
            this.panel_HoVaTenInput = new System.Windows.Forms.Panel();
            this.textBox_HoVaTenInput = new System.Windows.Forms.TextBox();
            this.label_HoVaTen = new System.Windows.Forms.Label();
            this.label_ThemNhanVienMoi = new System.Windows.Forms.Label();
            this.panel_XoaNhanVienFunction = new System.Windows.Forms.Panel();
            this.button_ResetDelete = new System.Windows.Forms.Button();
            this.panel_IDDeleteInput = new System.Windows.Forms.Panel();
            this.textBox_IDDeleteInput = new System.Windows.Forms.TextBox();
            this.button_SaveDelete = new System.Windows.Forms.Button();
            this.label_ID = new System.Windows.Forms.Label();
            this.label_XoaNhanVien = new System.Windows.Forms.Label();
            this.openFileDialog_Avatar = new System.Windows.Forms.OpenFileDialog();
            this.panel_ThemNhanVienFunction.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.guna2CirclePictureBox_Avatar)).BeginInit();
            this.panel_GioiThieuInput.SuspendLayout();
            this.panel_NgayNhanViecInput.SuspendLayout();
            this.panel_SoDienThoaiInput.SuspendLayout();
            this.panel_GioiTinhInput.SuspendLayout();
            this.panel_NgaySinhInput.SuspendLayout();
            this.panel_ChucVuInput.SuspendLayout();
            this.panel_HoVaTenInput.SuspendLayout();
            this.panel_XoaNhanVienFunction.SuspendLayout();
            this.panel_IDDeleteInput.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel_ThemNhanVienFunction
            // 
            this.panel_ThemNhanVienFunction.BackColor = System.Drawing.Color.White;
            this.panel_ThemNhanVienFunction.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel_ThemNhanVienFunction.Controls.Add(this.guna2CirclePictureBox_Avatar);
            this.panel_ThemNhanVienFunction.Controls.Add(this.button_ResetInsert);
            this.panel_ThemNhanVienFunction.Controls.Add(this.button_SaveInsert);
            this.panel_ThemNhanVienFunction.Controls.Add(this.label_Upload);
            this.panel_ThemNhanVienFunction.Controls.Add(this.button_Upload);
            this.panel_ThemNhanVienFunction.Controls.Add(this.panel_GioiThieuInput);
            this.panel_ThemNhanVienFunction.Controls.Add(this.label_GioiThieu);
            this.panel_ThemNhanVienFunction.Controls.Add(this.panel_NgayNhanViecInput);
            this.panel_ThemNhanVienFunction.Controls.Add(this.panel_SoDienThoaiInput);
            this.panel_ThemNhanVienFunction.Controls.Add(this.label_NgayNhanViec);
            this.panel_ThemNhanVienFunction.Controls.Add(this.label_SoDienThoai);
            this.panel_ThemNhanVienFunction.Controls.Add(this.panel_GioiTinhInput);
            this.panel_ThemNhanVienFunction.Controls.Add(this.panel_NgaySinhInput);
            this.panel_ThemNhanVienFunction.Controls.Add(this.label_NgaySinh);
            this.panel_ThemNhanVienFunction.Controls.Add(this.label_GioiTinh);
            this.panel_ThemNhanVienFunction.Controls.Add(this.panel_ChucVuInput);
            this.panel_ThemNhanVienFunction.Controls.Add(this.label_ChucVu);
            this.panel_ThemNhanVienFunction.Controls.Add(this.panel_HoVaTenInput);
            this.panel_ThemNhanVienFunction.Controls.Add(this.label_HoVaTen);
            this.panel_ThemNhanVienFunction.Controls.Add(this.label_ThemNhanVienMoi);
            this.panel_ThemNhanVienFunction.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel_ThemNhanVienFunction.Location = new System.Drawing.Point(0, 0);
            this.panel_ThemNhanVienFunction.Name = "panel_ThemNhanVienFunction";
            this.panel_ThemNhanVienFunction.Size = new System.Drawing.Size(968, 458);
            this.panel_ThemNhanVienFunction.TabIndex = 0;
            // 
            // guna2CirclePictureBox_Avatar
            // 
            this.guna2CirclePictureBox_Avatar.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.guna2CirclePictureBox_Avatar.ImageRotate = 0F;
            this.guna2CirclePictureBox_Avatar.Location = new System.Drawing.Point(17, 268);
            this.guna2CirclePictureBox_Avatar.Name = "guna2CirclePictureBox_Avatar";
            this.guna2CirclePictureBox_Avatar.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle;
            this.guna2CirclePictureBox_Avatar.Size = new System.Drawing.Size(200, 175);
            this.guna2CirclePictureBox_Avatar.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.guna2CirclePictureBox_Avatar.TabIndex = 22;
            this.guna2CirclePictureBox_Avatar.TabStop = false;
            // 
            // button_ResetInsert
            // 
            this.button_ResetInsert.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(95)))), ((int)(((byte)(105)))));
            this.button_ResetInsert.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button_ResetInsert.FlatAppearance.BorderSize = 0;
            this.button_ResetInsert.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_ResetInsert.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_ResetInsert.Location = new System.Drawing.Point(845, 395);
            this.button_ResetInsert.Name = "button_ResetInsert";
            this.button_ResetInsert.Size = new System.Drawing.Size(96, 48);
            this.button_ResetInsert.TabIndex = 20;
            this.button_ResetInsert.Text = "Reset";
            this.button_ResetInsert.UseVisualStyleBackColor = false;
            this.button_ResetInsert.Click += new System.EventHandler(this.button_ResetInsert_Click);
            // 
            // button_SaveInsert
            // 
            this.button_SaveInsert.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(111)))), ((int)(((byte)(51)))));
            this.button_SaveInsert.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button_SaveInsert.FlatAppearance.BorderSize = 0;
            this.button_SaveInsert.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_SaveInsert.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_SaveInsert.Location = new System.Drawing.Point(743, 396);
            this.button_SaveInsert.Name = "button_SaveInsert";
            this.button_SaveInsert.Size = new System.Drawing.Size(96, 48);
            this.button_SaveInsert.TabIndex = 19;
            this.button_SaveInsert.Text = "Save";
            this.button_SaveInsert.UseVisualStyleBackColor = false;
            this.button_SaveInsert.Click += new System.EventHandler(this.button_SaveInsert_Click);
            // 
            // label_Upload
            // 
            this.label_Upload.AutoSize = true;
            this.label_Upload.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label_Upload.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_Upload.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label_Upload.Location = new System.Drawing.Point(237, 383);
            this.label_Upload.Name = "label_Upload";
            this.label_Upload.Size = new System.Drawing.Size(130, 25);
            this.label_Upload.TabIndex = 18;
            this.label_Upload.Text = "Upload avatar";
            // 
            // button_Upload
            // 
            this.button_Upload.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(221)))), ((int)(((byte)(222)))), ((int)(((byte)(238)))));
            this.button_Upload.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.button_Upload.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.button_Upload.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.button_Upload.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_Upload.ForeColor = System.Drawing.Color.Black;
            this.button_Upload.Location = new System.Drawing.Point(240, 410);
            this.button_Upload.Name = "button_Upload";
            this.button_Upload.Size = new System.Drawing.Size(126, 32);
            this.button_Upload.TabIndex = 17;
            this.button_Upload.Text = "Choose File";
            this.button_Upload.UseVisualStyleBackColor = false;
            this.button_Upload.Click += new System.EventHandler(this.button_Upload_Click);
            // 
            // panel_GioiThieuInput
            // 
            this.panel_GioiThieuInput.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(221)))), ((int)(((byte)(222)))), ((int)(((byte)(238)))));
            this.panel_GioiThieuInput.Controls.Add(this.textBox_GioiThieuInput);
            this.panel_GioiThieuInput.ForeColor = System.Drawing.SystemColors.Control;
            this.panel_GioiThieuInput.Location = new System.Drawing.Point(327, 186);
            this.panel_GioiThieuInput.Name = "panel_GioiThieuInput";
            this.panel_GioiThieuInput.Size = new System.Drawing.Size(304, 152);
            this.panel_GioiThieuInput.TabIndex = 15;
            // 
            // textBox_GioiThieuInput
            // 
            this.textBox_GioiThieuInput.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(221)))), ((int)(((byte)(222)))), ((int)(((byte)(238)))));
            this.textBox_GioiThieuInput.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox_GioiThieuInput.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox_GioiThieuInput.Location = new System.Drawing.Point(2, 3);
            this.textBox_GioiThieuInput.Multiline = true;
            this.textBox_GioiThieuInput.Name = "textBox_GioiThieuInput";
            this.textBox_GioiThieuInput.Size = new System.Drawing.Size(299, 146);
            this.textBox_GioiThieuInput.TabIndex = 2;
            // 
            // label_GioiThieu
            // 
            this.label_GioiThieu.AutoSize = true;
            this.label_GioiThieu.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label_GioiThieu.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_GioiThieu.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label_GioiThieu.Location = new System.Drawing.Point(323, 152);
            this.label_GioiThieu.Name = "label_GioiThieu";
            this.label_GioiThieu.Size = new System.Drawing.Size(94, 25);
            this.label_GioiThieu.TabIndex = 14;
            this.label_GioiThieu.Text = "Giới thiệu";
            // 
            // panel_NgayNhanViecInput
            // 
            this.panel_NgayNhanViecInput.BackColor = System.Drawing.Color.White;
            this.panel_NgayNhanViecInput.Controls.Add(this.dateTimePicker_NgayNhanViecInput);
            this.panel_NgayNhanViecInput.ForeColor = System.Drawing.SystemColors.Control;
            this.panel_NgayNhanViecInput.Location = new System.Drawing.Point(710, 186);
            this.panel_NgayNhanViecInput.Name = "panel_NgayNhanViecInput";
            this.panel_NgayNhanViecInput.Size = new System.Drawing.Size(231, 45);
            this.panel_NgayNhanViecInput.TabIndex = 11;
            // 
            // dateTimePicker_NgayNhanViecInput
            // 
            this.dateTimePicker_NgayNhanViecInput.CalendarForeColor = System.Drawing.Color.White;
            this.dateTimePicker_NgayNhanViecInput.CalendarTitleBackColor = System.Drawing.Color.White;
            this.dateTimePicker_NgayNhanViecInput.CustomFormat = "dd/MM/yyyy";
            this.dateTimePicker_NgayNhanViecInput.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dateTimePicker_NgayNhanViecInput.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dateTimePicker_NgayNhanViecInput.Location = new System.Drawing.Point(0, 6);
            this.dateTimePicker_NgayNhanViecInput.Name = "dateTimePicker_NgayNhanViecInput";
            this.dateTimePicker_NgayNhanViecInput.Size = new System.Drawing.Size(230, 33);
            this.dateTimePicker_NgayNhanViecInput.TabIndex = 3;
            this.dateTimePicker_NgayNhanViecInput.Value = new System.DateTime(2024, 3, 8, 0, 0, 0, 0);
            this.dateTimePicker_NgayNhanViecInput.ValueChanged += new System.EventHandler(this.dateTimePicker_NgayNhanViecInput_ValueChanged);
            // 
            // panel_SoDienThoaiInput
            // 
            this.panel_SoDienThoaiInput.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(221)))), ((int)(((byte)(222)))), ((int)(((byte)(238)))));
            this.panel_SoDienThoaiInput.Controls.Add(this.textBox_SoDienThoaiInput);
            this.panel_SoDienThoaiInput.ForeColor = System.Drawing.SystemColors.Control;
            this.panel_SoDienThoaiInput.Location = new System.Drawing.Point(17, 186);
            this.panel_SoDienThoaiInput.Name = "panel_SoDienThoaiInput";
            this.panel_SoDienThoaiInput.Size = new System.Drawing.Size(254, 45);
            this.panel_SoDienThoaiInput.TabIndex = 15;
            // 
            // textBox_SoDienThoaiInput
            // 
            this.textBox_SoDienThoaiInput.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(221)))), ((int)(((byte)(222)))), ((int)(((byte)(238)))));
            this.textBox_SoDienThoaiInput.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox_SoDienThoaiInput.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox_SoDienThoaiInput.Location = new System.Drawing.Point(2, 9);
            this.textBox_SoDienThoaiInput.Name = "textBox_SoDienThoaiInput";
            this.textBox_SoDienThoaiInput.Size = new System.Drawing.Size(249, 26);
            this.textBox_SoDienThoaiInput.TabIndex = 2;
            // 
            // label_NgayNhanViec
            // 
            this.label_NgayNhanViec.AutoSize = true;
            this.label_NgayNhanViec.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label_NgayNhanViec.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_NgayNhanViec.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label_NgayNhanViec.Location = new System.Drawing.Point(706, 152);
            this.label_NgayNhanViec.Name = "label_NgayNhanViec";
            this.label_NgayNhanViec.Size = new System.Drawing.Size(155, 25);
            this.label_NgayNhanViec.TabIndex = 10;
            this.label_NgayNhanViec.Text = "Ngày nhận việc *";
            // 
            // label_SoDienThoai
            // 
            this.label_SoDienThoai.AutoSize = true;
            this.label_SoDienThoai.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label_SoDienThoai.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_SoDienThoai.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label_SoDienThoai.Location = new System.Drawing.Point(13, 152);
            this.label_SoDienThoai.Name = "label_SoDienThoai";
            this.label_SoDienThoai.Size = new System.Drawing.Size(136, 25);
            this.label_SoDienThoai.TabIndex = 14;
            this.label_SoDienThoai.Text = "Số điện thoại *";
            // 
            // panel_GioiTinhInput
            // 
            this.panel_GioiTinhInput.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(221)))), ((int)(((byte)(222)))), ((int)(((byte)(238)))));
            this.panel_GioiTinhInput.Controls.Add(this.comboBox_GioiTinhInput);
            this.panel_GioiTinhInput.ForeColor = System.Drawing.SystemColors.Control;
            this.panel_GioiTinhInput.Location = new System.Drawing.Point(502, 78);
            this.panel_GioiTinhInput.Name = "panel_GioiTinhInput";
            this.panel_GioiTinhInput.Size = new System.Drawing.Size(123, 45);
            this.panel_GioiTinhInput.TabIndex = 11;
            // 
            // comboBox_GioiTinhInput
            // 
            this.comboBox_GioiTinhInput.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.comboBox_GioiTinhInput.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.comboBox_GioiTinhInput.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(221)))), ((int)(((byte)(222)))), ((int)(((byte)(238)))));
            this.comboBox_GioiTinhInput.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.comboBox_GioiTinhInput.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboBox_GioiTinhInput.FormattingEnabled = true;
            this.comboBox_GioiTinhInput.Location = new System.Drawing.Point(2, 6);
            this.comboBox_GioiTinhInput.Name = "comboBox_GioiTinhInput";
            this.comboBox_GioiTinhInput.Size = new System.Drawing.Size(118, 33);
            this.comboBox_GioiTinhInput.TabIndex = 10;
            // 
            // panel_NgaySinhInput
            // 
            this.panel_NgaySinhInput.BackColor = System.Drawing.Color.White;
            this.panel_NgaySinhInput.Controls.Add(this.dateTimePicker_NgaySinhInput);
            this.panel_NgaySinhInput.ForeColor = System.Drawing.SystemColors.Control;
            this.panel_NgaySinhInput.Location = new System.Drawing.Point(710, 78);
            this.panel_NgaySinhInput.Name = "panel_NgaySinhInput";
            this.panel_NgaySinhInput.Size = new System.Drawing.Size(231, 45);
            this.panel_NgaySinhInput.TabIndex = 9;
            // 
            // dateTimePicker_NgaySinhInput
            // 
            this.dateTimePicker_NgaySinhInput.CalendarForeColor = System.Drawing.Color.White;
            this.dateTimePicker_NgaySinhInput.CalendarTitleBackColor = System.Drawing.Color.White;
            this.dateTimePicker_NgaySinhInput.CustomFormat = "dd/MM/yyyy";
            this.dateTimePicker_NgaySinhInput.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dateTimePicker_NgaySinhInput.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dateTimePicker_NgaySinhInput.Location = new System.Drawing.Point(1, 6);
            this.dateTimePicker_NgaySinhInput.Name = "dateTimePicker_NgaySinhInput";
            this.dateTimePicker_NgaySinhInput.Size = new System.Drawing.Size(230, 33);
            this.dateTimePicker_NgaySinhInput.TabIndex = 3;
            this.dateTimePicker_NgaySinhInput.Value = new System.DateTime(2024, 3, 8, 0, 0, 0, 0);
            this.dateTimePicker_NgaySinhInput.ValueChanged += new System.EventHandler(this.dateTimePicker_NgaySinhInput_ValueChanged);
            // 
            // label_NgaySinh
            // 
            this.label_NgaySinh.AutoSize = true;
            this.label_NgaySinh.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label_NgaySinh.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_NgaySinh.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label_NgaySinh.Location = new System.Drawing.Point(706, 45);
            this.label_NgaySinh.Name = "label_NgaySinh";
            this.label_NgaySinh.Size = new System.Drawing.Size(205, 25);
            this.label_NgaySinh.TabIndex = 8;
            this.label_NgaySinh.Text = "Ngày tháng năm sinh *";
            // 
            // label_GioiTinh
            // 
            this.label_GioiTinh.AutoSize = true;
            this.label_GioiTinh.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label_GioiTinh.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_GioiTinh.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label_GioiTinh.Location = new System.Drawing.Point(497, 45);
            this.label_GioiTinh.Name = "label_GioiTinh";
            this.label_GioiTinh.Size = new System.Drawing.Size(97, 25);
            this.label_GioiTinh.TabIndex = 6;
            this.label_GioiTinh.Text = "Giới tính *";
            // 
            // panel_ChucVuInput
            // 
            this.panel_ChucVuInput.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(221)))), ((int)(((byte)(222)))), ((int)(((byte)(238)))));
            this.panel_ChucVuInput.Controls.Add(this.comboBox_ChucVuInput);
            this.panel_ChucVuInput.ForeColor = System.Drawing.SystemColors.Control;
            this.panel_ChucVuInput.Location = new System.Drawing.Point(325, 78);
            this.panel_ChucVuInput.Name = "panel_ChucVuInput";
            this.panel_ChucVuInput.Size = new System.Drawing.Size(120, 45);
            this.panel_ChucVuInput.TabIndex = 5;
            // 
            // comboBox_ChucVuInput
            // 
            this.comboBox_ChucVuInput.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.comboBox_ChucVuInput.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.comboBox_ChucVuInput.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(221)))), ((int)(((byte)(222)))), ((int)(((byte)(238)))));
            this.comboBox_ChucVuInput.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.comboBox_ChucVuInput.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboBox_ChucVuInput.FormattingEnabled = true;
            this.comboBox_ChucVuInput.Location = new System.Drawing.Point(2, 6);
            this.comboBox_ChucVuInput.Name = "comboBox_ChucVuInput";
            this.comboBox_ChucVuInput.Size = new System.Drawing.Size(115, 33);
            this.comboBox_ChucVuInput.TabIndex = 10;
            // 
            // label_ChucVu
            // 
            this.label_ChucVu.AutoSize = true;
            this.label_ChucVu.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label_ChucVu.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_ChucVu.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label_ChucVu.Location = new System.Drawing.Point(321, 45);
            this.label_ChucVu.Name = "label_ChucVu";
            this.label_ChucVu.Size = new System.Drawing.Size(93, 25);
            this.label_ChucVu.TabIndex = 4;
            this.label_ChucVu.Text = "Chức vụ *";
            // 
            // panel_HoVaTenInput
            // 
            this.panel_HoVaTenInput.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(221)))), ((int)(((byte)(222)))), ((int)(((byte)(238)))));
            this.panel_HoVaTenInput.Controls.Add(this.textBox_HoVaTenInput);
            this.panel_HoVaTenInput.ForeColor = System.Drawing.SystemColors.Control;
            this.panel_HoVaTenInput.Location = new System.Drawing.Point(16, 78);
            this.panel_HoVaTenInput.Name = "panel_HoVaTenInput";
            this.panel_HoVaTenInput.Size = new System.Drawing.Size(254, 45);
            this.panel_HoVaTenInput.TabIndex = 3;
            // 
            // textBox_HoVaTenInput
            // 
            this.textBox_HoVaTenInput.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(221)))), ((int)(((byte)(222)))), ((int)(((byte)(238)))));
            this.textBox_HoVaTenInput.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox_HoVaTenInput.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox_HoVaTenInput.Location = new System.Drawing.Point(2, 9);
            this.textBox_HoVaTenInput.Name = "textBox_HoVaTenInput";
            this.textBox_HoVaTenInput.Size = new System.Drawing.Size(249, 26);
            this.textBox_HoVaTenInput.TabIndex = 2;
            // 
            // label_HoVaTen
            // 
            this.label_HoVaTen.AutoSize = true;
            this.label_HoVaTen.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label_HoVaTen.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_HoVaTen.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label_HoVaTen.Location = new System.Drawing.Point(12, 45);
            this.label_HoVaTen.Name = "label_HoVaTen";
            this.label_HoVaTen.Size = new System.Drawing.Size(105, 25);
            this.label_HoVaTen.TabIndex = 1;
            this.label_HoVaTen.Text = "Họ và tên *";
            // 
            // label_ThemNhanVienMoi
            // 
            this.label_ThemNhanVienMoi.AutoSize = true;
            this.label_ThemNhanVienMoi.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label_ThemNhanVienMoi.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_ThemNhanVienMoi.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(95)))), ((int)(((byte)(105)))));
            this.label_ThemNhanVienMoi.Location = new System.Drawing.Point(12, 9);
            this.label_ThemNhanVienMoi.Name = "label_ThemNhanVienMoi";
            this.label_ThemNhanVienMoi.Size = new System.Drawing.Size(195, 25);
            this.label_ThemNhanVienMoi.TabIndex = 0;
            this.label_ThemNhanVienMoi.Text = "Thêm Nhân viên mới";
            // 
            // panel_XoaNhanVienFunction
            // 
            this.panel_XoaNhanVienFunction.BackColor = System.Drawing.Color.White;
            this.panel_XoaNhanVienFunction.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel_XoaNhanVienFunction.Controls.Add(this.button_ResetDelete);
            this.panel_XoaNhanVienFunction.Controls.Add(this.panel_IDDeleteInput);
            this.panel_XoaNhanVienFunction.Controls.Add(this.button_SaveDelete);
            this.panel_XoaNhanVienFunction.Controls.Add(this.label_ID);
            this.panel_XoaNhanVienFunction.Controls.Add(this.label_XoaNhanVien);
            this.panel_XoaNhanVienFunction.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel_XoaNhanVienFunction.Location = new System.Drawing.Point(0, 458);
            this.panel_XoaNhanVienFunction.Name = "panel_XoaNhanVienFunction";
            this.panel_XoaNhanVienFunction.Size = new System.Drawing.Size(968, 229);
            this.panel_XoaNhanVienFunction.TabIndex = 1;
            // 
            // button_ResetDelete
            // 
            this.button_ResetDelete.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(95)))), ((int)(((byte)(105)))));
            this.button_ResetDelete.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button_ResetDelete.FlatAppearance.BorderSize = 0;
            this.button_ResetDelete.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_ResetDelete.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_ResetDelete.Location = new System.Drawing.Point(118, 158);
            this.button_ResetDelete.Name = "button_ResetDelete";
            this.button_ResetDelete.Size = new System.Drawing.Size(96, 48);
            this.button_ResetDelete.TabIndex = 22;
            this.button_ResetDelete.Text = "Reset";
            this.button_ResetDelete.UseVisualStyleBackColor = false;
            this.button_ResetDelete.Click += new System.EventHandler(this.button_ResetDelete_Click);
            // 
            // panel_IDDeleteInput
            // 
            this.panel_IDDeleteInput.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(221)))), ((int)(((byte)(222)))), ((int)(((byte)(238)))));
            this.panel_IDDeleteInput.Controls.Add(this.textBox_IDDeleteInput);
            this.panel_IDDeleteInput.ForeColor = System.Drawing.SystemColors.Control;
            this.panel_IDDeleteInput.Location = new System.Drawing.Point(16, 90);
            this.panel_IDDeleteInput.Name = "panel_IDDeleteInput";
            this.panel_IDDeleteInput.Size = new System.Drawing.Size(201, 45);
            this.panel_IDDeleteInput.TabIndex = 5;
            // 
            // textBox_IDDeleteInput
            // 
            this.textBox_IDDeleteInput.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(221)))), ((int)(((byte)(222)))), ((int)(((byte)(238)))));
            this.textBox_IDDeleteInput.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox_IDDeleteInput.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox_IDDeleteInput.Location = new System.Drawing.Point(2, 9);
            this.textBox_IDDeleteInput.Name = "textBox_IDDeleteInput";
            this.textBox_IDDeleteInput.Size = new System.Drawing.Size(196, 26);
            this.textBox_IDDeleteInput.TabIndex = 2;
            // 
            // button_SaveDelete
            // 
            this.button_SaveDelete.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(111)))), ((int)(((byte)(51)))));
            this.button_SaveDelete.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button_SaveDelete.FlatAppearance.BorderSize = 0;
            this.button_SaveDelete.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_SaveDelete.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_SaveDelete.Location = new System.Drawing.Point(16, 159);
            this.button_SaveDelete.Name = "button_SaveDelete";
            this.button_SaveDelete.Size = new System.Drawing.Size(96, 48);
            this.button_SaveDelete.TabIndex = 21;
            this.button_SaveDelete.Text = "Delete";
            this.button_SaveDelete.UseVisualStyleBackColor = false;
            this.button_SaveDelete.Click += new System.EventHandler(this.button_SaveDelete_Click);
            // 
            // label_ID
            // 
            this.label_ID.AutoSize = true;
            this.label_ID.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label_ID.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_ID.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label_ID.Location = new System.Drawing.Point(12, 57);
            this.label_ID.Name = "label_ID";
            this.label_ID.Size = new System.Drawing.Size(43, 25);
            this.label_ID.TabIndex = 4;
            this.label_ID.Text = "ID *";
            // 
            // label_XoaNhanVien
            // 
            this.label_XoaNhanVien.AutoSize = true;
            this.label_XoaNhanVien.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label_XoaNhanVien.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_XoaNhanVien.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(95)))), ((int)(((byte)(105)))));
            this.label_XoaNhanVien.Location = new System.Drawing.Point(11, 19);
            this.label_XoaNhanVien.Name = "label_XoaNhanVien";
            this.label_XoaNhanVien.Size = new System.Drawing.Size(141, 25);
            this.label_XoaNhanVien.TabIndex = 21;
            this.label_XoaNhanVien.Text = "Xóa Nhân viên";
            // 
            // openFileDialog_Avatar
            // 
            this.openFileDialog_Avatar.FileName = "openFileDialog1";
            // 
            // ffc_ThemXoaNhanVien
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(968, 687);
            this.Controls.Add(this.panel_ThemNhanVienFunction);
            this.Controls.Add(this.panel_XoaNhanVienFunction);
            this.ForeColor = System.Drawing.Color.White;
            this.Name = "ffc_ThemXoaNhanVien";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "FormThemXoaNhanVien";
            this.panel_ThemNhanVienFunction.ResumeLayout(false);
            this.panel_ThemNhanVienFunction.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.guna2CirclePictureBox_Avatar)).EndInit();
            this.panel_GioiThieuInput.ResumeLayout(false);
            this.panel_GioiThieuInput.PerformLayout();
            this.panel_NgayNhanViecInput.ResumeLayout(false);
            this.panel_SoDienThoaiInput.ResumeLayout(false);
            this.panel_SoDienThoaiInput.PerformLayout();
            this.panel_GioiTinhInput.ResumeLayout(false);
            this.panel_NgaySinhInput.ResumeLayout(false);
            this.panel_ChucVuInput.ResumeLayout(false);
            this.panel_HoVaTenInput.ResumeLayout(false);
            this.panel_HoVaTenInput.PerformLayout();
            this.panel_XoaNhanVienFunction.ResumeLayout(false);
            this.panel_XoaNhanVienFunction.PerformLayout();
            this.panel_IDDeleteInput.ResumeLayout(false);
            this.panel_IDDeleteInput.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel_ThemNhanVienFunction;
        private System.Windows.Forms.Label label_ThemNhanVienMoi;
        private System.Windows.Forms.Label label_NgaySinh;
        private System.Windows.Forms.Label label_GioiTinh;
        private System.Windows.Forms.Panel panel_ChucVuInput;
        private System.Windows.Forms.ComboBox comboBox_ChucVuInput;
        private System.Windows.Forms.Label label_ChucVu;
        private System.Windows.Forms.Panel panel_HoVaTenInput;
        private System.Windows.Forms.TextBox textBox_HoVaTenInput;
        private System.Windows.Forms.Label label_HoVaTen;
        private System.Windows.Forms.Panel panel_GioiTinhInput;
        private System.Windows.Forms.ComboBox comboBox_GioiTinhInput;
        private System.Windows.Forms.Panel panel_SoDienThoaiInput;
        private System.Windows.Forms.TextBox textBox_SoDienThoaiInput;
        private System.Windows.Forms.Label label_SoDienThoai;
        private System.Windows.Forms.Panel panel_NgayNhanViecInput;
        private System.Windows.Forms.DateTimePicker dateTimePicker_NgayNhanViecInput;
        private System.Windows.Forms.Label label_NgayNhanViec;
        private System.Windows.Forms.Button button_Upload;
        private System.Windows.Forms.Panel panel_GioiThieuInput;
        private System.Windows.Forms.TextBox textBox_GioiThieuInput;
        private System.Windows.Forms.Label label_GioiThieu;
        private System.Windows.Forms.Label label_Upload;
        private System.Windows.Forms.Button button_ResetInsert;
        private System.Windows.Forms.Button button_SaveInsert;
        private System.Windows.Forms.Panel panel_XoaNhanVienFunction;
        private System.Windows.Forms.Panel panel_IDDeleteInput;
        private System.Windows.Forms.TextBox textBox_IDDeleteInput;
        private System.Windows.Forms.Label label_ID;
        private System.Windows.Forms.Label label_XoaNhanVien;
        private System.Windows.Forms.Button button_ResetDelete;
        private System.Windows.Forms.Button button_SaveDelete;
        private System.Windows.Forms.Panel panel_NgaySinhInput;
        private System.Windows.Forms.DateTimePicker dateTimePicker_NgaySinhInput;
        private System.Windows.Forms.OpenFileDialog openFileDialog_Avatar;
        private Guna.UI2.WinForms.Guna2CirclePictureBox guna2CirclePictureBox_Avatar;
    }
}