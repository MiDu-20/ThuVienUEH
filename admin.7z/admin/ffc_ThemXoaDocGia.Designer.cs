﻿namespace QuanLiThuVienUeh.admin
{
    partial class ffc_ThemXoaDocGia
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel_ThemNhanVienFunction = new System.Windows.Forms.Panel();
            this.panel_LopInput = new System.Windows.Forms.Panel();
            this.textBox_LopInput = new System.Windows.Forms.TextBox();
            this.label_Lop = new System.Windows.Forms.Label();
            this.panel_ChuyenNganhInput = new System.Windows.Forms.Panel();
            this.textBox_ChuyenNganhInput = new System.Windows.Forms.TextBox();
            this.label_ChuyenNganh = new System.Windows.Forms.Label();
            this.guna2CirclePictureBox_Avatar = new Guna.UI2.WinForms.Guna2CirclePictureBox();
            this.button_ResetInsert = new System.Windows.Forms.Button();
            this.button_SaveInsert = new System.Windows.Forms.Button();
            this.label_Upload = new System.Windows.Forms.Label();
            this.button_Upload = new System.Windows.Forms.Button();
            this.panel_GioiThieuInput = new System.Windows.Forms.Panel();
            this.textBox_GioiThieuInput = new System.Windows.Forms.TextBox();
            this.label_GioiThieu = new System.Windows.Forms.Label();
            this.panel_SoDienThoaiInput = new System.Windows.Forms.Panel();
            this.textBox_SoDienThoaiInput = new System.Windows.Forms.TextBox();
            this.label_SoDienThoai = new System.Windows.Forms.Label();
            this.panel_GioiTinhInput = new System.Windows.Forms.Panel();
            this.comboBox_GioiTinhInput = new System.Windows.Forms.ComboBox();
            this.panel_NgaySinhInput = new System.Windows.Forms.Panel();
            this.dateTimePicker_NgaySinhInput = new System.Windows.Forms.DateTimePicker();
            this.label_NgaySinh = new System.Windows.Forms.Label();
            this.label_GioiTinh = new System.Windows.Forms.Label();
            this.panel_HoVaTenInput = new System.Windows.Forms.Panel();
            this.textBox_HoVaTenInput = new System.Windows.Forms.TextBox();
            this.label_HoVaTen = new System.Windows.Forms.Label();
            this.label_ThemDocGiaMoi = new System.Windows.Forms.Label();
            this.panel_XoaNhanVienFunction = new System.Windows.Forms.Panel();
            this.button_ResetDelete = new System.Windows.Forms.Button();
            this.panel_IDDeleteInput = new System.Windows.Forms.Panel();
            this.textBox_IDDeleteInput = new System.Windows.Forms.TextBox();
            this.button_SaveDelete = new System.Windows.Forms.Button();
            this.label_ID = new System.Windows.Forms.Label();
            this.label_XoaNhanVien = new System.Windows.Forms.Label();
            this.openFileDialog_Avatar = new System.Windows.Forms.OpenFileDialog();
            this.panel_ThemNhanVienFunction.SuspendLayout();
            this.panel_LopInput.SuspendLayout();
            this.panel_ChuyenNganhInput.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.guna2CirclePictureBox_Avatar)).BeginInit();
            this.panel_GioiThieuInput.SuspendLayout();
            this.panel_SoDienThoaiInput.SuspendLayout();
            this.panel_GioiTinhInput.SuspendLayout();
            this.panel_NgaySinhInput.SuspendLayout();
            this.panel_HoVaTenInput.SuspendLayout();
            this.panel_XoaNhanVienFunction.SuspendLayout();
            this.panel_IDDeleteInput.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel_ThemNhanVienFunction
            // 
            this.panel_ThemNhanVienFunction.BackColor = System.Drawing.Color.White;
            this.panel_ThemNhanVienFunction.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel_ThemNhanVienFunction.Controls.Add(this.panel_LopInput);
            this.panel_ThemNhanVienFunction.Controls.Add(this.label_Lop);
            this.panel_ThemNhanVienFunction.Controls.Add(this.panel_ChuyenNganhInput);
            this.panel_ThemNhanVienFunction.Controls.Add(this.label_ChuyenNganh);
            this.panel_ThemNhanVienFunction.Controls.Add(this.guna2CirclePictureBox_Avatar);
            this.panel_ThemNhanVienFunction.Controls.Add(this.button_ResetInsert);
            this.panel_ThemNhanVienFunction.Controls.Add(this.button_SaveInsert);
            this.panel_ThemNhanVienFunction.Controls.Add(this.label_Upload);
            this.panel_ThemNhanVienFunction.Controls.Add(this.button_Upload);
            this.panel_ThemNhanVienFunction.Controls.Add(this.panel_GioiThieuInput);
            this.panel_ThemNhanVienFunction.Controls.Add(this.label_GioiThieu);
            this.panel_ThemNhanVienFunction.Controls.Add(this.panel_SoDienThoaiInput);
            this.panel_ThemNhanVienFunction.Controls.Add(this.label_SoDienThoai);
            this.panel_ThemNhanVienFunction.Controls.Add(this.panel_GioiTinhInput);
            this.panel_ThemNhanVienFunction.Controls.Add(this.panel_NgaySinhInput);
            this.panel_ThemNhanVienFunction.Controls.Add(this.label_NgaySinh);
            this.panel_ThemNhanVienFunction.Controls.Add(this.label_GioiTinh);
            this.panel_ThemNhanVienFunction.Controls.Add(this.panel_HoVaTenInput);
            this.panel_ThemNhanVienFunction.Controls.Add(this.label_HoVaTen);
            this.panel_ThemNhanVienFunction.Controls.Add(this.label_ThemDocGiaMoi);
            this.panel_ThemNhanVienFunction.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel_ThemNhanVienFunction.Location = new System.Drawing.Point(0, 0);
            this.panel_ThemNhanVienFunction.Margin = new System.Windows.Forms.Padding(4);
            this.panel_ThemNhanVienFunction.Name = "panel_ThemNhanVienFunction";
            this.panel_ThemNhanVienFunction.Size = new System.Drawing.Size(1245, 565);
            this.panel_ThemNhanVienFunction.TabIndex = 0;
            // 
            // panel_LopInput
            // 
            this.panel_LopInput.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(221)))), ((int)(((byte)(222)))), ((int)(((byte)(238)))));
            this.panel_LopInput.Controls.Add(this.textBox_LopInput);
            this.panel_LopInput.ForeColor = System.Drawing.SystemColors.Control;
            this.panel_LopInput.Location = new System.Drawing.Point(407, 229);
            this.panel_LopInput.Margin = new System.Windows.Forms.Padding(4);
            this.panel_LopInput.Name = "panel_LopInput";
            this.panel_LopInput.Size = new System.Drawing.Size(168, 55);
            this.panel_LopInput.TabIndex = 24;
            // 
            // textBox_LopInput
            // 
            this.textBox_LopInput.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(221)))), ((int)(((byte)(222)))), ((int)(((byte)(238)))));
            this.textBox_LopInput.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox_LopInput.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox_LopInput.Location = new System.Drawing.Point(3, 11);
            this.textBox_LopInput.Margin = new System.Windows.Forms.Padding(4);
            this.textBox_LopInput.Name = "textBox_LopInput";
            this.textBox_LopInput.Size = new System.Drawing.Size(161, 32);
            this.textBox_LopInput.TabIndex = 2;
            // 
            // label_Lop
            // 
            this.label_Lop.AutoSize = true;
            this.label_Lop.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label_Lop.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_Lop.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label_Lop.Location = new System.Drawing.Point(401, 187);
            this.label_Lop.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_Lop.Name = "label_Lop";
            this.label_Lop.Size = new System.Drawing.Size(70, 32);
            this.label_Lop.TabIndex = 23;
            this.label_Lop.Text = "Lớp *";
            // 
            // panel_ChuyenNganhInput
            // 
            this.panel_ChuyenNganhInput.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(221)))), ((int)(((byte)(222)))), ((int)(((byte)(238)))));
            this.panel_ChuyenNganhInput.Controls.Add(this.textBox_ChuyenNganhInput);
            this.panel_ChuyenNganhInput.ForeColor = System.Drawing.SystemColors.Control;
            this.panel_ChuyenNganhInput.Location = new System.Drawing.Point(21, 229);
            this.panel_ChuyenNganhInput.Margin = new System.Windows.Forms.Padding(4);
            this.panel_ChuyenNganhInput.Name = "panel_ChuyenNganhInput";
            this.panel_ChuyenNganhInput.Size = new System.Drawing.Size(339, 55);
            this.panel_ChuyenNganhInput.TabIndex = 17;
            // 
            // textBox_ChuyenNganhInput
            // 
            this.textBox_ChuyenNganhInput.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(221)))), ((int)(((byte)(222)))), ((int)(((byte)(238)))));
            this.textBox_ChuyenNganhInput.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox_ChuyenNganhInput.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox_ChuyenNganhInput.Location = new System.Drawing.Point(3, 11);
            this.textBox_ChuyenNganhInput.Margin = new System.Windows.Forms.Padding(4);
            this.textBox_ChuyenNganhInput.Name = "textBox_ChuyenNganhInput";
            this.textBox_ChuyenNganhInput.Size = new System.Drawing.Size(332, 32);
            this.textBox_ChuyenNganhInput.TabIndex = 2;
            // 
            // label_ChuyenNganh
            // 
            this.label_ChuyenNganh.AutoSize = true;
            this.label_ChuyenNganh.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label_ChuyenNganh.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_ChuyenNganh.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label_ChuyenNganh.Location = new System.Drawing.Point(16, 187);
            this.label_ChuyenNganh.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_ChuyenNganh.Name = "label_ChuyenNganh";
            this.label_ChuyenNganh.Size = new System.Drawing.Size(188, 32);
            this.label_ChuyenNganh.TabIndex = 16;
            this.label_ChuyenNganh.Text = "Chuyên ngành *";
            // 
            // guna2CirclePictureBox_Avatar
            // 
            this.guna2CirclePictureBox_Avatar.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.guna2CirclePictureBox_Avatar.ImageRotate = 0F;
            this.guna2CirclePictureBox_Avatar.Location = new System.Drawing.Point(23, 330);
            this.guna2CirclePictureBox_Avatar.Margin = new System.Windows.Forms.Padding(4);
            this.guna2CirclePictureBox_Avatar.Name = "guna2CirclePictureBox_Avatar";
            this.guna2CirclePictureBox_Avatar.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle;
            this.guna2CirclePictureBox_Avatar.Size = new System.Drawing.Size(266, 215);
            this.guna2CirclePictureBox_Avatar.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.guna2CirclePictureBox_Avatar.TabIndex = 22;
            this.guna2CirclePictureBox_Avatar.TabStop = false;
            // 
            // button_ResetInsert
            // 
            this.button_ResetInsert.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(95)))), ((int)(((byte)(105)))));
            this.button_ResetInsert.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button_ResetInsert.FlatAppearance.BorderSize = 0;
            this.button_ResetInsert.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_ResetInsert.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_ResetInsert.Location = new System.Drawing.Point(1083, 484);
            this.button_ResetInsert.Margin = new System.Windows.Forms.Padding(4);
            this.button_ResetInsert.Name = "button_ResetInsert";
            this.button_ResetInsert.Size = new System.Drawing.Size(128, 59);
            this.button_ResetInsert.TabIndex = 20;
            this.button_ResetInsert.Text = "Reset";
            this.button_ResetInsert.UseVisualStyleBackColor = false;
            this.button_ResetInsert.Click += new System.EventHandler(this.button_ResetInsert_Click);
            // 
            // button_SaveInsert
            // 
            this.button_SaveInsert.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(111)))), ((int)(((byte)(51)))));
            this.button_SaveInsert.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button_SaveInsert.FlatAppearance.BorderSize = 0;
            this.button_SaveInsert.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_SaveInsert.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_SaveInsert.Location = new System.Drawing.Point(947, 485);
            this.button_SaveInsert.Margin = new System.Windows.Forms.Padding(4);
            this.button_SaveInsert.Name = "button_SaveInsert";
            this.button_SaveInsert.Size = new System.Drawing.Size(128, 59);
            this.button_SaveInsert.TabIndex = 19;
            this.button_SaveInsert.Text = "Save";
            this.button_SaveInsert.UseVisualStyleBackColor = false;
            this.button_SaveInsert.Click += new System.EventHandler(this.button_SaveInsert_Click);
            // 
            // label_Upload
            // 
            this.label_Upload.AutoSize = true;
            this.label_Upload.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label_Upload.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_Upload.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label_Upload.Location = new System.Drawing.Point(316, 471);
            this.label_Upload.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_Upload.Name = "label_Upload";
            this.label_Upload.Size = new System.Drawing.Size(161, 32);
            this.label_Upload.TabIndex = 18;
            this.label_Upload.Text = "Upload avatar";
            // 
            // button_Upload
            // 
            this.button_Upload.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(221)))), ((int)(((byte)(222)))), ((int)(((byte)(238)))));
            this.button_Upload.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.button_Upload.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.button_Upload.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.button_Upload.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_Upload.ForeColor = System.Drawing.Color.Black;
            this.button_Upload.Location = new System.Drawing.Point(320, 505);
            this.button_Upload.Margin = new System.Windows.Forms.Padding(4);
            this.button_Upload.Name = "button_Upload";
            this.button_Upload.Size = new System.Drawing.Size(168, 39);
            this.button_Upload.TabIndex = 17;
            this.button_Upload.Text = "Choose File";
            this.button_Upload.UseVisualStyleBackColor = false;
            this.button_Upload.Click += new System.EventHandler(this.button_Upload_Click);
            // 
            // panel_GioiThieuInput
            // 
            this.panel_GioiThieuInput.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(221)))), ((int)(((byte)(222)))), ((int)(((byte)(238)))));
            this.panel_GioiThieuInput.Controls.Add(this.textBox_GioiThieuInput);
            this.panel_GioiThieuInput.ForeColor = System.Drawing.SystemColors.Control;
            this.panel_GioiThieuInput.Location = new System.Drawing.Point(620, 229);
            this.panel_GioiThieuInput.Margin = new System.Windows.Forms.Padding(4);
            this.panel_GioiThieuInput.Name = "panel_GioiThieuInput";
            this.panel_GioiThieuInput.Size = new System.Drawing.Size(405, 187);
            this.panel_GioiThieuInput.TabIndex = 15;
            // 
            // textBox_GioiThieuInput
            // 
            this.textBox_GioiThieuInput.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(221)))), ((int)(((byte)(222)))), ((int)(((byte)(238)))));
            this.textBox_GioiThieuInput.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox_GioiThieuInput.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox_GioiThieuInput.Location = new System.Drawing.Point(3, 4);
            this.textBox_GioiThieuInput.Margin = new System.Windows.Forms.Padding(4);
            this.textBox_GioiThieuInput.Multiline = true;
            this.textBox_GioiThieuInput.Name = "textBox_GioiThieuInput";
            this.textBox_GioiThieuInput.Size = new System.Drawing.Size(399, 180);
            this.textBox_GioiThieuInput.TabIndex = 2;
            // 
            // label_GioiThieu
            // 
            this.label_GioiThieu.AutoSize = true;
            this.label_GioiThieu.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label_GioiThieu.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_GioiThieu.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label_GioiThieu.Location = new System.Drawing.Point(615, 187);
            this.label_GioiThieu.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_GioiThieu.Name = "label_GioiThieu";
            this.label_GioiThieu.Size = new System.Drawing.Size(118, 32);
            this.label_GioiThieu.TabIndex = 14;
            this.label_GioiThieu.Text = "Giới thiệu";
            // 
            // panel_SoDienThoaiInput
            // 
            this.panel_SoDienThoaiInput.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(221)))), ((int)(((byte)(222)))), ((int)(((byte)(238)))));
            this.panel_SoDienThoaiInput.Controls.Add(this.textBox_SoDienThoaiInput);
            this.panel_SoDienThoaiInput.ForeColor = System.Drawing.SystemColors.Control;
            this.panel_SoDienThoaiInput.Location = new System.Drawing.Point(619, 96);
            this.panel_SoDienThoaiInput.Margin = new System.Windows.Forms.Padding(4);
            this.panel_SoDienThoaiInput.Name = "panel_SoDienThoaiInput";
            this.panel_SoDienThoaiInput.Size = new System.Drawing.Size(276, 55);
            this.panel_SoDienThoaiInput.TabIndex = 15;
            // 
            // textBox_SoDienThoaiInput
            // 
            this.textBox_SoDienThoaiInput.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(221)))), ((int)(((byte)(222)))), ((int)(((byte)(238)))));
            this.textBox_SoDienThoaiInput.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox_SoDienThoaiInput.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox_SoDienThoaiInput.Location = new System.Drawing.Point(3, 11);
            this.textBox_SoDienThoaiInput.Margin = new System.Windows.Forms.Padding(4);
            this.textBox_SoDienThoaiInput.Name = "textBox_SoDienThoaiInput";
            this.textBox_SoDienThoaiInput.Size = new System.Drawing.Size(269, 32);
            this.textBox_SoDienThoaiInput.TabIndex = 2;
            this.textBox_SoDienThoaiInput.TextChanged += new System.EventHandler(this.textBox_SoDienThoaiInput_TextChanged);
            // 
            // label_SoDienThoai
            // 
            this.label_SoDienThoai.AutoSize = true;
            this.label_SoDienThoai.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label_SoDienThoai.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_SoDienThoai.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label_SoDienThoai.Location = new System.Drawing.Point(613, 54);
            this.label_SoDienThoai.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_SoDienThoai.Name = "label_SoDienThoai";
            this.label_SoDienThoai.Size = new System.Drawing.Size(173, 32);
            this.label_SoDienThoai.TabIndex = 14;
            this.label_SoDienThoai.Text = "Số điện thoại *";
            // 
            // panel_GioiTinhInput
            // 
            this.panel_GioiTinhInput.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(221)))), ((int)(((byte)(222)))), ((int)(((byte)(238)))));
            this.panel_GioiTinhInput.Controls.Add(this.comboBox_GioiTinhInput);
            this.panel_GioiTinhInput.ForeColor = System.Drawing.SystemColors.Control;
            this.panel_GioiTinhInput.Location = new System.Drawing.Point(407, 96);
            this.panel_GioiTinhInput.Margin = new System.Windows.Forms.Padding(4);
            this.panel_GioiTinhInput.Name = "panel_GioiTinhInput";
            this.panel_GioiTinhInput.Size = new System.Drawing.Size(164, 55);
            this.panel_GioiTinhInput.TabIndex = 11;
            // 
            // comboBox_GioiTinhInput
            // 
            this.comboBox_GioiTinhInput.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.comboBox_GioiTinhInput.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.comboBox_GioiTinhInput.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(221)))), ((int)(((byte)(222)))), ((int)(((byte)(238)))));
            this.comboBox_GioiTinhInput.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.comboBox_GioiTinhInput.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboBox_GioiTinhInput.FormattingEnabled = true;
            this.comboBox_GioiTinhInput.Location = new System.Drawing.Point(3, 7);
            this.comboBox_GioiTinhInput.Margin = new System.Windows.Forms.Padding(4);
            this.comboBox_GioiTinhInput.Name = "comboBox_GioiTinhInput";
            this.comboBox_GioiTinhInput.Size = new System.Drawing.Size(156, 40);
            this.comboBox_GioiTinhInput.TabIndex = 10;
            this.comboBox_GioiTinhInput.TextChanged += new System.EventHandler(this.comboBox_GioiTinhInput_TextChanged);
            // 
            // panel_NgaySinhInput
            // 
            this.panel_NgaySinhInput.BackColor = System.Drawing.Color.White;
            this.panel_NgaySinhInput.Controls.Add(this.dateTimePicker_NgaySinhInput);
            this.panel_NgaySinhInput.ForeColor = System.Drawing.SystemColors.Control;
            this.panel_NgaySinhInput.Location = new System.Drawing.Point(947, 96);
            this.panel_NgaySinhInput.Margin = new System.Windows.Forms.Padding(4);
            this.panel_NgaySinhInput.Name = "panel_NgaySinhInput";
            this.panel_NgaySinhInput.Size = new System.Drawing.Size(268, 55);
            this.panel_NgaySinhInput.TabIndex = 9;
            // 
            // dateTimePicker_NgaySinhInput
            // 
            this.dateTimePicker_NgaySinhInput.CalendarForeColor = System.Drawing.Color.White;
            this.dateTimePicker_NgaySinhInput.CalendarTitleBackColor = System.Drawing.Color.White;
            this.dateTimePicker_NgaySinhInput.CustomFormat = "dd/MM/yyyy";
            this.dateTimePicker_NgaySinhInput.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dateTimePicker_NgaySinhInput.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dateTimePicker_NgaySinhInput.Location = new System.Drawing.Point(1, 7);
            this.dateTimePicker_NgaySinhInput.Margin = new System.Windows.Forms.Padding(4);
            this.dateTimePicker_NgaySinhInput.Name = "dateTimePicker_NgaySinhInput";
            this.dateTimePicker_NgaySinhInput.Size = new System.Drawing.Size(265, 39);
            this.dateTimePicker_NgaySinhInput.TabIndex = 3;
            this.dateTimePicker_NgaySinhInput.Value = new System.DateTime(2024, 3, 8, 0, 0, 0, 0);
            this.dateTimePicker_NgaySinhInput.ValueChanged += new System.EventHandler(this.dateTimePicker_NgaySinhInput_ValueChanged);
            // 
            // label_NgaySinh
            // 
            this.label_NgaySinh.AutoSize = true;
            this.label_NgaySinh.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label_NgaySinh.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_NgaySinh.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label_NgaySinh.Location = new System.Drawing.Point(941, 55);
            this.label_NgaySinh.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_NgaySinh.Name = "label_NgaySinh";
            this.label_NgaySinh.Size = new System.Drawing.Size(261, 32);
            this.label_NgaySinh.TabIndex = 8;
            this.label_NgaySinh.Text = "Ngày tháng năm sinh *";
            // 
            // label_GioiTinh
            // 
            this.label_GioiTinh.AutoSize = true;
            this.label_GioiTinh.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label_GioiTinh.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_GioiTinh.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label_GioiTinh.Location = new System.Drawing.Point(400, 55);
            this.label_GioiTinh.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_GioiTinh.Name = "label_GioiTinh";
            this.label_GioiTinh.Size = new System.Drawing.Size(122, 32);
            this.label_GioiTinh.TabIndex = 6;
            this.label_GioiTinh.Text = "Giới tính *";
            // 
            // panel_HoVaTenInput
            // 
            this.panel_HoVaTenInput.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(221)))), ((int)(((byte)(222)))), ((int)(((byte)(238)))));
            this.panel_HoVaTenInput.Controls.Add(this.textBox_HoVaTenInput);
            this.panel_HoVaTenInput.ForeColor = System.Drawing.SystemColors.Control;
            this.panel_HoVaTenInput.Location = new System.Drawing.Point(21, 96);
            this.panel_HoVaTenInput.Margin = new System.Windows.Forms.Padding(4);
            this.panel_HoVaTenInput.Name = "panel_HoVaTenInput";
            this.panel_HoVaTenInput.Size = new System.Drawing.Size(339, 55);
            this.panel_HoVaTenInput.TabIndex = 3;
            // 
            // textBox_HoVaTenInput
            // 
            this.textBox_HoVaTenInput.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(221)))), ((int)(((byte)(222)))), ((int)(((byte)(238)))));
            this.textBox_HoVaTenInput.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox_HoVaTenInput.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox_HoVaTenInput.Location = new System.Drawing.Point(3, 11);
            this.textBox_HoVaTenInput.Margin = new System.Windows.Forms.Padding(4);
            this.textBox_HoVaTenInput.Name = "textBox_HoVaTenInput";
            this.textBox_HoVaTenInput.Size = new System.Drawing.Size(332, 32);
            this.textBox_HoVaTenInput.TabIndex = 2;
            this.textBox_HoVaTenInput.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBox_HoVaTenInput_KeyPress);
            // 
            // label_HoVaTen
            // 
            this.label_HoVaTen.AutoSize = true;
            this.label_HoVaTen.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label_HoVaTen.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_HoVaTen.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label_HoVaTen.Location = new System.Drawing.Point(16, 55);
            this.label_HoVaTen.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_HoVaTen.Name = "label_HoVaTen";
            this.label_HoVaTen.Size = new System.Drawing.Size(135, 32);
            this.label_HoVaTen.TabIndex = 1;
            this.label_HoVaTen.Text = "Họ và tên *";
            // 
            // label_ThemDocGiaMoi
            // 
            this.label_ThemDocGiaMoi.AutoSize = true;
            this.label_ThemDocGiaMoi.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label_ThemDocGiaMoi.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_ThemDocGiaMoi.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(95)))), ((int)(((byte)(105)))));
            this.label_ThemDocGiaMoi.Location = new System.Drawing.Point(16, 11);
            this.label_ThemDocGiaMoi.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_ThemDocGiaMoi.Name = "label_ThemDocGiaMoi";
            this.label_ThemDocGiaMoi.Size = new System.Drawing.Size(222, 32);
            this.label_ThemDocGiaMoi.TabIndex = 0;
            this.label_ThemDocGiaMoi.Text = "Thêm Độc giả mới";
            // 
            // panel_XoaNhanVienFunction
            // 
            this.panel_XoaNhanVienFunction.BackColor = System.Drawing.Color.White;
            this.panel_XoaNhanVienFunction.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel_XoaNhanVienFunction.Controls.Add(this.button_ResetDelete);
            this.panel_XoaNhanVienFunction.Controls.Add(this.panel_IDDeleteInput);
            this.panel_XoaNhanVienFunction.Controls.Add(this.button_SaveDelete);
            this.panel_XoaNhanVienFunction.Controls.Add(this.label_ID);
            this.panel_XoaNhanVienFunction.Controls.Add(this.label_XoaNhanVien);
            this.panel_XoaNhanVienFunction.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel_XoaNhanVienFunction.Location = new System.Drawing.Point(0, 565);
            this.panel_XoaNhanVienFunction.Margin = new System.Windows.Forms.Padding(4);
            this.panel_XoaNhanVienFunction.Name = "panel_XoaNhanVienFunction";
            this.panel_XoaNhanVienFunction.Size = new System.Drawing.Size(1245, 281);
            this.panel_XoaNhanVienFunction.TabIndex = 1;
            // 
            // button_ResetDelete
            // 
            this.button_ResetDelete.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(95)))), ((int)(((byte)(105)))));
            this.button_ResetDelete.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button_ResetDelete.FlatAppearance.BorderSize = 0;
            this.button_ResetDelete.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_ResetDelete.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_ResetDelete.Location = new System.Drawing.Point(157, 194);
            this.button_ResetDelete.Margin = new System.Windows.Forms.Padding(4);
            this.button_ResetDelete.Name = "button_ResetDelete";
            this.button_ResetDelete.Size = new System.Drawing.Size(128, 59);
            this.button_ResetDelete.TabIndex = 22;
            this.button_ResetDelete.Text = "Reset";
            this.button_ResetDelete.UseVisualStyleBackColor = false;
            this.button_ResetDelete.Click += new System.EventHandler(this.button_ResetDelete_Click);
            // 
            // panel_IDDeleteInput
            // 
            this.panel_IDDeleteInput.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(221)))), ((int)(((byte)(222)))), ((int)(((byte)(238)))));
            this.panel_IDDeleteInput.Controls.Add(this.textBox_IDDeleteInput);
            this.panel_IDDeleteInput.ForeColor = System.Drawing.SystemColors.Control;
            this.panel_IDDeleteInput.Location = new System.Drawing.Point(21, 111);
            this.panel_IDDeleteInput.Margin = new System.Windows.Forms.Padding(4);
            this.panel_IDDeleteInput.Name = "panel_IDDeleteInput";
            this.panel_IDDeleteInput.Size = new System.Drawing.Size(268, 55);
            this.panel_IDDeleteInput.TabIndex = 5;
            // 
            // textBox_IDDeleteInput
            // 
            this.textBox_IDDeleteInput.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(221)))), ((int)(((byte)(222)))), ((int)(((byte)(238)))));
            this.textBox_IDDeleteInput.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox_IDDeleteInput.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox_IDDeleteInput.Location = new System.Drawing.Point(3, 11);
            this.textBox_IDDeleteInput.Margin = new System.Windows.Forms.Padding(4);
            this.textBox_IDDeleteInput.Name = "textBox_IDDeleteInput";
            this.textBox_IDDeleteInput.Size = new System.Drawing.Size(261, 32);
            this.textBox_IDDeleteInput.TabIndex = 2;
            // 
            // button_SaveDelete
            // 
            this.button_SaveDelete.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(111)))), ((int)(((byte)(51)))));
            this.button_SaveDelete.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button_SaveDelete.FlatAppearance.BorderSize = 0;
            this.button_SaveDelete.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_SaveDelete.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_SaveDelete.Location = new System.Drawing.Point(21, 196);
            this.button_SaveDelete.Margin = new System.Windows.Forms.Padding(4);
            this.button_SaveDelete.Name = "button_SaveDelete";
            this.button_SaveDelete.Size = new System.Drawing.Size(128, 59);
            this.button_SaveDelete.TabIndex = 21;
            this.button_SaveDelete.Text = "Delete";
            this.button_SaveDelete.UseVisualStyleBackColor = false;
            this.button_SaveDelete.Click += new System.EventHandler(this.button_SaveDelete_Click);
            // 
            // label_ID
            // 
            this.label_ID.AutoSize = true;
            this.label_ID.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label_ID.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_ID.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label_ID.Location = new System.Drawing.Point(16, 70);
            this.label_ID.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_ID.Name = "label_ID";
            this.label_ID.Size = new System.Drawing.Size(54, 32);
            this.label_ID.TabIndex = 4;
            this.label_ID.Text = "ID *";
            // 
            // label_XoaNhanVien
            // 
            this.label_XoaNhanVien.AutoSize = true;
            this.label_XoaNhanVien.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label_XoaNhanVien.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_XoaNhanVien.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(95)))), ((int)(((byte)(105)))));
            this.label_XoaNhanVien.Location = new System.Drawing.Point(15, 23);
            this.label_XoaNhanVien.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_XoaNhanVien.Name = "label_XoaNhanVien";
            this.label_XoaNhanVien.Size = new System.Drawing.Size(152, 32);
            this.label_XoaNhanVien.TabIndex = 21;
            this.label_XoaNhanVien.Text = "Xóa Độc giả";
            // 
            // openFileDialog_Avatar
            // 
            this.openFileDialog_Avatar.FileName = "openFileDialog1";
            // 
            // ffc_ThemXoaDocGia
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1245, 846);
            this.Controls.Add(this.panel_ThemNhanVienFunction);
            this.Controls.Add(this.panel_XoaNhanVienFunction);
            this.ForeColor = System.Drawing.Color.White;
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "ffc_ThemXoaDocGia";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "FormThemXoaDocGia";
            this.panel_ThemNhanVienFunction.ResumeLayout(false);
            this.panel_ThemNhanVienFunction.PerformLayout();
            this.panel_LopInput.ResumeLayout(false);
            this.panel_LopInput.PerformLayout();
            this.panel_ChuyenNganhInput.ResumeLayout(false);
            this.panel_ChuyenNganhInput.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.guna2CirclePictureBox_Avatar)).EndInit();
            this.panel_GioiThieuInput.ResumeLayout(false);
            this.panel_GioiThieuInput.PerformLayout();
            this.panel_SoDienThoaiInput.ResumeLayout(false);
            this.panel_SoDienThoaiInput.PerformLayout();
            this.panel_GioiTinhInput.ResumeLayout(false);
            this.panel_NgaySinhInput.ResumeLayout(false);
            this.panel_HoVaTenInput.ResumeLayout(false);
            this.panel_HoVaTenInput.PerformLayout();
            this.panel_XoaNhanVienFunction.ResumeLayout(false);
            this.panel_XoaNhanVienFunction.PerformLayout();
            this.panel_IDDeleteInput.ResumeLayout(false);
            this.panel_IDDeleteInput.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel_ThemNhanVienFunction;
        private System.Windows.Forms.Label label_ThemDocGiaMoi;
        private System.Windows.Forms.Label label_NgaySinh;
        private System.Windows.Forms.Label label_GioiTinh;
        private System.Windows.Forms.Panel panel_HoVaTenInput;
        private System.Windows.Forms.TextBox textBox_HoVaTenInput;
        private System.Windows.Forms.Label label_HoVaTen;
        private System.Windows.Forms.Panel panel_GioiTinhInput;
        private System.Windows.Forms.ComboBox comboBox_GioiTinhInput;
        private System.Windows.Forms.Panel panel_SoDienThoaiInput;
        private System.Windows.Forms.TextBox textBox_SoDienThoaiInput;
        private System.Windows.Forms.Label label_SoDienThoai;
        private System.Windows.Forms.Button button_Upload;
        private System.Windows.Forms.Panel panel_GioiThieuInput;
        private System.Windows.Forms.TextBox textBox_GioiThieuInput;
        private System.Windows.Forms.Label label_GioiThieu;
        private System.Windows.Forms.Label label_Upload;
        private System.Windows.Forms.Button button_ResetInsert;
        private System.Windows.Forms.Button button_SaveInsert;
        private System.Windows.Forms.Panel panel_XoaNhanVienFunction;
        private System.Windows.Forms.Panel panel_IDDeleteInput;
        private System.Windows.Forms.TextBox textBox_IDDeleteInput;
        private System.Windows.Forms.Label label_ID;
        private System.Windows.Forms.Label label_XoaNhanVien;
        private System.Windows.Forms.Button button_ResetDelete;
        private System.Windows.Forms.Button button_SaveDelete;
        private System.Windows.Forms.Panel panel_NgaySinhInput;
        private System.Windows.Forms.DateTimePicker dateTimePicker_NgaySinhInput;
        private System.Windows.Forms.OpenFileDialog openFileDialog_Avatar;
        private Guna.UI2.WinForms.Guna2CirclePictureBox guna2CirclePictureBox_Avatar;
        private System.Windows.Forms.Panel panel_LopInput;
        private System.Windows.Forms.TextBox textBox_LopInput;
        private System.Windows.Forms.Label label_Lop;
        private System.Windows.Forms.Panel panel_ChuyenNganhInput;
        private System.Windows.Forms.TextBox textBox_ChuyenNganhInput;
        private System.Windows.Forms.Label label_ChuyenNganh;
    }
}