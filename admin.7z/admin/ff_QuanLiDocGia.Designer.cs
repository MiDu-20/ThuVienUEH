﻿namespace QuanLiThuVienUeh.admin
{
    partial class ff_QuanLiDocGia
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ff_QuanLiDocGia));
            this.button_Search = new System.Windows.Forms.Button();
            this.panel_SearchFunction = new System.Windows.Forms.Panel();
            this.panel_Main = new System.Windows.Forms.Panel();
            this.dataGridView_ThongTinDocGia = new System.Windows.Forms.DataGridView();
            this.panel_Null4 = new System.Windows.Forms.Panel();
            this.button_ReturnLastPage = new System.Windows.Forms.Button();
            this.button_ReturnFirstPage = new System.Windows.Forms.Button();
            this.label_Previous = new System.Windows.Forms.Label();
            this.button_ChangePage3 = new System.Windows.Forms.Button();
            this.button_ChangePage1 = new System.Windows.Forms.Button();
            this.label_Next = new System.Windows.Forms.Label();
            this.button_ChangePage2 = new System.Windows.Forms.Button();
            this.panel_Null3 = new System.Windows.Forms.Panel();
            this.panel_Search = new System.Windows.Forms.Panel();
            this.label_SearchName = new System.Windows.Forms.Label();
            this.textBox_SearchName = new System.Windows.Forms.TextBox();
            this.label_ThongTinDocGia = new System.Windows.Forms.Label();
            this.panel_Null1 = new System.Windows.Forms.Panel();
            this.panel_Null2 = new System.Windows.Forms.Panel();
            this.button_Add = new System.Windows.Forms.Button();
            this.panel_SearchFunction.SuspendLayout();
            this.panel_Main.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_ThongTinDocGia)).BeginInit();
            this.panel_Null4.SuspendLayout();
            this.panel_Null3.SuspendLayout();
            this.panel_Search.SuspendLayout();
            this.SuspendLayout();
            // 
            // button_Search
            // 
            this.button_Search.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.button_Search.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(95)))), ((int)(((byte)(105)))));
            this.button_Search.FlatAppearance.BorderSize = 0;
            this.button_Search.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_Search.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_Search.ForeColor = System.Drawing.Color.White;
            this.button_Search.Location = new System.Drawing.Point(1232, 57);
            this.button_Search.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.button_Search.Name = "button_Search";
            this.button_Search.Size = new System.Drawing.Size(207, 48);
            this.button_Search.TabIndex = 4;
            this.button_Search.Text = "SEARCH";
            this.button_Search.UseVisualStyleBackColor = false;
            // 
            // panel_SearchFunction
            // 
            this.panel_SearchFunction.BackColor = System.Drawing.Color.White;
            this.panel_SearchFunction.Controls.Add(this.panel_Main);
            this.panel_SearchFunction.Controls.Add(this.panel_Null1);
            this.panel_SearchFunction.Controls.Add(this.panel_Null2);
            this.panel_SearchFunction.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel_SearchFunction.Location = new System.Drawing.Point(0, 0);
            this.panel_SearchFunction.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.panel_SearchFunction.Name = "panel_SearchFunction";
            this.panel_SearchFunction.Size = new System.Drawing.Size(1508, 693);
            this.panel_SearchFunction.TabIndex = 1;
            // 
            // panel_Main
            // 
            this.panel_Main.Controls.Add(this.dataGridView_ThongTinDocGia);
            this.panel_Main.Controls.Add(this.panel_Null4);
            this.panel_Main.Controls.Add(this.panel_Null3);
            this.panel_Main.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel_Main.Location = new System.Drawing.Point(41, 0);
            this.panel_Main.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.panel_Main.Name = "panel_Main";
            this.panel_Main.Size = new System.Drawing.Size(1438, 693);
            this.panel_Main.TabIndex = 20;
            // 
            // dataGridView_ThongTinDocGia
            // 
            this.dataGridView_ThongTinDocGia.AllowUserToAddRows = false;
            this.dataGridView_ThongTinDocGia.AllowUserToDeleteRows = false;
            this.dataGridView_ThongTinDocGia.AllowUserToResizeColumns = false;
            this.dataGridView_ThongTinDocGia.AllowUserToResizeRows = false;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.White;
            this.dataGridView_ThongTinDocGia.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.dataGridView_ThongTinDocGia.BackgroundColor = System.Drawing.Color.White;
            this.dataGridView_ThongTinDocGia.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(111)))), ((int)(((byte)(51)))));
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.Color.White;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView_ThongTinDocGia.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            this.dataGridView_ThongTinDocGia.ColumnHeadersHeight = 40;
            this.dataGridView_ThongTinDocGia.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            this.dataGridView_ThongTinDocGia.Cursor = System.Windows.Forms.Cursors.Hand;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle3.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridView_ThongTinDocGia.DefaultCellStyle = dataGridViewCellStyle3;
            this.dataGridView_ThongTinDocGia.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridView_ThongTinDocGia.EnableHeadersVisualStyles = false;
            this.dataGridView_ThongTinDocGia.GridColor = System.Drawing.Color.White;
            this.dataGridView_ThongTinDocGia.Location = new System.Drawing.Point(0, 127);
            this.dataGridView_ThongTinDocGia.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.dataGridView_ThongTinDocGia.MultiSelect = false;
            this.dataGridView_ThongTinDocGia.Name = "dataGridView_ThongTinDocGia";
            this.dataGridView_ThongTinDocGia.ReadOnly = true;
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle4.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle4.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle4.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle4.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle4.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView_ThongTinDocGia.RowHeadersDefaultCellStyle = dataGridViewCellStyle4;
            this.dataGridView_ThongTinDocGia.RowHeadersVisible = false;
            this.dataGridView_ThongTinDocGia.RowHeadersWidth = 100;
            this.dataGridView_ThongTinDocGia.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            dataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle5.BackColor = System.Drawing.Color.DimGray;
            dataGridViewCellStyle5.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(95)))), ((int)(((byte)(105)))));
            this.dataGridView_ThongTinDocGia.RowsDefaultCellStyle = dataGridViewCellStyle5;
            this.dataGridView_ThongTinDocGia.RowTemplate.DefaultCellStyle.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.dataGridView_ThongTinDocGia.RowTemplate.DefaultCellStyle.BackColor = System.Drawing.Color.White;
            this.dataGridView_ThongTinDocGia.RowTemplate.Height = 24;
            this.dataGridView_ThongTinDocGia.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.CellSelect;
            this.dataGridView_ThongTinDocGia.Size = new System.Drawing.Size(1438, 491);
            this.dataGridView_ThongTinDocGia.TabIndex = 0;
            this.dataGridView_ThongTinDocGia.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView_ThongTinDocGia_CellContentClick);
            this.dataGridView_ThongTinDocGia.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView_ThongTinDocGia_CellDoubleClick);
            this.dataGridView_ThongTinDocGia.CellMouseEnter += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView_ThongTinDocGia_CellMouseEnter);
            this.dataGridView_ThongTinDocGia.CellMouseLeave += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView_ThongTinDocGia_CellMouseLeave);
            // 
            // panel_Null4
            // 
            this.panel_Null4.Controls.Add(this.button_ReturnLastPage);
            this.panel_Null4.Controls.Add(this.button_ReturnFirstPage);
            this.panel_Null4.Controls.Add(this.button_Add);
            this.panel_Null4.Controls.Add(this.label_Previous);
            this.panel_Null4.Controls.Add(this.button_ChangePage3);
            this.panel_Null4.Controls.Add(this.button_ChangePage1);
            this.panel_Null4.Controls.Add(this.label_Next);
            this.panel_Null4.Controls.Add(this.button_ChangePage2);
            this.panel_Null4.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel_Null4.Location = new System.Drawing.Point(0, 618);
            this.panel_Null4.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.panel_Null4.Name = "panel_Null4";
            this.panel_Null4.Size = new System.Drawing.Size(1438, 75);
            this.panel_Null4.TabIndex = 1;
            // 
            // button_ReturnLastPage
            // 
            this.button_ReturnLastPage.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.button_ReturnLastPage.BackColor = System.Drawing.Color.White;
            this.button_ReturnLastPage.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button_ReturnLastPage.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(111)))), ((int)(((byte)(51)))));
            this.button_ReturnLastPage.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(95)))), ((int)(((byte)(105)))));
            this.button_ReturnLastPage.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_ReturnLastPage.Font = new System.Drawing.Font("Segoe UI Black", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_ReturnLastPage.ForeColor = System.Drawing.Color.Black;
            this.button_ReturnLastPage.Location = new System.Drawing.Point(1317, 14);
            this.button_ReturnLastPage.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.button_ReturnLastPage.Name = "button_ReturnLastPage";
            this.button_ReturnLastPage.Size = new System.Drawing.Size(53, 49);
            this.button_ReturnLastPage.TabIndex = 19;
            this.button_ReturnLastPage.Text = ">>";
            this.button_ReturnLastPage.UseVisualStyleBackColor = false;
            this.button_ReturnLastPage.Click += new System.EventHandler(this.button_ReturnLastPage_Click);
            // 
            // button_ReturnFirstPage
            // 
            this.button_ReturnFirstPage.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.button_ReturnFirstPage.BackColor = System.Drawing.Color.White;
            this.button_ReturnFirstPage.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button_ReturnFirstPage.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(111)))), ((int)(((byte)(51)))));
            this.button_ReturnFirstPage.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(95)))), ((int)(((byte)(105)))));
            this.button_ReturnFirstPage.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_ReturnFirstPage.Font = new System.Drawing.Font("Segoe UI Black", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_ReturnFirstPage.ForeColor = System.Drawing.Color.Black;
            this.button_ReturnFirstPage.Location = new System.Drawing.Point(1004, 14);
            this.button_ReturnFirstPage.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.button_ReturnFirstPage.Name = "button_ReturnFirstPage";
            this.button_ReturnFirstPage.Size = new System.Drawing.Size(53, 49);
            this.button_ReturnFirstPage.TabIndex = 18;
            this.button_ReturnFirstPage.Text = "<<";
            this.button_ReturnFirstPage.UseVisualStyleBackColor = false;
            this.button_ReturnFirstPage.Click += new System.EventHandler(this.button_ReturnFirstPage_Click);
            // 
            // label_Previous
            // 
            this.label_Previous.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.label_Previous.AutoSize = true;
            this.label_Previous.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label_Previous.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_Previous.Location = new System.Drawing.Point(885, 23);
            this.label_Previous.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_Previous.Name = "label_Previous";
            this.label_Previous.Size = new System.Drawing.Size(104, 32);
            this.label_Previous.TabIndex = 12;
            this.label_Previous.Text = "Previous";
            // 
            // button_ChangePage3
            // 
            this.button_ChangePage3.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.button_ChangePage3.BackColor = System.Drawing.Color.White;
            this.button_ChangePage3.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button_ChangePage3.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(111)))), ((int)(((byte)(51)))));
            this.button_ChangePage3.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(95)))), ((int)(((byte)(105)))));
            this.button_ChangePage3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_ChangePage3.Font = new System.Drawing.Font("Segoe UI Semibold", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_ChangePage3.ForeColor = System.Drawing.Color.Black;
            this.button_ChangePage3.Location = new System.Drawing.Point(1240, 14);
            this.button_ChangePage3.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.button_ChangePage3.Name = "button_ChangePage3";
            this.button_ChangePage3.Size = new System.Drawing.Size(53, 49);
            this.button_ChangePage3.TabIndex = 17;
            this.button_ChangePage3.Text = "3";
            this.button_ChangePage3.UseVisualStyleBackColor = false;
            this.button_ChangePage3.Click += new System.EventHandler(this.button_ChangePage3_Click);
            // 
            // button_ChangePage1
            // 
            this.button_ChangePage1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.button_ChangePage1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(95)))), ((int)(((byte)(105)))));
            this.button_ChangePage1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button_ChangePage1.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(111)))), ((int)(((byte)(51)))));
            this.button_ChangePage1.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(95)))), ((int)(((byte)(105)))));
            this.button_ChangePage1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_ChangePage1.Font = new System.Drawing.Font("Segoe UI Semibold", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_ChangePage1.ForeColor = System.Drawing.Color.White;
            this.button_ChangePage1.Location = new System.Drawing.Point(1084, 14);
            this.button_ChangePage1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.button_ChangePage1.Name = "button_ChangePage1";
            this.button_ChangePage1.Size = new System.Drawing.Size(53, 49);
            this.button_ChangePage1.TabIndex = 13;
            this.button_ChangePage1.Text = "1";
            this.button_ChangePage1.UseVisualStyleBackColor = false;
            this.button_ChangePage1.Click += new System.EventHandler(this.button_ChangePage1_Click);
            // 
            // label_Next
            // 
            this.label_Next.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.label_Next.AutoSize = true;
            this.label_Next.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label_Next.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_Next.Location = new System.Drawing.Point(1377, 23);
            this.label_Next.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_Next.Name = "label_Next";
            this.label_Next.Size = new System.Drawing.Size(64, 32);
            this.label_Next.TabIndex = 16;
            this.label_Next.Text = "Next";
            // 
            // button_ChangePage2
            // 
            this.button_ChangePage2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.button_ChangePage2.BackColor = System.Drawing.Color.White;
            this.button_ChangePage2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button_ChangePage2.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(111)))), ((int)(((byte)(51)))));
            this.button_ChangePage2.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(95)))), ((int)(((byte)(105)))));
            this.button_ChangePage2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_ChangePage2.Font = new System.Drawing.Font("Segoe UI Semibold", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_ChangePage2.ForeColor = System.Drawing.Color.Black;
            this.button_ChangePage2.Location = new System.Drawing.Point(1162, 14);
            this.button_ChangePage2.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.button_ChangePage2.Name = "button_ChangePage2";
            this.button_ChangePage2.Size = new System.Drawing.Size(53, 49);
            this.button_ChangePage2.TabIndex = 14;
            this.button_ChangePage2.Text = "2";
            this.button_ChangePage2.UseVisualStyleBackColor = false;
            this.button_ChangePage2.Click += new System.EventHandler(this.button_ChangePage2_Click);
            // 
            // panel_Null3
            // 
            this.panel_Null3.Controls.Add(this.panel_Search);
            this.panel_Null3.Controls.Add(this.button_Search);
            this.panel_Null3.Controls.Add(this.label_ThongTinDocGia);
            this.panel_Null3.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel_Null3.Location = new System.Drawing.Point(0, 0);
            this.panel_Null3.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.panel_Null3.Name = "panel_Null3";
            this.panel_Null3.Size = new System.Drawing.Size(1438, 127);
            this.panel_Null3.TabIndex = 0;
            // 
            // panel_Search
            // 
            this.panel_Search.BackColor = System.Drawing.Color.Gainsboro;
            this.panel_Search.Controls.Add(this.label_SearchName);
            this.panel_Search.Controls.Add(this.textBox_SearchName);
            this.panel_Search.Location = new System.Drawing.Point(0, 58);
            this.panel_Search.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.panel_Search.Name = "panel_Search";
            this.panel_Search.Size = new System.Drawing.Size(640, 48);
            this.panel_Search.TabIndex = 9;
            // 
            // label_SearchName
            // 
            this.label_SearchName.AutoSize = true;
            this.label_SearchName.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.label_SearchName.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_SearchName.ForeColor = System.Drawing.Color.DimGray;
            this.label_SearchName.Location = new System.Drawing.Point(16, 10);
            this.label_SearchName.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_SearchName.Name = "label_SearchName";
            this.label_SearchName.Size = new System.Drawing.Size(162, 28);
            this.label_SearchName.TabIndex = 10;
            this.label_SearchName.Text = "Search by name...";
            this.label_SearchName.Click += new System.EventHandler(this.label_SearchName_Click);
            // 
            // textBox_SearchName
            // 
            this.textBox_SearchName.BackColor = System.Drawing.Color.Gainsboro;
            this.textBox_SearchName.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox_SearchName.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox_SearchName.Location = new System.Drawing.Point(3, 10);
            this.textBox_SearchName.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.textBox_SearchName.Name = "textBox_SearchName";
            this.textBox_SearchName.Size = new System.Drawing.Size(447, 27);
            this.textBox_SearchName.TabIndex = 7;
            this.textBox_SearchName.Click += new System.EventHandler(this.textBox_SearchName_Click);
            this.textBox_SearchName.TextChanged += new System.EventHandler(this.textBox_SearchName_TextChanged);
            // 
            // label_ThongTinDocGia
            // 
            this.label_ThongTinDocGia.AutoSize = true;
            this.label_ThongTinDocGia.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_ThongTinDocGia.Location = new System.Drawing.Point(-7, 11);
            this.label_ThongTinDocGia.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_ThongTinDocGia.Name = "label_ThongTinDocGia";
            this.label_ThongTinDocGia.Size = new System.Drawing.Size(270, 37);
            this.label_ThongTinDocGia.TabIndex = 6;
            this.label_ThongTinDocGia.Text = "THÔNG TIN ĐỘC GIẢ";
            this.label_ThongTinDocGia.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // panel_Null1
            // 
            this.panel_Null1.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel_Null1.Location = new System.Drawing.Point(0, 0);
            this.panel_Null1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.panel_Null1.Name = "panel_Null1";
            this.panel_Null1.Size = new System.Drawing.Size(41, 693);
            this.panel_Null1.TabIndex = 18;
            // 
            // panel_Null2
            // 
            this.panel_Null2.Dock = System.Windows.Forms.DockStyle.Right;
            this.panel_Null2.Location = new System.Drawing.Point(1479, 0);
            this.panel_Null2.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.panel_Null2.Name = "panel_Null2";
            this.panel_Null2.Size = new System.Drawing.Size(29, 693);
            this.panel_Null2.TabIndex = 19;
            // 
            // button_Add
            // 
            this.button_Add.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.button_Add.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button_Add.FlatAppearance.BorderSize = 0;
            this.button_Add.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_Add.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_Add.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(95)))), ((int)(((byte)(105)))));
            this.button_Add.Image = ((System.Drawing.Image)(resources.GetObject("button_Add.Image")));
            this.button_Add.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button_Add.Location = new System.Drawing.Point(0, 14);
            this.button_Add.Margin = new System.Windows.Forms.Padding(4);
            this.button_Add.Name = "button_Add";
            this.button_Add.Size = new System.Drawing.Size(231, 49);
            this.button_Add.TabIndex = 11;
            this.button_Add.Text = "      Insert/ Delete";
            this.button_Add.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button_Add.UseVisualStyleBackColor = true;
            this.button_Add.Click += new System.EventHandler(this.button_Add_Click);
            // 
            // ff_QuanLiDocGia
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1508, 693);
            this.Controls.Add(this.panel_SearchFunction);
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Name = "ff_QuanLiDocGia";
            this.Text = "FormQuanLiDocGia";
            this.Resize += new System.EventHandler(this.FormThongTinNhanVien_Resize);
            this.panel_SearchFunction.ResumeLayout(false);
            this.panel_Main.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_ThongTinDocGia)).EndInit();
            this.panel_Null4.ResumeLayout(false);
            this.panel_Null4.PerformLayout();
            this.panel_Null3.ResumeLayout(false);
            this.panel_Null3.PerformLayout();
            this.panel_Search.ResumeLayout(false);
            this.panel_Search.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Button button_Search;
        private System.Windows.Forms.Panel panel_SearchFunction;
        private System.Windows.Forms.Label label_ThongTinDocGia;
        private System.Windows.Forms.Panel panel_Search;
        private System.Windows.Forms.TextBox textBox_SearchName;
        private System.Windows.Forms.Label label_SearchName;
        private System.Windows.Forms.Button button_ChangePage3;
        private System.Windows.Forms.Label label_Next;
        private System.Windows.Forms.Button button_ChangePage2;
        private System.Windows.Forms.Button button_ChangePage1;
        private System.Windows.Forms.Label label_Previous;
        private System.Windows.Forms.Button button_Add;
        private System.Windows.Forms.Panel panel_Null2;
        private System.Windows.Forms.Panel panel_Null1;
        private System.Windows.Forms.Panel panel_Main;
        private System.Windows.Forms.Panel panel_Null4;
        private System.Windows.Forms.Panel panel_Null3;
        private System.Windows.Forms.DataGridView dataGridView_ThongTinDocGia;
        private System.Windows.Forms.Button button_ReturnLastPage;
        private System.Windows.Forms.Button button_ReturnFirstPage;
    }
}