﻿namespace QuanLiThuVienUeh.admin
{
    partial class ffc_ThemXoaSach
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel_ThemNhanVienFunction = new System.Windows.Forms.Panel();
            this.panel_TheLoaiInsertInput = new System.Windows.Forms.Panel();
            this.label_TheLoaiInsertInput = new System.Windows.Forms.Label();
            this.panel_NhaXuatBanInsertInput = new System.Windows.Forms.Panel();
            this.label_NhaXuatBanInsertInput = new System.Windows.Forms.Label();
            this.panel_SoLuongInsertInput = new System.Windows.Forms.Panel();
            this.textBox_SoLuongInsertInput = new System.Windows.Forms.TextBox();
            this.textBox_SoLuongUpdateInput = new System.Windows.Forms.TextBox();
            this.label_SoLuongInsertInput = new System.Windows.Forms.Label();
            this.panel_NamXuatBanInsertInput = new System.Windows.Forms.Panel();
            this.dateTimePicker_NamXuatBanInsertInput = new System.Windows.Forms.DateTimePicker();
            this.label_NamXuatBanInsertInput = new System.Windows.Forms.Label();
            this.panel_TacGiaInsertInput = new System.Windows.Forms.Panel();
            this.textBox_TacGiaInsertInput = new System.Windows.Forms.TextBox();
            this.label_TacGiaInsertInput = new System.Windows.Forms.Label();
            this.button_ResetInsert = new System.Windows.Forms.Button();
            this.button_SaveInsert = new System.Windows.Forms.Button();
            this.label_Upload = new System.Windows.Forms.Label();
            this.button_Upload = new System.Windows.Forms.Button();
            this.panel_GioiThieuInput = new System.Windows.Forms.Panel();
            this.textBox_GioiThieuInput = new System.Windows.Forms.TextBox();
            this.label_GioiThieu = new System.Windows.Forms.Label();
            this.pictureBox_Avatar = new System.Windows.Forms.PictureBox();
            this.panel_TenSachInsertInput = new System.Windows.Forms.Panel();
            this.textBox_TenSachInsertInput = new System.Windows.Forms.TextBox();
            this.label_TenSachInsertInput = new System.Windows.Forms.Label();
            this.label_ThemSachMoi = new System.Windows.Forms.Label();
            this.panel_XoaNhanVienFunction = new System.Windows.Forms.Panel();
            this.button_ResetDelete = new System.Windows.Forms.Button();
            this.panel_IDSachDeleteInput = new System.Windows.Forms.Panel();
            this.textBox_IDSachDeleteInput = new System.Windows.Forms.TextBox();
            this.button_SaveDelete = new System.Windows.Forms.Button();
            this.label_IDSachDeleteInput = new System.Windows.Forms.Label();
            this.label_XoaSach = new System.Windows.Forms.Label();
            this.openFileDialog_Avatar = new System.Windows.Forms.OpenFileDialog();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.comboBox2 = new System.Windows.Forms.ComboBox();
            this.panel_ThemNhanVienFunction.SuspendLayout();
            this.panel_TheLoaiInsertInput.SuspendLayout();
            this.panel_NhaXuatBanInsertInput.SuspendLayout();
            this.panel_SoLuongInsertInput.SuspendLayout();
            this.panel_NamXuatBanInsertInput.SuspendLayout();
            this.panel_TacGiaInsertInput.SuspendLayout();
            this.panel_GioiThieuInput.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_Avatar)).BeginInit();
            this.panel_TenSachInsertInput.SuspendLayout();
            this.panel_XoaNhanVienFunction.SuspendLayout();
            this.panel_IDSachDeleteInput.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel_ThemNhanVienFunction
            // 
            this.panel_ThemNhanVienFunction.BackColor = System.Drawing.Color.White;
            this.panel_ThemNhanVienFunction.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel_ThemNhanVienFunction.Controls.Add(this.panel_TheLoaiInsertInput);
            this.panel_ThemNhanVienFunction.Controls.Add(this.label_TheLoaiInsertInput);
            this.panel_ThemNhanVienFunction.Controls.Add(this.panel_NhaXuatBanInsertInput);
            this.panel_ThemNhanVienFunction.Controls.Add(this.label_NhaXuatBanInsertInput);
            this.panel_ThemNhanVienFunction.Controls.Add(this.panel_SoLuongInsertInput);
            this.panel_ThemNhanVienFunction.Controls.Add(this.label_SoLuongInsertInput);
            this.panel_ThemNhanVienFunction.Controls.Add(this.panel_NamXuatBanInsertInput);
            this.panel_ThemNhanVienFunction.Controls.Add(this.label_NamXuatBanInsertInput);
            this.panel_ThemNhanVienFunction.Controls.Add(this.panel_TacGiaInsertInput);
            this.panel_ThemNhanVienFunction.Controls.Add(this.label_TacGiaInsertInput);
            this.panel_ThemNhanVienFunction.Controls.Add(this.button_ResetInsert);
            this.panel_ThemNhanVienFunction.Controls.Add(this.button_SaveInsert);
            this.panel_ThemNhanVienFunction.Controls.Add(this.label_Upload);
            this.panel_ThemNhanVienFunction.Controls.Add(this.button_Upload);
            this.panel_ThemNhanVienFunction.Controls.Add(this.panel_GioiThieuInput);
            this.panel_ThemNhanVienFunction.Controls.Add(this.label_GioiThieu);
            this.panel_ThemNhanVienFunction.Controls.Add(this.pictureBox_Avatar);
            this.panel_ThemNhanVienFunction.Controls.Add(this.panel_TenSachInsertInput);
            this.panel_ThemNhanVienFunction.Controls.Add(this.label_TenSachInsertInput);
            this.panel_ThemNhanVienFunction.Controls.Add(this.label_ThemSachMoi);
            this.panel_ThemNhanVienFunction.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel_ThemNhanVienFunction.Location = new System.Drawing.Point(0, 0);
            this.panel_ThemNhanVienFunction.Margin = new System.Windows.Forms.Padding(4);
            this.panel_ThemNhanVienFunction.Name = "panel_ThemNhanVienFunction";
            this.panel_ThemNhanVienFunction.Size = new System.Drawing.Size(1291, 594);
            this.panel_ThemNhanVienFunction.TabIndex = 0;
            // 
            // panel_TheLoaiInsertInput
            // 
            this.panel_TheLoaiInsertInput.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(221)))), ((int)(((byte)(222)))), ((int)(((byte)(238)))));
            this.panel_TheLoaiInsertInput.Controls.Add(this.comboBox1);
            this.panel_TheLoaiInsertInput.ForeColor = System.Drawing.SystemColors.Control;
            this.panel_TheLoaiInsertInput.Location = new System.Drawing.Point(935, 96);
            this.panel_TheLoaiInsertInput.Margin = new System.Windows.Forms.Padding(4);
            this.panel_TheLoaiInsertInput.Name = "panel_TheLoaiInsertInput";
            this.panel_TheLoaiInsertInput.Size = new System.Drawing.Size(320, 55);
            this.panel_TheLoaiInsertInput.TabIndex = 67;
            // 
            // label_TheLoaiInsertInput
            // 
            this.label_TheLoaiInsertInput.AutoSize = true;
            this.label_TheLoaiInsertInput.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label_TheLoaiInsertInput.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_TheLoaiInsertInput.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label_TheLoaiInsertInput.Location = new System.Drawing.Point(929, 62);
            this.label_TheLoaiInsertInput.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_TheLoaiInsertInput.Name = "label_TheLoaiInsertInput";
            this.label_TheLoaiInsertInput.Size = new System.Drawing.Size(116, 32);
            this.label_TheLoaiInsertInput.TabIndex = 66;
            this.label_TheLoaiInsertInput.Text = "Thể loại *";
            // 
            // panel_NhaXuatBanInsertInput
            // 
            this.panel_NhaXuatBanInsertInput.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(221)))), ((int)(((byte)(222)))), ((int)(((byte)(238)))));
            this.panel_NhaXuatBanInsertInput.Controls.Add(this.comboBox2);
            this.panel_NhaXuatBanInsertInput.ForeColor = System.Drawing.SystemColors.Control;
            this.panel_NhaXuatBanInsertInput.Location = new System.Drawing.Point(459, 238);
            this.panel_NhaXuatBanInsertInput.Margin = new System.Windows.Forms.Padding(4);
            this.panel_NhaXuatBanInsertInput.Name = "panel_NhaXuatBanInsertInput";
            this.panel_NhaXuatBanInsertInput.Size = new System.Drawing.Size(363, 55);
            this.panel_NhaXuatBanInsertInput.TabIndex = 58;
            // 
            // label_NhaXuatBanInsertInput
            // 
            this.label_NhaXuatBanInsertInput.AutoSize = true;
            this.label_NhaXuatBanInsertInput.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label_NhaXuatBanInsertInput.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_NhaXuatBanInsertInput.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label_NhaXuatBanInsertInput.Location = new System.Drawing.Point(453, 203);
            this.label_NhaXuatBanInsertInput.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_NhaXuatBanInsertInput.Name = "label_NhaXuatBanInsertInput";
            this.label_NhaXuatBanInsertInput.Size = new System.Drawing.Size(174, 32);
            this.label_NhaXuatBanInsertInput.TabIndex = 55;
            this.label_NhaXuatBanInsertInput.Text = "Nhà xuất bản *";
            // 
            // panel_SoLuongInsertInput
            // 
            this.panel_SoLuongInsertInput.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(221)))), ((int)(((byte)(222)))), ((int)(((byte)(238)))));
            this.panel_SoLuongInsertInput.Controls.Add(this.textBox_SoLuongInsertInput);
            this.panel_SoLuongInsertInput.Controls.Add(this.textBox_SoLuongUpdateInput);
            this.panel_SoLuongInsertInput.ForeColor = System.Drawing.SystemColors.Control;
            this.panel_SoLuongInsertInput.Location = new System.Drawing.Point(24, 238);
            this.panel_SoLuongInsertInput.Margin = new System.Windows.Forms.Padding(4);
            this.panel_SoLuongInsertInput.Name = "panel_SoLuongInsertInput";
            this.panel_SoLuongInsertInput.Size = new System.Drawing.Size(215, 55);
            this.panel_SoLuongInsertInput.TabIndex = 59;
            // 
            // textBox_SoLuongInsertInput
            // 
            this.textBox_SoLuongInsertInput.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(221)))), ((int)(((byte)(222)))), ((int)(((byte)(238)))));
            this.textBox_SoLuongInsertInput.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox_SoLuongInsertInput.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox_SoLuongInsertInput.Location = new System.Drawing.Point(1, 11);
            this.textBox_SoLuongInsertInput.Margin = new System.Windows.Forms.Padding(4);
            this.textBox_SoLuongInsertInput.Name = "textBox_SoLuongInsertInput";
            this.textBox_SoLuongInsertInput.Size = new System.Drawing.Size(209, 32);
            this.textBox_SoLuongInsertInput.TabIndex = 3;
            this.textBox_SoLuongInsertInput.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBox_SoLuongInsertInput_KeyPress);
            // 
            // textBox_SoLuongUpdateInput
            // 
            this.textBox_SoLuongUpdateInput.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(221)))), ((int)(((byte)(222)))), ((int)(((byte)(238)))));
            this.textBox_SoLuongUpdateInput.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox_SoLuongUpdateInput.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox_SoLuongUpdateInput.Location = new System.Drawing.Point(3, 12);
            this.textBox_SoLuongUpdateInput.Margin = new System.Windows.Forms.Padding(4);
            this.textBox_SoLuongUpdateInput.Name = "textBox_SoLuongUpdateInput";
            this.textBox_SoLuongUpdateInput.Size = new System.Drawing.Size(105, 32);
            this.textBox_SoLuongUpdateInput.TabIndex = 2;
            // 
            // label_SoLuongInsertInput
            // 
            this.label_SoLuongInsertInput.AutoSize = true;
            this.label_SoLuongInsertInput.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label_SoLuongInsertInput.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_SoLuongInsertInput.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label_SoLuongInsertInput.Location = new System.Drawing.Point(19, 203);
            this.label_SoLuongInsertInput.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_SoLuongInsertInput.Name = "label_SoLuongInsertInput";
            this.label_SoLuongInsertInput.Size = new System.Drawing.Size(127, 32);
            this.label_SoLuongInsertInput.TabIndex = 56;
            this.label_SoLuongInsertInput.Text = "Số lượng *";
            // 
            // panel_NamXuatBanInsertInput
            // 
            this.panel_NamXuatBanInsertInput.BackColor = System.Drawing.Color.White;
            this.panel_NamXuatBanInsertInput.Controls.Add(this.dateTimePicker_NamXuatBanInsertInput);
            this.panel_NamXuatBanInsertInput.ForeColor = System.Drawing.SystemColors.Control;
            this.panel_NamXuatBanInsertInput.Location = new System.Drawing.Point(947, 238);
            this.panel_NamXuatBanInsertInput.Margin = new System.Windows.Forms.Padding(4);
            this.panel_NamXuatBanInsertInput.Name = "panel_NamXuatBanInsertInput";
            this.panel_NamXuatBanInsertInput.Size = new System.Drawing.Size(308, 55);
            this.panel_NamXuatBanInsertInput.TabIndex = 65;
            // 
            // dateTimePicker_NamXuatBanInsertInput
            // 
            this.dateTimePicker_NamXuatBanInsertInput.CalendarForeColor = System.Drawing.Color.White;
            this.dateTimePicker_NamXuatBanInsertInput.CalendarTitleBackColor = System.Drawing.Color.White;
            this.dateTimePicker_NamXuatBanInsertInput.CustomFormat = "dd/MM/yyyy";
            this.dateTimePicker_NamXuatBanInsertInput.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dateTimePicker_NamXuatBanInsertInput.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dateTimePicker_NamXuatBanInsertInput.Location = new System.Drawing.Point(1, 7);
            this.dateTimePicker_NamXuatBanInsertInput.Margin = new System.Windows.Forms.Padding(4);
            this.dateTimePicker_NamXuatBanInsertInput.Name = "dateTimePicker_NamXuatBanInsertInput";
            this.dateTimePicker_NamXuatBanInsertInput.Size = new System.Drawing.Size(305, 39);
            this.dateTimePicker_NamXuatBanInsertInput.TabIndex = 3;
            this.dateTimePicker_NamXuatBanInsertInput.Value = new System.DateTime(2024, 3, 8, 0, 0, 0, 0);
            this.dateTimePicker_NamXuatBanInsertInput.ValueChanged += new System.EventHandler(this.dateTimePicker_NamXuatBanInsertInput_ValueChanged);
            // 
            // label_NamXuatBanInsertInput
            // 
            this.label_NamXuatBanInsertInput.AutoSize = true;
            this.label_NamXuatBanInsertInput.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label_NamXuatBanInsertInput.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_NamXuatBanInsertInput.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label_NamXuatBanInsertInput.Location = new System.Drawing.Point(941, 202);
            this.label_NamXuatBanInsertInput.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_NamXuatBanInsertInput.Name = "label_NamXuatBanInsertInput";
            this.label_NamXuatBanInsertInput.Size = new System.Drawing.Size(181, 32);
            this.label_NamXuatBanInsertInput.TabIndex = 64;
            this.label_NamXuatBanInsertInput.Text = "Năm xuất bản *";
            // 
            // panel_TacGiaInsertInput
            // 
            this.panel_TacGiaInsertInput.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(221)))), ((int)(((byte)(222)))), ((int)(((byte)(238)))));
            this.panel_TacGiaInsertInput.Controls.Add(this.textBox_TacGiaInsertInput);
            this.panel_TacGiaInsertInput.ForeColor = System.Drawing.SystemColors.Control;
            this.panel_TacGiaInsertInput.Location = new System.Drawing.Point(459, 96);
            this.panel_TacGiaInsertInput.Margin = new System.Windows.Forms.Padding(4);
            this.panel_TacGiaInsertInput.Name = "panel_TacGiaInsertInput";
            this.panel_TacGiaInsertInput.Size = new System.Drawing.Size(363, 55);
            this.panel_TacGiaInsertInput.TabIndex = 63;
            // 
            // textBox_TacGiaInsertInput
            // 
            this.textBox_TacGiaInsertInput.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(221)))), ((int)(((byte)(222)))), ((int)(((byte)(238)))));
            this.textBox_TacGiaInsertInput.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox_TacGiaInsertInput.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox_TacGiaInsertInput.Location = new System.Drawing.Point(3, 11);
            this.textBox_TacGiaInsertInput.Margin = new System.Windows.Forms.Padding(4);
            this.textBox_TacGiaInsertInput.Name = "textBox_TacGiaInsertInput";
            this.textBox_TacGiaInsertInput.Size = new System.Drawing.Size(356, 32);
            this.textBox_TacGiaInsertInput.TabIndex = 2;
            this.textBox_TacGiaInsertInput.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBox_TacGiaInsertInput_KeyPress);
            // 
            // label_TacGiaInsertInput
            // 
            this.label_TacGiaInsertInput.AutoSize = true;
            this.label_TacGiaInsertInput.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label_TacGiaInsertInput.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_TacGiaInsertInput.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label_TacGiaInsertInput.Location = new System.Drawing.Point(452, 62);
            this.label_TacGiaInsertInput.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_TacGiaInsertInput.Name = "label_TacGiaInsertInput";
            this.label_TacGiaInsertInput.Size = new System.Drawing.Size(103, 32);
            this.label_TacGiaInsertInput.TabIndex = 62;
            this.label_TacGiaInsertInput.Text = "Tác giả *";
            // 
            // button_ResetInsert
            // 
            this.button_ResetInsert.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(95)))), ((int)(((byte)(105)))));
            this.button_ResetInsert.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button_ResetInsert.FlatAppearance.BorderSize = 0;
            this.button_ResetInsert.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_ResetInsert.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_ResetInsert.Location = new System.Drawing.Point(1127, 486);
            this.button_ResetInsert.Margin = new System.Windows.Forms.Padding(4);
            this.button_ResetInsert.Name = "button_ResetInsert";
            this.button_ResetInsert.Size = new System.Drawing.Size(128, 59);
            this.button_ResetInsert.TabIndex = 20;
            this.button_ResetInsert.Text = "Reset";
            this.button_ResetInsert.UseVisualStyleBackColor = false;
            this.button_ResetInsert.Click += new System.EventHandler(this.button_ResetInsert_Click);
            // 
            // button_SaveInsert
            // 
            this.button_SaveInsert.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(111)))), ((int)(((byte)(51)))));
            this.button_SaveInsert.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button_SaveInsert.FlatAppearance.BorderSize = 0;
            this.button_SaveInsert.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_SaveInsert.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_SaveInsert.Location = new System.Drawing.Point(991, 487);
            this.button_SaveInsert.Margin = new System.Windows.Forms.Padding(4);
            this.button_SaveInsert.Name = "button_SaveInsert";
            this.button_SaveInsert.Size = new System.Drawing.Size(128, 59);
            this.button_SaveInsert.TabIndex = 19;
            this.button_SaveInsert.Text = "Save";
            this.button_SaveInsert.UseVisualStyleBackColor = false;
            this.button_SaveInsert.Click += new System.EventHandler(this.button_SaveInsert_Click);
            // 
            // label_Upload
            // 
            this.label_Upload.AutoSize = true;
            this.label_Upload.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label_Upload.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_Upload.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label_Upload.Location = new System.Drawing.Point(236, 358);
            this.label_Upload.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_Upload.Name = "label_Upload";
            this.label_Upload.Size = new System.Drawing.Size(161, 32);
            this.label_Upload.TabIndex = 18;
            this.label_Upload.Text = "Upload avatar";
            // 
            // button_Upload
            // 
            this.button_Upload.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(221)))), ((int)(((byte)(222)))), ((int)(((byte)(238)))));
            this.button_Upload.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.button_Upload.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.button_Upload.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.button_Upload.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_Upload.ForeColor = System.Drawing.Color.Black;
            this.button_Upload.Location = new System.Drawing.Point(240, 391);
            this.button_Upload.Margin = new System.Windows.Forms.Padding(4);
            this.button_Upload.Name = "button_Upload";
            this.button_Upload.Size = new System.Drawing.Size(168, 39);
            this.button_Upload.TabIndex = 17;
            this.button_Upload.Text = "Choose File";
            this.button_Upload.UseVisualStyleBackColor = false;
            this.button_Upload.Click += new System.EventHandler(this.button_Upload_Click);
            // 
            // panel_GioiThieuInput
            // 
            this.panel_GioiThieuInput.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(221)))), ((int)(((byte)(222)))), ((int)(((byte)(238)))));
            this.panel_GioiThieuInput.Controls.Add(this.textBox_GioiThieuInput);
            this.panel_GioiThieuInput.ForeColor = System.Drawing.SystemColors.Control;
            this.panel_GioiThieuInput.Location = new System.Drawing.Point(507, 358);
            this.panel_GioiThieuInput.Margin = new System.Windows.Forms.Padding(4);
            this.panel_GioiThieuInput.Name = "panel_GioiThieuInput";
            this.panel_GioiThieuInput.Size = new System.Drawing.Size(405, 187);
            this.panel_GioiThieuInput.TabIndex = 15;
            // 
            // textBox_GioiThieuInput
            // 
            this.textBox_GioiThieuInput.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(221)))), ((int)(((byte)(222)))), ((int)(((byte)(238)))));
            this.textBox_GioiThieuInput.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox_GioiThieuInput.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox_GioiThieuInput.Location = new System.Drawing.Point(3, 4);
            this.textBox_GioiThieuInput.Margin = new System.Windows.Forms.Padding(4);
            this.textBox_GioiThieuInput.Multiline = true;
            this.textBox_GioiThieuInput.Name = "textBox_GioiThieuInput";
            this.textBox_GioiThieuInput.Size = new System.Drawing.Size(399, 180);
            this.textBox_GioiThieuInput.TabIndex = 2;
            // 
            // label_GioiThieu
            // 
            this.label_GioiThieu.AutoSize = true;
            this.label_GioiThieu.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label_GioiThieu.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_GioiThieu.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label_GioiThieu.Location = new System.Drawing.Point(501, 316);
            this.label_GioiThieu.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_GioiThieu.Name = "label_GioiThieu";
            this.label_GioiThieu.Size = new System.Drawing.Size(118, 32);
            this.label_GioiThieu.TabIndex = 14;
            this.label_GioiThieu.Text = "Giới thiệu";
            // 
            // pictureBox_Avatar
            // 
            this.pictureBox_Avatar.Location = new System.Drawing.Point(21, 358);
            this.pictureBox_Avatar.Margin = new System.Windows.Forms.Padding(4);
            this.pictureBox_Avatar.Name = "pictureBox_Avatar";
            this.pictureBox_Avatar.Size = new System.Drawing.Size(207, 187);
            this.pictureBox_Avatar.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox_Avatar.TabIndex = 16;
            this.pictureBox_Avatar.TabStop = false;
            // 
            // panel_TenSachInsertInput
            // 
            this.panel_TenSachInsertInput.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(221)))), ((int)(((byte)(222)))), ((int)(((byte)(238)))));
            this.panel_TenSachInsertInput.Controls.Add(this.textBox_TenSachInsertInput);
            this.panel_TenSachInsertInput.ForeColor = System.Drawing.SystemColors.Control;
            this.panel_TenSachInsertInput.Location = new System.Drawing.Point(21, 96);
            this.panel_TenSachInsertInput.Margin = new System.Windows.Forms.Padding(4);
            this.panel_TenSachInsertInput.Name = "panel_TenSachInsertInput";
            this.panel_TenSachInsertInput.Size = new System.Drawing.Size(339, 55);
            this.panel_TenSachInsertInput.TabIndex = 3;
            // 
            // textBox_TenSachInsertInput
            // 
            this.textBox_TenSachInsertInput.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(221)))), ((int)(((byte)(222)))), ((int)(((byte)(238)))));
            this.textBox_TenSachInsertInput.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox_TenSachInsertInput.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox_TenSachInsertInput.Location = new System.Drawing.Point(3, 11);
            this.textBox_TenSachInsertInput.Margin = new System.Windows.Forms.Padding(4);
            this.textBox_TenSachInsertInput.Name = "textBox_TenSachInsertInput";
            this.textBox_TenSachInsertInput.Size = new System.Drawing.Size(332, 32);
            this.textBox_TenSachInsertInput.TabIndex = 2;
            // 
            // label_TenSachInsertInput
            // 
            this.label_TenSachInsertInput.AutoSize = true;
            this.label_TenSachInsertInput.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label_TenSachInsertInput.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_TenSachInsertInput.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label_TenSachInsertInput.Location = new System.Drawing.Point(16, 55);
            this.label_TenSachInsertInput.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_TenSachInsertInput.Name = "label_TenSachInsertInput";
            this.label_TenSachInsertInput.Size = new System.Drawing.Size(123, 32);
            this.label_TenSachInsertInput.TabIndex = 1;
            this.label_TenSachInsertInput.Text = "Tên sách *";
            // 
            // label_ThemSachMoi
            // 
            this.label_ThemSachMoi.AutoSize = true;
            this.label_ThemSachMoi.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label_ThemSachMoi.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_ThemSachMoi.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(95)))), ((int)(((byte)(105)))));
            this.label_ThemSachMoi.Location = new System.Drawing.Point(16, 11);
            this.label_ThemSachMoi.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_ThemSachMoi.Name = "label_ThemSachMoi";
            this.label_ThemSachMoi.Size = new System.Drawing.Size(187, 32);
            this.label_ThemSachMoi.TabIndex = 0;
            this.label_ThemSachMoi.Text = "Thêm Sách mới";
            // 
            // panel_XoaNhanVienFunction
            // 
            this.panel_XoaNhanVienFunction.BackColor = System.Drawing.Color.White;
            this.panel_XoaNhanVienFunction.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel_XoaNhanVienFunction.Controls.Add(this.button_ResetDelete);
            this.panel_XoaNhanVienFunction.Controls.Add(this.panel_IDSachDeleteInput);
            this.panel_XoaNhanVienFunction.Controls.Add(this.button_SaveDelete);
            this.panel_XoaNhanVienFunction.Controls.Add(this.label_IDSachDeleteInput);
            this.panel_XoaNhanVienFunction.Controls.Add(this.label_XoaSach);
            this.panel_XoaNhanVienFunction.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel_XoaNhanVienFunction.Location = new System.Drawing.Point(0, 594);
            this.panel_XoaNhanVienFunction.Margin = new System.Windows.Forms.Padding(4);
            this.panel_XoaNhanVienFunction.Name = "panel_XoaNhanVienFunction";
            this.panel_XoaNhanVienFunction.Size = new System.Drawing.Size(1291, 281);
            this.panel_XoaNhanVienFunction.TabIndex = 1;
            // 
            // button_ResetDelete
            // 
            this.button_ResetDelete.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(95)))), ((int)(((byte)(105)))));
            this.button_ResetDelete.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button_ResetDelete.FlatAppearance.BorderSize = 0;
            this.button_ResetDelete.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_ResetDelete.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_ResetDelete.Location = new System.Drawing.Point(181, 196);
            this.button_ResetDelete.Margin = new System.Windows.Forms.Padding(4);
            this.button_ResetDelete.Name = "button_ResetDelete";
            this.button_ResetDelete.Size = new System.Drawing.Size(128, 59);
            this.button_ResetDelete.TabIndex = 22;
            this.button_ResetDelete.Text = "Reset";
            this.button_ResetDelete.UseVisualStyleBackColor = false;
            this.button_ResetDelete.Click += new System.EventHandler(this.button_ResetDelete_Click);
            // 
            // panel_IDSachDeleteInput
            // 
            this.panel_IDSachDeleteInput.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(221)))), ((int)(((byte)(222)))), ((int)(((byte)(238)))));
            this.panel_IDSachDeleteInput.Controls.Add(this.textBox_IDSachDeleteInput);
            this.panel_IDSachDeleteInput.ForeColor = System.Drawing.SystemColors.Control;
            this.panel_IDSachDeleteInput.Location = new System.Drawing.Point(45, 112);
            this.panel_IDSachDeleteInput.Margin = new System.Windows.Forms.Padding(4);
            this.panel_IDSachDeleteInput.Name = "panel_IDSachDeleteInput";
            this.panel_IDSachDeleteInput.Size = new System.Drawing.Size(268, 55);
            this.panel_IDSachDeleteInput.TabIndex = 5;
            // 
            // textBox_IDSachDeleteInput
            // 
            this.textBox_IDSachDeleteInput.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(221)))), ((int)(((byte)(222)))), ((int)(((byte)(238)))));
            this.textBox_IDSachDeleteInput.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox_IDSachDeleteInput.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox_IDSachDeleteInput.Location = new System.Drawing.Point(3, 11);
            this.textBox_IDSachDeleteInput.Margin = new System.Windows.Forms.Padding(4);
            this.textBox_IDSachDeleteInput.Name = "textBox_IDSachDeleteInput";
            this.textBox_IDSachDeleteInput.Size = new System.Drawing.Size(261, 32);
            this.textBox_IDSachDeleteInput.TabIndex = 2;
            // 
            // button_SaveDelete
            // 
            this.button_SaveDelete.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(111)))), ((int)(((byte)(51)))));
            this.button_SaveDelete.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button_SaveDelete.FlatAppearance.BorderSize = 0;
            this.button_SaveDelete.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_SaveDelete.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_SaveDelete.Location = new System.Drawing.Point(45, 197);
            this.button_SaveDelete.Margin = new System.Windows.Forms.Padding(4);
            this.button_SaveDelete.Name = "button_SaveDelete";
            this.button_SaveDelete.Size = new System.Drawing.Size(128, 59);
            this.button_SaveDelete.TabIndex = 21;
            this.button_SaveDelete.Text = "Delete";
            this.button_SaveDelete.UseVisualStyleBackColor = false;
            this.button_SaveDelete.Click += new System.EventHandler(this.button_SaveDelete_Click);
            // 
            // label_IDSachDeleteInput
            // 
            this.label_IDSachDeleteInput.AutoSize = true;
            this.label_IDSachDeleteInput.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label_IDSachDeleteInput.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_IDSachDeleteInput.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label_IDSachDeleteInput.Location = new System.Drawing.Point(40, 71);
            this.label_IDSachDeleteInput.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_IDSachDeleteInput.Name = "label_IDSachDeleteInput";
            this.label_IDSachDeleteInput.Size = new System.Drawing.Size(111, 32);
            this.label_IDSachDeleteInput.TabIndex = 4;
            this.label_IDSachDeleteInput.Text = "ID Sách *";
            // 
            // label_XoaSach
            // 
            this.label_XoaSach.AutoSize = true;
            this.label_XoaSach.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label_XoaSach.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_XoaSach.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(95)))), ((int)(((byte)(105)))));
            this.label_XoaSach.Location = new System.Drawing.Point(39, 25);
            this.label_XoaSach.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_XoaSach.Name = "label_XoaSach";
            this.label_XoaSach.Size = new System.Drawing.Size(117, 32);
            this.label_XoaSach.TabIndex = 21;
            this.label_XoaSach.Text = "Xóa Sách";
            // 
            // openFileDialog_Avatar
            // 
            this.openFileDialog_Avatar.FileName = "openFileDialog1";
            // 
            // comboBox1
            // 
            this.comboBox1.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Location = new System.Drawing.Point(0, 11);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(317, 36);
            this.comboBox1.TabIndex = 0;
            // 
            // comboBox2
            // 
            this.comboBox2.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboBox2.FormattingEnabled = true;
            this.comboBox2.Location = new System.Drawing.Point(3, 8);
            this.comboBox2.Name = "comboBox2";
            this.comboBox2.Size = new System.Drawing.Size(360, 36);
            this.comboBox2.TabIndex = 1;
            // 
            // ffc_ThemXoaSach
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1291, 875);
            this.Controls.Add(this.panel_ThemNhanVienFunction);
            this.Controls.Add(this.panel_XoaNhanVienFunction);
            this.ForeColor = System.Drawing.Color.White;
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "ffc_ThemXoaSach";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form_ThemXoaSach";
            this.panel_ThemNhanVienFunction.ResumeLayout(false);
            this.panel_ThemNhanVienFunction.PerformLayout();
            this.panel_TheLoaiInsertInput.ResumeLayout(false);
            this.panel_NhaXuatBanInsertInput.ResumeLayout(false);
            this.panel_SoLuongInsertInput.ResumeLayout(false);
            this.panel_SoLuongInsertInput.PerformLayout();
            this.panel_NamXuatBanInsertInput.ResumeLayout(false);
            this.panel_TacGiaInsertInput.ResumeLayout(false);
            this.panel_TacGiaInsertInput.PerformLayout();
            this.panel_GioiThieuInput.ResumeLayout(false);
            this.panel_GioiThieuInput.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_Avatar)).EndInit();
            this.panel_TenSachInsertInput.ResumeLayout(false);
            this.panel_TenSachInsertInput.PerformLayout();
            this.panel_XoaNhanVienFunction.ResumeLayout(false);
            this.panel_XoaNhanVienFunction.PerformLayout();
            this.panel_IDSachDeleteInput.ResumeLayout(false);
            this.panel_IDSachDeleteInput.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel_ThemNhanVienFunction;
        private System.Windows.Forms.Label label_ThemSachMoi;
        private System.Windows.Forms.Panel panel_TenSachInsertInput;
        private System.Windows.Forms.TextBox textBox_TenSachInsertInput;
        private System.Windows.Forms.Label label_TenSachInsertInput;
        private System.Windows.Forms.Button button_Upload;
        private System.Windows.Forms.Panel panel_GioiThieuInput;
        private System.Windows.Forms.TextBox textBox_GioiThieuInput;
        private System.Windows.Forms.Label label_GioiThieu;
        private System.Windows.Forms.PictureBox pictureBox_Avatar;
        private System.Windows.Forms.Label label_Upload;
        private System.Windows.Forms.Button button_ResetInsert;
        private System.Windows.Forms.Button button_SaveInsert;
        private System.Windows.Forms.Panel panel_XoaNhanVienFunction;
        private System.Windows.Forms.Panel panel_IDSachDeleteInput;
        private System.Windows.Forms.TextBox textBox_IDSachDeleteInput;
        private System.Windows.Forms.Label label_IDSachDeleteInput;
        private System.Windows.Forms.Label label_XoaSach;
        private System.Windows.Forms.Button button_ResetDelete;
        private System.Windows.Forms.Button button_SaveDelete;
        private System.Windows.Forms.Panel panel_NhaXuatBanInsertInput;
        private System.Windows.Forms.Label label_NhaXuatBanInsertInput;
        private System.Windows.Forms.Panel panel_SoLuongInsertInput;
        private System.Windows.Forms.TextBox textBox_SoLuongUpdateInput;
        private System.Windows.Forms.Label label_SoLuongInsertInput;
        private System.Windows.Forms.Panel panel_NamXuatBanInsertInput;
        private System.Windows.Forms.DateTimePicker dateTimePicker_NamXuatBanInsertInput;
        private System.Windows.Forms.Label label_NamXuatBanInsertInput;
        private System.Windows.Forms.Panel panel_TacGiaInsertInput;
        private System.Windows.Forms.TextBox textBox_TacGiaInsertInput;
        private System.Windows.Forms.Label label_TacGiaInsertInput;
        private System.Windows.Forms.Panel panel_TheLoaiInsertInput;
        private System.Windows.Forms.Label label_TheLoaiInsertInput;
        private System.Windows.Forms.TextBox textBox_SoLuongInsertInput;
        private System.Windows.Forms.OpenFileDialog openFileDialog_Avatar;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.ComboBox comboBox2;
    }
}