﻿namespace QuanLiThuVienUeh.admin
{
    partial class ffc_ThongTinNhanVienChiTiet
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ffc_ThongTinNhanVienChiTiet));
            this.pictureBox_UehLogoIcon = new System.Windows.Forms.PictureBox();
            this.textBox_GioiThieu = new System.Windows.Forms.TextBox();
            this.label_NhanVienName = new System.Windows.Forms.Label();
            this.label_ID = new System.Windows.Forms.Label();
            this.label_GioiTinh = new System.Windows.Forms.Label();
            this.label_NgaySinh = new System.Windows.Forms.Label();
            this.label_Email = new System.Windows.Forms.Label();
            this.label_SoDienThoai = new System.Windows.Forms.Label();
            this.label_NgayNhanViec = new System.Windows.Forms.Label();
            this.label_IDInfo = new System.Windows.Forms.Label();
            this.label_GioiTinhInfo = new System.Windows.Forms.Label();
            this.label_NgaySinhInfo = new System.Windows.Forms.Label();
            this.label_EmailInfo = new System.Windows.Forms.Label();
            this.label_SoDienThoaiInfo = new System.Windows.Forms.Label();
            this.label_NgayNhanViecInfo = new System.Windows.Forms.Label();
            this.label_ChucVuInfo = new System.Windows.Forms.Label();
            this.label_ChucVu = new System.Windows.Forms.Label();
            this.guna2CirclePictureBox_Avatar = new Guna.UI2.WinForms.Guna2CirclePictureBox();
            this.button_ResetInsert = new System.Windows.Forms.Button();
            this.button_SaveInsert = new System.Windows.Forms.Button();
            this.button_Edit = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_UehLogoIcon)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.guna2CirclePictureBox_Avatar)).BeginInit();
            this.SuspendLayout();
            // 
            // pictureBox_UehLogoIcon
            // 
            this.pictureBox_UehLogoIcon.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox_UehLogoIcon.Image")));
            this.pictureBox_UehLogoIcon.Location = new System.Drawing.Point(48, 15);
            this.pictureBox_UehLogoIcon.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.pictureBox_UehLogoIcon.Name = "pictureBox_UehLogoIcon";
            this.pictureBox_UehLogoIcon.Size = new System.Drawing.Size(88, 58);
            this.pictureBox_UehLogoIcon.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox_UehLogoIcon.TabIndex = 2;
            this.pictureBox_UehLogoIcon.TabStop = false;
            // 
            // textBox_GioiThieu
            // 
            this.textBox_GioiThieu.BackColor = System.Drawing.Color.White;
            this.textBox_GioiThieu.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox_GioiThieu.Enabled = false;
            this.textBox_GioiThieu.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox_GioiThieu.ForeColor = System.Drawing.Color.Black;
            this.textBox_GioiThieu.Location = new System.Drawing.Point(356, 143);
            this.textBox_GioiThieu.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.textBox_GioiThieu.Multiline = true;
            this.textBox_GioiThieu.Name = "textBox_GioiThieu";
            this.textBox_GioiThieu.Size = new System.Drawing.Size(499, 121);
            this.textBox_GioiThieu.TabIndex = 3;
            this.textBox_GioiThieu.Text = "...";
            // 
            // label_NhanVienName
            // 
            this.label_NhanVienName.AutoSize = true;
            this.label_NhanVienName.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label_NhanVienName.Font = new System.Drawing.Font("Segoe UI Semibold", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_NhanVienName.ForeColor = System.Drawing.Color.MediumBlue;
            this.label_NhanVienName.Location = new System.Drawing.Point(353, 96);
            this.label_NhanVienName.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_NhanVienName.Name = "label_NhanVienName";
            this.label_NhanVienName.Size = new System.Drawing.Size(161, 32);
            this.label_NhanVienName.TabIndex = 5;
            this.label_NhanVienName.Text = "Đào Gia Phúc";
            this.label_NhanVienName.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label_ID
            // 
            this.label_ID.AutoSize = true;
            this.label_ID.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label_ID.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_ID.ForeColor = System.Drawing.Color.Black;
            this.label_ID.Location = new System.Drawing.Point(353, 267);
            this.label_ID.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_ID.Name = "label_ID";
            this.label_ID.Size = new System.Drawing.Size(42, 32);
            this.label_ID.TabIndex = 6;
            this.label_ID.Text = "ID:";
            // 
            // label_GioiTinh
            // 
            this.label_GioiTinh.AutoSize = true;
            this.label_GioiTinh.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label_GioiTinh.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_GioiTinh.ForeColor = System.Drawing.Color.Black;
            this.label_GioiTinh.Location = new System.Drawing.Point(353, 315);
            this.label_GioiTinh.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_GioiTinh.Name = "label_GioiTinh";
            this.label_GioiTinh.Size = new System.Drawing.Size(110, 32);
            this.label_GioiTinh.TabIndex = 8;
            this.label_GioiTinh.Text = "Giới tính:";
            // 
            // label_NgaySinh
            // 
            this.label_NgaySinh.AutoSize = true;
            this.label_NgaySinh.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label_NgaySinh.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_NgaySinh.ForeColor = System.Drawing.Color.Black;
            this.label_NgaySinh.Location = new System.Drawing.Point(353, 421);
            this.label_NgaySinh.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_NgaySinh.Name = "label_NgaySinh";
            this.label_NgaySinh.Size = new System.Drawing.Size(126, 32);
            this.label_NgaySinh.TabIndex = 9;
            this.label_NgaySinh.Text = "Ngày sinh:";
            // 
            // label_Email
            // 
            this.label_Email.AutoSize = true;
            this.label_Email.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label_Email.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_Email.ForeColor = System.Drawing.Color.Black;
            this.label_Email.Location = new System.Drawing.Point(353, 475);
            this.label_Email.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_Email.Name = "label_Email";
            this.label_Email.Size = new System.Drawing.Size(76, 32);
            this.label_Email.TabIndex = 10;
            this.label_Email.Text = "Email:";
            // 
            // label_SoDienThoai
            // 
            this.label_SoDienThoai.AutoSize = true;
            this.label_SoDienThoai.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label_SoDienThoai.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_SoDienThoai.ForeColor = System.Drawing.Color.Black;
            this.label_SoDienThoai.Location = new System.Drawing.Point(353, 526);
            this.label_SoDienThoai.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_SoDienThoai.Name = "label_SoDienThoai";
            this.label_SoDienThoai.Size = new System.Drawing.Size(161, 32);
            this.label_SoDienThoai.TabIndex = 11;
            this.label_SoDienThoai.Text = "Số điện thoại:";
            // 
            // label_NgayNhanViec
            // 
            this.label_NgayNhanViec.AutoSize = true;
            this.label_NgayNhanViec.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label_NgayNhanViec.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_NgayNhanViec.ForeColor = System.Drawing.Color.Black;
            this.label_NgayNhanViec.Location = new System.Drawing.Point(353, 580);
            this.label_NgayNhanViec.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_NgayNhanViec.Name = "label_NgayNhanViec";
            this.label_NgayNhanViec.Size = new System.Drawing.Size(185, 32);
            this.label_NgayNhanViec.TabIndex = 12;
            this.label_NgayNhanViec.Text = "Ngày nhận việc:";
            // 
            // label_IDInfo
            // 
            this.label_IDInfo.AutoSize = true;
            this.label_IDInfo.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label_IDInfo.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_IDInfo.ForeColor = System.Drawing.Color.Black;
            this.label_IDInfo.Location = new System.Drawing.Point(605, 267);
            this.label_IDInfo.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_IDInfo.Name = "label_IDInfo";
            this.label_IDInfo.Size = new System.Drawing.Size(29, 32);
            this.label_IDInfo.TabIndex = 13;
            this.label_IDInfo.Text = "...";
            // 
            // label_GioiTinhInfo
            // 
            this.label_GioiTinhInfo.AutoSize = true;
            this.label_GioiTinhInfo.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label_GioiTinhInfo.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_GioiTinhInfo.ForeColor = System.Drawing.Color.Black;
            this.label_GioiTinhInfo.Location = new System.Drawing.Point(605, 315);
            this.label_GioiTinhInfo.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_GioiTinhInfo.Name = "label_GioiTinhInfo";
            this.label_GioiTinhInfo.Size = new System.Drawing.Size(29, 32);
            this.label_GioiTinhInfo.TabIndex = 15;
            this.label_GioiTinhInfo.Text = "...";
            // 
            // label_NgaySinhInfo
            // 
            this.label_NgaySinhInfo.AutoSize = true;
            this.label_NgaySinhInfo.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label_NgaySinhInfo.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_NgaySinhInfo.ForeColor = System.Drawing.Color.Black;
            this.label_NgaySinhInfo.Location = new System.Drawing.Point(605, 421);
            this.label_NgaySinhInfo.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_NgaySinhInfo.Name = "label_NgaySinhInfo";
            this.label_NgaySinhInfo.Size = new System.Drawing.Size(29, 32);
            this.label_NgaySinhInfo.TabIndex = 16;
            this.label_NgaySinhInfo.Text = "...";
            // 
            // label_EmailInfo
            // 
            this.label_EmailInfo.AutoSize = true;
            this.label_EmailInfo.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label_EmailInfo.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_EmailInfo.ForeColor = System.Drawing.Color.Black;
            this.label_EmailInfo.Location = new System.Drawing.Point(605, 475);
            this.label_EmailInfo.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_EmailInfo.Name = "label_EmailInfo";
            this.label_EmailInfo.Size = new System.Drawing.Size(29, 32);
            this.label_EmailInfo.TabIndex = 17;
            this.label_EmailInfo.Text = "...";
            // 
            // label_SoDienThoaiInfo
            // 
            this.label_SoDienThoaiInfo.AutoSize = true;
            this.label_SoDienThoaiInfo.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label_SoDienThoaiInfo.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_SoDienThoaiInfo.ForeColor = System.Drawing.Color.Black;
            this.label_SoDienThoaiInfo.Location = new System.Drawing.Point(605, 526);
            this.label_SoDienThoaiInfo.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_SoDienThoaiInfo.Name = "label_SoDienThoaiInfo";
            this.label_SoDienThoaiInfo.Size = new System.Drawing.Size(29, 32);
            this.label_SoDienThoaiInfo.TabIndex = 18;
            this.label_SoDienThoaiInfo.Text = "...";
            // 
            // label_NgayNhanViecInfo
            // 
            this.label_NgayNhanViecInfo.AutoSize = true;
            this.label_NgayNhanViecInfo.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label_NgayNhanViecInfo.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_NgayNhanViecInfo.ForeColor = System.Drawing.Color.Black;
            this.label_NgayNhanViecInfo.Location = new System.Drawing.Point(605, 580);
            this.label_NgayNhanViecInfo.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_NgayNhanViecInfo.Name = "label_NgayNhanViecInfo";
            this.label_NgayNhanViecInfo.Size = new System.Drawing.Size(29, 32);
            this.label_NgayNhanViecInfo.TabIndex = 19;
            this.label_NgayNhanViecInfo.Text = "...";
            // 
            // label_ChucVuInfo
            // 
            this.label_ChucVuInfo.AutoSize = true;
            this.label_ChucVuInfo.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label_ChucVuInfo.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_ChucVuInfo.ForeColor = System.Drawing.Color.Black;
            this.label_ChucVuInfo.Location = new System.Drawing.Point(605, 367);
            this.label_ChucVuInfo.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_ChucVuInfo.Name = "label_ChucVuInfo";
            this.label_ChucVuInfo.Size = new System.Drawing.Size(29, 32);
            this.label_ChucVuInfo.TabIndex = 21;
            this.label_ChucVuInfo.Text = "...";
            // 
            // label_ChucVu
            // 
            this.label_ChucVu.AutoSize = true;
            this.label_ChucVu.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label_ChucVu.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_ChucVu.ForeColor = System.Drawing.Color.Black;
            this.label_ChucVu.Location = new System.Drawing.Point(353, 367);
            this.label_ChucVu.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_ChucVu.Name = "label_ChucVu";
            this.label_ChucVu.Size = new System.Drawing.Size(106, 32);
            this.label_ChucVu.TabIndex = 20;
            this.label_ChucVu.Text = "Chức vụ:";
            // 
            // guna2CirclePictureBox_Avatar
            // 
            this.guna2CirclePictureBox_Avatar.ImageRotate = 0F;
            this.guna2CirclePictureBox_Avatar.Location = new System.Drawing.Point(48, 96);
            this.guna2CirclePictureBox_Avatar.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.guna2CirclePictureBox_Avatar.Name = "guna2CirclePictureBox_Avatar";
            this.guna2CirclePictureBox_Avatar.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle;
            this.guna2CirclePictureBox_Avatar.Size = new System.Drawing.Size(233, 215);
            this.guna2CirclePictureBox_Avatar.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.guna2CirclePictureBox_Avatar.TabIndex = 23;
            this.guna2CirclePictureBox_Avatar.TabStop = false;
            // 
            // button_ResetInsert
            // 
            this.button_ResetInsert.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(95)))), ((int)(((byte)(105)))));
            this.button_ResetInsert.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button_ResetInsert.FlatAppearance.BorderSize = 0;
            this.button_ResetInsert.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_ResetInsert.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_ResetInsert.ForeColor = System.Drawing.Color.White;
            this.button_ResetInsert.Location = new System.Drawing.Point(175, 560);
            this.button_ResetInsert.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.button_ResetInsert.Name = "button_ResetInsert";
            this.button_ResetInsert.Size = new System.Drawing.Size(107, 50);
            this.button_ResetInsert.TabIndex = 26;
            this.button_ResetInsert.Text = "Reset";
            this.button_ResetInsert.UseVisualStyleBackColor = false;
            this.button_ResetInsert.Click += new System.EventHandler(this.button_ResetInsert_Click);
            // 
            // button_SaveInsert
            // 
            this.button_SaveInsert.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(111)))), ((int)(((byte)(51)))));
            this.button_SaveInsert.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button_SaveInsert.FlatAppearance.BorderSize = 0;
            this.button_SaveInsert.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_SaveInsert.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_SaveInsert.ForeColor = System.Drawing.Color.White;
            this.button_SaveInsert.Location = new System.Drawing.Point(48, 560);
            this.button_SaveInsert.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.button_SaveInsert.Name = "button_SaveInsert";
            this.button_SaveInsert.Size = new System.Drawing.Size(107, 50);
            this.button_SaveInsert.TabIndex = 25;
            this.button_SaveInsert.Text = "Save";
            this.button_SaveInsert.UseVisualStyleBackColor = false;
            this.button_SaveInsert.Click += new System.EventHandler(this.button_SaveInsert_Click);
            // 
            // button_Edit
            // 
            this.button_Edit.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button_Edit.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(95)))), ((int)(((byte)(105)))));
            this.button_Edit.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_Edit.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_Edit.ForeColor = System.Drawing.Color.Black;
            this.button_Edit.Location = new System.Drawing.Point(48, 367);
            this.button_Edit.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.button_Edit.Name = "button_Edit";
            this.button_Edit.Size = new System.Drawing.Size(107, 50);
            this.button_Edit.TabIndex = 27;
            this.button_Edit.Text = "Edit";
            this.button_Edit.UseVisualStyleBackColor = false;
            this.button_Edit.Click += new System.EventHandler(this.button_Edit_Click);
            // 
            // ffc_ThongTinNhanVienChiTiet
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(947, 650);
            this.Controls.Add(this.button_Edit);
            this.Controls.Add(this.button_ResetInsert);
            this.Controls.Add(this.button_SaveInsert);
            this.Controls.Add(this.guna2CirclePictureBox_Avatar);
            this.Controls.Add(this.label_ChucVuInfo);
            this.Controls.Add(this.label_ChucVu);
            this.Controls.Add(this.label_NgayNhanViecInfo);
            this.Controls.Add(this.label_SoDienThoaiInfo);
            this.Controls.Add(this.label_EmailInfo);
            this.Controls.Add(this.label_NgaySinhInfo);
            this.Controls.Add(this.label_GioiTinhInfo);
            this.Controls.Add(this.label_IDInfo);
            this.Controls.Add(this.label_NgayNhanViec);
            this.Controls.Add(this.label_SoDienThoai);
            this.Controls.Add(this.label_Email);
            this.Controls.Add(this.label_NgaySinh);
            this.Controls.Add(this.label_GioiTinh);
            this.Controls.Add(this.label_ID);
            this.Controls.Add(this.label_NhanVienName);
            this.Controls.Add(this.textBox_GioiThieu);
            this.Controls.Add(this.pictureBox_UehLogoIcon);
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Name = "ffc_ThongTinNhanVienChiTiet";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form_ThongTinNhanVienChiTiet";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_UehLogoIcon)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.guna2CirclePictureBox_Avatar)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.PictureBox pictureBox_UehLogoIcon;
        private System.Windows.Forms.TextBox textBox_GioiThieu;
        private System.Windows.Forms.Label label_NhanVienName;
        private System.Windows.Forms.Label label_ID;
        private System.Windows.Forms.Label label_GioiTinh;
        private System.Windows.Forms.Label label_NgaySinh;
        private System.Windows.Forms.Label label_Email;
        private System.Windows.Forms.Label label_SoDienThoai;
        private System.Windows.Forms.Label label_NgayNhanViec;
        private System.Windows.Forms.Label label_IDInfo;
        private System.Windows.Forms.Label label_GioiTinhInfo;
        private System.Windows.Forms.Label label_NgaySinhInfo;
        private System.Windows.Forms.Label label_EmailInfo;
        private System.Windows.Forms.Label label_SoDienThoaiInfo;
        private System.Windows.Forms.Label label_NgayNhanViecInfo;
        private System.Windows.Forms.Label label_ChucVuInfo;
        private System.Windows.Forms.Label label_ChucVu;
        private Guna.UI2.WinForms.Guna2CirclePictureBox guna2CirclePictureBox_Avatar;
        private System.Windows.Forms.Button button_ResetInsert;
        private System.Windows.Forms.Button button_SaveInsert;
        private System.Windows.Forms.Button button_Edit;
    }
}