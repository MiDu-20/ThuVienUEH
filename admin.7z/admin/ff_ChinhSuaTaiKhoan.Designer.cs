﻿namespace QuanLiThuVienUeh.admin
{
    partial class ff_ChinhSuaTaiKhoan
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ff_ChinhSuaTaiKhoan));
            this.panel_Null2 = new System.Windows.Forms.Panel();
            this.label_ThongTinNhanVien = new System.Windows.Forms.Label();
            this.label_SearchName = new System.Windows.Forms.Label();
            this.textBox_SearchName = new System.Windows.Forms.TextBox();
            this.panel_Search = new System.Windows.Forms.Panel();
            this.button_ReturnLastPage = new System.Windows.Forms.Button();
            this.button_ReturnFirstPage = new System.Windows.Forms.Button();
            this.label_Previous = new System.Windows.Forms.Label();
            this.panel_Null3 = new System.Windows.Forms.Panel();
            this.button_Search = new System.Windows.Forms.Button();
            this.button_ChangePage3 = new System.Windows.Forms.Button();
            this.label_Next = new System.Windows.Forms.Label();
            this.button_ChangePage2 = new System.Windows.Forms.Button();
            this.panel_Null1 = new System.Windows.Forms.Panel();
            this.panel_PhanTrang = new System.Windows.Forms.Panel();
            this.button_ChangePage1 = new System.Windows.Forms.Button();
            this.panel_Main = new System.Windows.Forms.Panel();
            this.dataGridView_ChinhSuaTaiKhoan = new System.Windows.Forms.DataGridView();
            this.panel_ChinhSuaTaiKhoan = new System.Windows.Forms.Panel();
            this.panel_NgayNhanViecInput = new System.Windows.Forms.Panel();
            this.dateTimePicker_NgayNhanViecInput = new System.Windows.Forms.DateTimePicker();
            this.label_NgayNhanViec = new System.Windows.Forms.Label();
            this.panel_NgaySinhInput = new System.Windows.Forms.Panel();
            this.dateTimePicker_NgaySinhInput = new System.Windows.Forms.DateTimePicker();
            this.label_NgaySinh = new System.Windows.Forms.Label();
            this.pictureBox_Exit = new System.Windows.Forms.PictureBox();
            this.panel5 = new System.Windows.Forms.Panel();
            this.textBox_SoDienThoaiUpdateInput = new System.Windows.Forms.TextBox();
            this.label_SoDienThoaiUpdateInput = new System.Windows.Forms.Label();
            this.panel_GioiTinhUpdateInput = new System.Windows.Forms.Panel();
            this.comboBox_GioiTinhUpdateInput = new System.Windows.Forms.ComboBox();
            this.label_GioiTinh = new System.Windows.Forms.Label();
            this.panel_ChucVuUpdateInput = new System.Windows.Forms.Panel();
            this.comboBox_ChucVuUpdateInput = new System.Windows.Forms.ComboBox();
            this.label_ChucVu = new System.Windows.Forms.Label();
            this.panel_HoVaTenUpdateInput = new System.Windows.Forms.Panel();
            this.textBox_HoVaTenUpdateInput = new System.Windows.Forms.TextBox();
            this.label_HoVaTenUpdateInput = new System.Windows.Forms.Label();
            this.panel4 = new System.Windows.Forms.Panel();
            this.textBox_IDUpdateInput = new System.Windows.Forms.TextBox();
            this.button_ResetUpdate = new System.Windows.Forms.Button();
            this.label_IDUpdateInput = new System.Windows.Forms.Label();
            this.button_SaveUpdate = new System.Windows.Forms.Button();
            this.label_ChinhSuaThongTinNhanVien = new System.Windows.Forms.Label();
            this.panel_SearchFunction = new System.Windows.Forms.Panel();
            this.timer_ChinhSuaTaiKhoanTransition = new System.Windows.Forms.Timer(this.components);
            this.guna2AnimateWindow1 = new Guna.UI2.WinForms.Guna2AnimateWindow(this.components);
            this.panel_Search.SuspendLayout();
            this.panel_Null3.SuspendLayout();
            this.panel_PhanTrang.SuspendLayout();
            this.panel_Main.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_ChinhSuaTaiKhoan)).BeginInit();
            this.panel_ChinhSuaTaiKhoan.SuspendLayout();
            this.panel_NgayNhanViecInput.SuspendLayout();
            this.panel_NgaySinhInput.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_Exit)).BeginInit();
            this.panel5.SuspendLayout();
            this.panel_GioiTinhUpdateInput.SuspendLayout();
            this.panel_ChucVuUpdateInput.SuspendLayout();
            this.panel_HoVaTenUpdateInput.SuspendLayout();
            this.panel4.SuspendLayout();
            this.panel_SearchFunction.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel_Null2
            // 
            this.panel_Null2.Dock = System.Windows.Forms.DockStyle.Right;
            this.panel_Null2.Location = new System.Drawing.Point(1708, 0);
            this.panel_Null2.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.panel_Null2.Name = "panel_Null2";
            this.panel_Null2.Size = new System.Drawing.Size(29, 832);
            this.panel_Null2.TabIndex = 19;
            // 
            // label_ThongTinNhanVien
            // 
            this.label_ThongTinNhanVien.AutoSize = true;
            this.label_ThongTinNhanVien.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_ThongTinNhanVien.Location = new System.Drawing.Point(-7, 4);
            this.label_ThongTinNhanVien.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_ThongTinNhanVien.Name = "label_ThongTinNhanVien";
            this.label_ThongTinNhanVien.Size = new System.Drawing.Size(305, 37);
            this.label_ThongTinNhanVien.TabIndex = 6;
            this.label_ThongTinNhanVien.Text = "THÔNG TIN NHÂN VIÊN";
            this.label_ThongTinNhanVien.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label_SearchName
            // 
            this.label_SearchName.AutoSize = true;
            this.label_SearchName.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.label_SearchName.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_SearchName.ForeColor = System.Drawing.Color.DimGray;
            this.label_SearchName.Location = new System.Drawing.Point(16, 10);
            this.label_SearchName.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_SearchName.Name = "label_SearchName";
            this.label_SearchName.Size = new System.Drawing.Size(244, 28);
            this.label_SearchName.TabIndex = 10;
            this.label_SearchName.Text = "Search by id, name, email...";
            this.label_SearchName.Click += new System.EventHandler(this.label_SearchName_Click);
            // 
            // textBox_SearchName
            // 
            this.textBox_SearchName.BackColor = System.Drawing.Color.Gainsboro;
            this.textBox_SearchName.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox_SearchName.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox_SearchName.Location = new System.Drawing.Point(3, 10);
            this.textBox_SearchName.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.textBox_SearchName.Name = "textBox_SearchName";
            this.textBox_SearchName.Size = new System.Drawing.Size(633, 27);
            this.textBox_SearchName.TabIndex = 7;
            this.textBox_SearchName.Click += new System.EventHandler(this.textBox_SearchName_Click);
            this.textBox_SearchName.TextChanged += new System.EventHandler(this.textBox_SearchName_TextChanged);
            // 
            // panel_Search
            // 
            this.panel_Search.BackColor = System.Drawing.Color.Gainsboro;
            this.panel_Search.Controls.Add(this.label_SearchName);
            this.panel_Search.Controls.Add(this.textBox_SearchName);
            this.panel_Search.Location = new System.Drawing.Point(0, 50);
            this.panel_Search.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.panel_Search.Name = "panel_Search";
            this.panel_Search.Size = new System.Drawing.Size(640, 48);
            this.panel_Search.TabIndex = 9;
            // 
            // button_ReturnLastPage
            // 
            this.button_ReturnLastPage.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.button_ReturnLastPage.BackColor = System.Drawing.Color.White;
            this.button_ReturnLastPage.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button_ReturnLastPage.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(111)))), ((int)(((byte)(51)))));
            this.button_ReturnLastPage.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(95)))), ((int)(((byte)(105)))));
            this.button_ReturnLastPage.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_ReturnLastPage.Font = new System.Drawing.Font("Segoe UI Black", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_ReturnLastPage.ForeColor = System.Drawing.Color.Black;
            this.button_ReturnLastPage.Location = new System.Drawing.Point(1545, 11);
            this.button_ReturnLastPage.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.button_ReturnLastPage.Name = "button_ReturnLastPage";
            this.button_ReturnLastPage.Size = new System.Drawing.Size(53, 49);
            this.button_ReturnLastPage.TabIndex = 19;
            this.button_ReturnLastPage.Text = ">>";
            this.button_ReturnLastPage.UseVisualStyleBackColor = false;
            this.button_ReturnLastPage.Click += new System.EventHandler(this.button_ReturnLastPage_Click);
            // 
            // button_ReturnFirstPage
            // 
            this.button_ReturnFirstPage.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.button_ReturnFirstPage.BackColor = System.Drawing.Color.White;
            this.button_ReturnFirstPage.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button_ReturnFirstPage.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(111)))), ((int)(((byte)(51)))));
            this.button_ReturnFirstPage.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(95)))), ((int)(((byte)(105)))));
            this.button_ReturnFirstPage.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_ReturnFirstPage.Font = new System.Drawing.Font("Segoe UI Black", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_ReturnFirstPage.ForeColor = System.Drawing.Color.Black;
            this.button_ReturnFirstPage.Location = new System.Drawing.Point(1232, 11);
            this.button_ReturnFirstPage.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.button_ReturnFirstPage.Name = "button_ReturnFirstPage";
            this.button_ReturnFirstPage.Size = new System.Drawing.Size(53, 49);
            this.button_ReturnFirstPage.TabIndex = 18;
            this.button_ReturnFirstPage.Text = "<<";
            this.button_ReturnFirstPage.UseVisualStyleBackColor = false;
            this.button_ReturnFirstPage.Click += new System.EventHandler(this.button_ReturnFirstPage_Click);
            // 
            // label_Previous
            // 
            this.label_Previous.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.label_Previous.AutoSize = true;
            this.label_Previous.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label_Previous.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_Previous.Location = new System.Drawing.Point(1113, 21);
            this.label_Previous.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_Previous.Name = "label_Previous";
            this.label_Previous.Size = new System.Drawing.Size(104, 32);
            this.label_Previous.TabIndex = 12;
            this.label_Previous.Text = "Previous";
            // 
            // panel_Null3
            // 
            this.panel_Null3.Controls.Add(this.panel_Search);
            this.panel_Null3.Controls.Add(this.button_Search);
            this.panel_Null3.Controls.Add(this.label_ThongTinNhanVien);
            this.panel_Null3.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel_Null3.Location = new System.Drawing.Point(0, 0);
            this.panel_Null3.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.panel_Null3.Name = "panel_Null3";
            this.panel_Null3.Size = new System.Drawing.Size(1667, 110);
            this.panel_Null3.TabIndex = 0;
            // 
            // button_Search
            // 
            this.button_Search.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.button_Search.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(95)))), ((int)(((byte)(105)))));
            this.button_Search.FlatAppearance.BorderSize = 0;
            this.button_Search.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_Search.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_Search.ForeColor = System.Drawing.Color.White;
            this.button_Search.Location = new System.Drawing.Point(1460, 49);
            this.button_Search.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.button_Search.Name = "button_Search";
            this.button_Search.Size = new System.Drawing.Size(207, 48);
            this.button_Search.TabIndex = 4;
            this.button_Search.Text = "SEARCH";
            this.button_Search.UseVisualStyleBackColor = false;
            // 
            // button_ChangePage3
            // 
            this.button_ChangePage3.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.button_ChangePage3.BackColor = System.Drawing.Color.White;
            this.button_ChangePage3.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button_ChangePage3.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(111)))), ((int)(((byte)(51)))));
            this.button_ChangePage3.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(95)))), ((int)(((byte)(105)))));
            this.button_ChangePage3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_ChangePage3.Font = new System.Drawing.Font("Segoe UI Semibold", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_ChangePage3.ForeColor = System.Drawing.Color.Black;
            this.button_ChangePage3.Location = new System.Drawing.Point(1468, 11);
            this.button_ChangePage3.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.button_ChangePage3.Name = "button_ChangePage3";
            this.button_ChangePage3.Size = new System.Drawing.Size(53, 49);
            this.button_ChangePage3.TabIndex = 17;
            this.button_ChangePage3.Text = "3";
            this.button_ChangePage3.UseVisualStyleBackColor = false;
            this.button_ChangePage3.Click += new System.EventHandler(this.button_ChangePage3_Click);
            // 
            // label_Next
            // 
            this.label_Next.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.label_Next.AutoSize = true;
            this.label_Next.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label_Next.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_Next.Location = new System.Drawing.Point(1605, 21);
            this.label_Next.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_Next.Name = "label_Next";
            this.label_Next.Size = new System.Drawing.Size(64, 32);
            this.label_Next.TabIndex = 16;
            this.label_Next.Text = "Next";
            // 
            // button_ChangePage2
            // 
            this.button_ChangePage2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.button_ChangePage2.BackColor = System.Drawing.Color.White;
            this.button_ChangePage2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button_ChangePage2.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(111)))), ((int)(((byte)(51)))));
            this.button_ChangePage2.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(95)))), ((int)(((byte)(105)))));
            this.button_ChangePage2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_ChangePage2.Font = new System.Drawing.Font("Segoe UI Semibold", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_ChangePage2.ForeColor = System.Drawing.Color.Black;
            this.button_ChangePage2.Location = new System.Drawing.Point(1391, 11);
            this.button_ChangePage2.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.button_ChangePage2.Name = "button_ChangePage2";
            this.button_ChangePage2.Size = new System.Drawing.Size(53, 49);
            this.button_ChangePage2.TabIndex = 14;
            this.button_ChangePage2.Text = "2";
            this.button_ChangePage2.UseVisualStyleBackColor = false;
            this.button_ChangePage2.Click += new System.EventHandler(this.button_ChangePage2_Click);
            // 
            // panel_Null1
            // 
            this.panel_Null1.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel_Null1.Location = new System.Drawing.Point(0, 0);
            this.panel_Null1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.panel_Null1.Name = "panel_Null1";
            this.panel_Null1.Size = new System.Drawing.Size(41, 832);
            this.panel_Null1.TabIndex = 18;
            // 
            // panel_PhanTrang
            // 
            this.panel_PhanTrang.Controls.Add(this.button_ReturnLastPage);
            this.panel_PhanTrang.Controls.Add(this.button_ReturnFirstPage);
            this.panel_PhanTrang.Controls.Add(this.label_Previous);
            this.panel_PhanTrang.Controls.Add(this.button_ChangePage3);
            this.panel_PhanTrang.Controls.Add(this.button_ChangePage1);
            this.panel_PhanTrang.Controls.Add(this.label_Next);
            this.panel_PhanTrang.Controls.Add(this.button_ChangePage2);
            this.panel_PhanTrang.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel_PhanTrang.Location = new System.Drawing.Point(0, 519);
            this.panel_PhanTrang.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.panel_PhanTrang.Name = "panel_PhanTrang";
            this.panel_PhanTrang.Size = new System.Drawing.Size(1667, 73);
            this.panel_PhanTrang.TabIndex = 1;
            // 
            // button_ChangePage1
            // 
            this.button_ChangePage1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.button_ChangePage1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(95)))), ((int)(((byte)(105)))));
            this.button_ChangePage1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button_ChangePage1.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(111)))), ((int)(((byte)(51)))));
            this.button_ChangePage1.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(95)))), ((int)(((byte)(105)))));
            this.button_ChangePage1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_ChangePage1.Font = new System.Drawing.Font("Segoe UI Semibold", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_ChangePage1.ForeColor = System.Drawing.Color.White;
            this.button_ChangePage1.Location = new System.Drawing.Point(1312, 11);
            this.button_ChangePage1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.button_ChangePage1.Name = "button_ChangePage1";
            this.button_ChangePage1.Size = new System.Drawing.Size(53, 49);
            this.button_ChangePage1.TabIndex = 13;
            this.button_ChangePage1.Text = "1";
            this.button_ChangePage1.UseVisualStyleBackColor = false;
            this.button_ChangePage1.Click += new System.EventHandler(this.button_ChangePage1_Click);
            // 
            // panel_Main
            // 
            this.panel_Main.Controls.Add(this.dataGridView_ChinhSuaTaiKhoan);
            this.panel_Main.Controls.Add(this.panel_PhanTrang);
            this.panel_Main.Controls.Add(this.panel_Null3);
            this.panel_Main.Controls.Add(this.panel_ChinhSuaTaiKhoan);
            this.panel_Main.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel_Main.Location = new System.Drawing.Point(41, 0);
            this.panel_Main.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.panel_Main.Name = "panel_Main";
            this.panel_Main.Size = new System.Drawing.Size(1667, 832);
            this.panel_Main.TabIndex = 20;
            // 
            // dataGridView_ChinhSuaTaiKhoan
            // 
            this.dataGridView_ChinhSuaTaiKhoan.AllowUserToAddRows = false;
            this.dataGridView_ChinhSuaTaiKhoan.AllowUserToDeleteRows = false;
            this.dataGridView_ChinhSuaTaiKhoan.AllowUserToResizeColumns = false;
            this.dataGridView_ChinhSuaTaiKhoan.AllowUserToResizeRows = false;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.White;
            this.dataGridView_ChinhSuaTaiKhoan.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.dataGridView_ChinhSuaTaiKhoan.BackgroundColor = System.Drawing.Color.White;
            this.dataGridView_ChinhSuaTaiKhoan.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(111)))), ((int)(((byte)(51)))));
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.Color.White;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView_ChinhSuaTaiKhoan.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            this.dataGridView_ChinhSuaTaiKhoan.ColumnHeadersHeight = 40;
            this.dataGridView_ChinhSuaTaiKhoan.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            this.dataGridView_ChinhSuaTaiKhoan.Cursor = System.Windows.Forms.Cursors.Hand;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle3.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridView_ChinhSuaTaiKhoan.DefaultCellStyle = dataGridViewCellStyle3;
            this.dataGridView_ChinhSuaTaiKhoan.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridView_ChinhSuaTaiKhoan.EnableHeadersVisualStyles = false;
            this.dataGridView_ChinhSuaTaiKhoan.GridColor = System.Drawing.Color.White;
            this.dataGridView_ChinhSuaTaiKhoan.Location = new System.Drawing.Point(0, 110);
            this.dataGridView_ChinhSuaTaiKhoan.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.dataGridView_ChinhSuaTaiKhoan.Name = "dataGridView_ChinhSuaTaiKhoan";
            this.dataGridView_ChinhSuaTaiKhoan.ReadOnly = true;
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle4.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle4.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle4.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle4.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle4.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView_ChinhSuaTaiKhoan.RowHeadersDefaultCellStyle = dataGridViewCellStyle4;
            this.dataGridView_ChinhSuaTaiKhoan.RowHeadersVisible = false;
            this.dataGridView_ChinhSuaTaiKhoan.RowHeadersWidth = 100;
            this.dataGridView_ChinhSuaTaiKhoan.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            dataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle5.BackColor = System.Drawing.Color.DimGray;
            dataGridViewCellStyle5.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(95)))), ((int)(((byte)(105)))));
            this.dataGridView_ChinhSuaTaiKhoan.RowsDefaultCellStyle = dataGridViewCellStyle5;
            this.dataGridView_ChinhSuaTaiKhoan.RowTemplate.DefaultCellStyle.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.dataGridView_ChinhSuaTaiKhoan.RowTemplate.DefaultCellStyle.BackColor = System.Drawing.Color.White;
            this.dataGridView_ChinhSuaTaiKhoan.RowTemplate.Height = 24;
            this.dataGridView_ChinhSuaTaiKhoan.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView_ChinhSuaTaiKhoan.Size = new System.Drawing.Size(1667, 409);
            this.dataGridView_ChinhSuaTaiKhoan.TabIndex = 0;
            this.dataGridView_ChinhSuaTaiKhoan.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView_ChinhSuaTaiKhoan_CellClick);
            this.dataGridView_ChinhSuaTaiKhoan.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView_ChinhSuaTaiKhoan_CellDoubleClick);
            // 
            // panel_ChinhSuaTaiKhoan
            // 
            this.panel_ChinhSuaTaiKhoan.Controls.Add(this.panel_NgayNhanViecInput);
            this.panel_ChinhSuaTaiKhoan.Controls.Add(this.label_NgayNhanViec);
            this.panel_ChinhSuaTaiKhoan.Controls.Add(this.panel_NgaySinhInput);
            this.panel_ChinhSuaTaiKhoan.Controls.Add(this.label_NgaySinh);
            this.panel_ChinhSuaTaiKhoan.Controls.Add(this.pictureBox_Exit);
            this.panel_ChinhSuaTaiKhoan.Controls.Add(this.panel5);
            this.panel_ChinhSuaTaiKhoan.Controls.Add(this.label_SoDienThoaiUpdateInput);
            this.panel_ChinhSuaTaiKhoan.Controls.Add(this.panel_GioiTinhUpdateInput);
            this.panel_ChinhSuaTaiKhoan.Controls.Add(this.label_GioiTinh);
            this.panel_ChinhSuaTaiKhoan.Controls.Add(this.panel_ChucVuUpdateInput);
            this.panel_ChinhSuaTaiKhoan.Controls.Add(this.label_ChucVu);
            this.panel_ChinhSuaTaiKhoan.Controls.Add(this.panel_HoVaTenUpdateInput);
            this.panel_ChinhSuaTaiKhoan.Controls.Add(this.label_HoVaTenUpdateInput);
            this.panel_ChinhSuaTaiKhoan.Controls.Add(this.panel4);
            this.panel_ChinhSuaTaiKhoan.Controls.Add(this.button_ResetUpdate);
            this.panel_ChinhSuaTaiKhoan.Controls.Add(this.label_IDUpdateInput);
            this.panel_ChinhSuaTaiKhoan.Controls.Add(this.button_SaveUpdate);
            this.panel_ChinhSuaTaiKhoan.Controls.Add(this.label_ChinhSuaThongTinNhanVien);
            this.panel_ChinhSuaTaiKhoan.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel_ChinhSuaTaiKhoan.Location = new System.Drawing.Point(0, 592);
            this.panel_ChinhSuaTaiKhoan.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.panel_ChinhSuaTaiKhoan.Name = "panel_ChinhSuaTaiKhoan";
            this.panel_ChinhSuaTaiKhoan.Size = new System.Drawing.Size(1667, 240);
            this.panel_ChinhSuaTaiKhoan.TabIndex = 28;
            // 
            // panel_NgayNhanViecInput
            // 
            this.panel_NgayNhanViecInput.BackColor = System.Drawing.Color.White;
            this.panel_NgayNhanViecInput.Controls.Add(this.dateTimePicker_NgayNhanViecInput);
            this.panel_NgayNhanViecInput.ForeColor = System.Drawing.SystemColors.Control;
            this.panel_NgayNhanViecInput.Location = new System.Drawing.Point(432, 170);
            this.panel_NgayNhanViecInput.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.panel_NgayNhanViecInput.Name = "panel_NgayNhanViecInput";
            this.panel_NgayNhanViecInput.Size = new System.Drawing.Size(308, 55);
            this.panel_NgayNhanViecInput.TabIndex = 35;
            // 
            // dateTimePicker_NgayNhanViecInput
            // 
            this.dateTimePicker_NgayNhanViecInput.CalendarForeColor = System.Drawing.Color.White;
            this.dateTimePicker_NgayNhanViecInput.CalendarTitleBackColor = System.Drawing.Color.White;
            this.dateTimePicker_NgayNhanViecInput.CustomFormat = "dd/MM/yyyy";
            this.dateTimePicker_NgayNhanViecInput.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dateTimePicker_NgayNhanViecInput.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dateTimePicker_NgayNhanViecInput.Location = new System.Drawing.Point(0, 7);
            this.dateTimePicker_NgayNhanViecInput.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.dateTimePicker_NgayNhanViecInput.Name = "dateTimePicker_NgayNhanViecInput";
            this.dateTimePicker_NgayNhanViecInput.Size = new System.Drawing.Size(305, 39);
            this.dateTimePicker_NgayNhanViecInput.TabIndex = 3;
            this.dateTimePicker_NgayNhanViecInput.Value = new System.DateTime(2024, 3, 26, 0, 0, 0, 0);
            this.dateTimePicker_NgayNhanViecInput.ValueChanged += new System.EventHandler(this.dateTimePicker_NgayNhanViecInput_ValueChanged);
            // 
            // label_NgayNhanViec
            // 
            this.label_NgayNhanViec.AutoSize = true;
            this.label_NgayNhanViec.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label_NgayNhanViec.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_NgayNhanViec.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label_NgayNhanViec.Location = new System.Drawing.Point(427, 135);
            this.label_NgayNhanViec.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_NgayNhanViec.Name = "label_NgayNhanViec";
            this.label_NgayNhanViec.Size = new System.Drawing.Size(197, 32);
            this.label_NgayNhanViec.TabIndex = 34;
            this.label_NgayNhanViec.Text = "Ngày nhận việc *";
            // 
            // panel_NgaySinhInput
            // 
            this.panel_NgaySinhInput.BackColor = System.Drawing.Color.White;
            this.panel_NgaySinhInput.Controls.Add(this.dateTimePicker_NgaySinhInput);
            this.panel_NgaySinhInput.ForeColor = System.Drawing.SystemColors.Control;
            this.panel_NgaySinhInput.Location = new System.Drawing.Point(20, 170);
            this.panel_NgaySinhInput.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.panel_NgaySinhInput.Name = "panel_NgaySinhInput";
            this.panel_NgaySinhInput.Size = new System.Drawing.Size(308, 55);
            this.panel_NgaySinhInput.TabIndex = 33;
            // 
            // dateTimePicker_NgaySinhInput
            // 
            this.dateTimePicker_NgaySinhInput.CalendarForeColor = System.Drawing.Color.White;
            this.dateTimePicker_NgaySinhInput.CalendarTitleBackColor = System.Drawing.Color.White;
            this.dateTimePicker_NgaySinhInput.CustomFormat = "dd/MM/yyyy";
            this.dateTimePicker_NgaySinhInput.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dateTimePicker_NgaySinhInput.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dateTimePicker_NgaySinhInput.Location = new System.Drawing.Point(1, 7);
            this.dateTimePicker_NgaySinhInput.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.dateTimePicker_NgaySinhInput.Name = "dateTimePicker_NgaySinhInput";
            this.dateTimePicker_NgaySinhInput.Size = new System.Drawing.Size(305, 39);
            this.dateTimePicker_NgaySinhInput.TabIndex = 3;
            this.dateTimePicker_NgaySinhInput.Value = new System.DateTime(1950, 12, 31, 0, 0, 0, 0);
            this.dateTimePicker_NgaySinhInput.ValueChanged += new System.EventHandler(this.dateTimePicker_NgaySinhInput_ValueChanged);
            // 
            // label_NgaySinh
            // 
            this.label_NgaySinh.AutoSize = true;
            this.label_NgaySinh.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label_NgaySinh.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_NgaySinh.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label_NgaySinh.Location = new System.Drawing.Point(15, 137);
            this.label_NgaySinh.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_NgaySinh.Name = "label_NgaySinh";
            this.label_NgaySinh.Size = new System.Drawing.Size(261, 32);
            this.label_NgaySinh.TabIndex = 32;
            this.label_NgaySinh.Text = "Ngày tháng năm sinh *";
            // 
            // pictureBox_Exit
            // 
            this.pictureBox_Exit.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBox_Exit.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBox_Exit.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox_Exit.Image")));
            this.pictureBox_Exit.Location = new System.Drawing.Point(1612, 0);
            this.pictureBox_Exit.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.pictureBox_Exit.Name = "pictureBox_Exit";
            this.pictureBox_Exit.Size = new System.Drawing.Size(55, 50);
            this.pictureBox_Exit.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox_Exit.TabIndex = 31;
            this.pictureBox_Exit.TabStop = false;
            this.pictureBox_Exit.Click += new System.EventHandler(this.pictureBox_Exit_Click);
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(221)))), ((int)(((byte)(222)))), ((int)(((byte)(238)))));
            this.panel5.Controls.Add(this.textBox_SoDienThoaiUpdateInput);
            this.panel5.ForeColor = System.Drawing.SystemColors.Control;
            this.panel5.Location = new System.Drawing.Point(1357, 73);
            this.panel5.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(309, 55);
            this.panel5.TabIndex = 21;
            // 
            // textBox_SoDienThoaiUpdateInput
            // 
            this.textBox_SoDienThoaiUpdateInput.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(221)))), ((int)(((byte)(222)))), ((int)(((byte)(238)))));
            this.textBox_SoDienThoaiUpdateInput.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox_SoDienThoaiUpdateInput.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox_SoDienThoaiUpdateInput.Location = new System.Drawing.Point(3, 12);
            this.textBox_SoDienThoaiUpdateInput.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.textBox_SoDienThoaiUpdateInput.Name = "textBox_SoDienThoaiUpdateInput";
            this.textBox_SoDienThoaiUpdateInput.Size = new System.Drawing.Size(303, 32);
            this.textBox_SoDienThoaiUpdateInput.TabIndex = 2;
            // 
            // label_SoDienThoaiUpdateInput
            // 
            this.label_SoDienThoaiUpdateInput.AutoSize = true;
            this.label_SoDienThoaiUpdateInput.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label_SoDienThoaiUpdateInput.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_SoDienThoaiUpdateInput.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label_SoDienThoaiUpdateInput.Location = new System.Drawing.Point(1352, 39);
            this.label_SoDienThoaiUpdateInput.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_SoDienThoaiUpdateInput.Name = "label_SoDienThoaiUpdateInput";
            this.label_SoDienThoaiUpdateInput.Size = new System.Drawing.Size(173, 32);
            this.label_SoDienThoaiUpdateInput.TabIndex = 20;
            this.label_SoDienThoaiUpdateInput.Text = "Số điện thoại *";
            // 
            // panel_GioiTinhUpdateInput
            // 
            this.panel_GioiTinhUpdateInput.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(221)))), ((int)(((byte)(222)))), ((int)(((byte)(238)))));
            this.panel_GioiTinhUpdateInput.Controls.Add(this.comboBox_GioiTinhUpdateInput);
            this.panel_GioiTinhUpdateInput.ForeColor = System.Drawing.SystemColors.Control;
            this.panel_GioiTinhUpdateInput.Location = new System.Drawing.Point(1061, 73);
            this.panel_GioiTinhUpdateInput.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.panel_GioiTinhUpdateInput.Name = "panel_GioiTinhUpdateInput";
            this.panel_GioiTinhUpdateInput.Size = new System.Drawing.Size(164, 55);
            this.panel_GioiTinhUpdateInput.TabIndex = 30;
            // 
            // comboBox_GioiTinhUpdateInput
            // 
            this.comboBox_GioiTinhUpdateInput.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.comboBox_GioiTinhUpdateInput.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.comboBox_GioiTinhUpdateInput.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(221)))), ((int)(((byte)(222)))), ((int)(((byte)(238)))));
            this.comboBox_GioiTinhUpdateInput.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.comboBox_GioiTinhUpdateInput.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboBox_GioiTinhUpdateInput.FormattingEnabled = true;
            this.comboBox_GioiTinhUpdateInput.Location = new System.Drawing.Point(3, 7);
            this.comboBox_GioiTinhUpdateInput.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.comboBox_GioiTinhUpdateInput.Name = "comboBox_GioiTinhUpdateInput";
            this.comboBox_GioiTinhUpdateInput.Size = new System.Drawing.Size(156, 40);
            this.comboBox_GioiTinhUpdateInput.TabIndex = 10;
            // 
            // label_GioiTinh
            // 
            this.label_GioiTinh.AutoSize = true;
            this.label_GioiTinh.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label_GioiTinh.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_GioiTinh.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label_GioiTinh.Location = new System.Drawing.Point(1055, 39);
            this.label_GioiTinh.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_GioiTinh.Name = "label_GioiTinh";
            this.label_GioiTinh.Size = new System.Drawing.Size(122, 32);
            this.label_GioiTinh.TabIndex = 29;
            this.label_GioiTinh.Text = "Giới tính *";
            // 
            // panel_ChucVuUpdateInput
            // 
            this.panel_ChucVuUpdateInput.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(221)))), ((int)(((byte)(222)))), ((int)(((byte)(238)))));
            this.panel_ChucVuUpdateInput.Controls.Add(this.comboBox_ChucVuUpdateInput);
            this.panel_ChucVuUpdateInput.ForeColor = System.Drawing.SystemColors.Control;
            this.panel_ChucVuUpdateInput.Location = new System.Drawing.Point(737, 73);
            this.panel_ChucVuUpdateInput.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.panel_ChucVuUpdateInput.Name = "panel_ChucVuUpdateInput";
            this.panel_ChucVuUpdateInput.Size = new System.Drawing.Size(200, 55);
            this.panel_ChucVuUpdateInput.TabIndex = 28;
            // 
            // comboBox_ChucVuUpdateInput
            // 
            this.comboBox_ChucVuUpdateInput.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.comboBox_ChucVuUpdateInput.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.comboBox_ChucVuUpdateInput.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(221)))), ((int)(((byte)(222)))), ((int)(((byte)(238)))));
            this.comboBox_ChucVuUpdateInput.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.comboBox_ChucVuUpdateInput.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboBox_ChucVuUpdateInput.FormattingEnabled = true;
            this.comboBox_ChucVuUpdateInput.Location = new System.Drawing.Point(3, 7);
            this.comboBox_ChucVuUpdateInput.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.comboBox_ChucVuUpdateInput.Name = "comboBox_ChucVuUpdateInput";
            this.comboBox_ChucVuUpdateInput.Size = new System.Drawing.Size(192, 40);
            this.comboBox_ChucVuUpdateInput.TabIndex = 10;
            // 
            // label_ChucVu
            // 
            this.label_ChucVu.AutoSize = true;
            this.label_ChucVu.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label_ChucVu.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_ChucVu.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label_ChucVu.Location = new System.Drawing.Point(732, 39);
            this.label_ChucVu.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_ChucVu.Name = "label_ChucVu";
            this.label_ChucVu.Size = new System.Drawing.Size(118, 32);
            this.label_ChucVu.TabIndex = 27;
            this.label_ChucVu.Text = "Chức vụ *";
            // 
            // panel_HoVaTenUpdateInput
            // 
            this.panel_HoVaTenUpdateInput.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(221)))), ((int)(((byte)(222)))), ((int)(((byte)(238)))));
            this.panel_HoVaTenUpdateInput.Controls.Add(this.textBox_HoVaTenUpdateInput);
            this.panel_HoVaTenUpdateInput.ForeColor = System.Drawing.SystemColors.Control;
            this.panel_HoVaTenUpdateInput.Location = new System.Drawing.Point(232, 73);
            this.panel_HoVaTenUpdateInput.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.panel_HoVaTenUpdateInput.Name = "panel_HoVaTenUpdateInput";
            this.panel_HoVaTenUpdateInput.Size = new System.Drawing.Size(391, 55);
            this.panel_HoVaTenUpdateInput.TabIndex = 26;
            // 
            // textBox_HoVaTenUpdateInput
            // 
            this.textBox_HoVaTenUpdateInput.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(221)))), ((int)(((byte)(222)))), ((int)(((byte)(238)))));
            this.textBox_HoVaTenUpdateInput.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox_HoVaTenUpdateInput.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox_HoVaTenUpdateInput.Location = new System.Drawing.Point(3, 11);
            this.textBox_HoVaTenUpdateInput.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.textBox_HoVaTenUpdateInput.Name = "textBox_HoVaTenUpdateInput";
            this.textBox_HoVaTenUpdateInput.Size = new System.Drawing.Size(384, 32);
            this.textBox_HoVaTenUpdateInput.TabIndex = 2;
            // 
            // label_HoVaTenUpdateInput
            // 
            this.label_HoVaTenUpdateInput.AutoSize = true;
            this.label_HoVaTenUpdateInput.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label_HoVaTenUpdateInput.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_HoVaTenUpdateInput.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label_HoVaTenUpdateInput.Location = new System.Drawing.Point(227, 39);
            this.label_HoVaTenUpdateInput.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_HoVaTenUpdateInput.Name = "label_HoVaTenUpdateInput";
            this.label_HoVaTenUpdateInput.Size = new System.Drawing.Size(135, 32);
            this.label_HoVaTenUpdateInput.TabIndex = 25;
            this.label_HoVaTenUpdateInput.Text = "Họ và tên *";
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(221)))), ((int)(((byte)(222)))), ((int)(((byte)(238)))));
            this.panel4.Controls.Add(this.textBox_IDUpdateInput);
            this.panel4.Enabled = false;
            this.panel4.ForeColor = System.Drawing.SystemColors.Control;
            this.panel4.Location = new System.Drawing.Point(21, 73);
            this.panel4.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(115, 55);
            this.panel4.TabIndex = 21;
            // 
            // textBox_IDUpdateInput
            // 
            this.textBox_IDUpdateInput.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(221)))), ((int)(((byte)(222)))), ((int)(((byte)(238)))));
            this.textBox_IDUpdateInput.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox_IDUpdateInput.Enabled = false;
            this.textBox_IDUpdateInput.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox_IDUpdateInput.Location = new System.Drawing.Point(3, 11);
            this.textBox_IDUpdateInput.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.textBox_IDUpdateInput.Name = "textBox_IDUpdateInput";
            this.textBox_IDUpdateInput.Size = new System.Drawing.Size(108, 32);
            this.textBox_IDUpdateInput.TabIndex = 2;
            // 
            // button_ResetUpdate
            // 
            this.button_ResetUpdate.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(95)))), ((int)(((byte)(105)))));
            this.button_ResetUpdate.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button_ResetUpdate.FlatAppearance.BorderSize = 0;
            this.button_ResetUpdate.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_ResetUpdate.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_ResetUpdate.ForeColor = System.Drawing.Color.White;
            this.button_ResetUpdate.Location = new System.Drawing.Point(1535, 166);
            this.button_ResetUpdate.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.button_ResetUpdate.Name = "button_ResetUpdate";
            this.button_ResetUpdate.Size = new System.Drawing.Size(128, 59);
            this.button_ResetUpdate.TabIndex = 24;
            this.button_ResetUpdate.Text = "Reset";
            this.button_ResetUpdate.UseVisualStyleBackColor = false;
            // 
            // label_IDUpdateInput
            // 
            this.label_IDUpdateInput.AutoSize = true;
            this.label_IDUpdateInput.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label_IDUpdateInput.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_IDUpdateInput.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label_IDUpdateInput.Location = new System.Drawing.Point(16, 39);
            this.label_IDUpdateInput.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_IDUpdateInput.Name = "label_IDUpdateInput";
            this.label_IDUpdateInput.Size = new System.Drawing.Size(54, 32);
            this.label_IDUpdateInput.TabIndex = 20;
            this.label_IDUpdateInput.Text = "ID *";
            // 
            // button_SaveUpdate
            // 
            this.button_SaveUpdate.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(111)))), ((int)(((byte)(51)))));
            this.button_SaveUpdate.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button_SaveUpdate.FlatAppearance.BorderSize = 0;
            this.button_SaveUpdate.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_SaveUpdate.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_SaveUpdate.ForeColor = System.Drawing.Color.White;
            this.button_SaveUpdate.Location = new System.Drawing.Point(1399, 167);
            this.button_SaveUpdate.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.button_SaveUpdate.Name = "button_SaveUpdate";
            this.button_SaveUpdate.Size = new System.Drawing.Size(128, 59);
            this.button_SaveUpdate.TabIndex = 23;
            this.button_SaveUpdate.Text = "Save";
            this.button_SaveUpdate.UseVisualStyleBackColor = false;
            this.button_SaveUpdate.Click += new System.EventHandler(this.button_SaveUpdate_Click);
            // 
            // label_ChinhSuaThongTinNhanVien
            // 
            this.label_ChinhSuaThongTinNhanVien.AutoSize = true;
            this.label_ChinhSuaThongTinNhanVien.BackColor = System.Drawing.Color.White;
            this.label_ChinhSuaThongTinNhanVien.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_ChinhSuaThongTinNhanVien.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(95)))), ((int)(((byte)(105)))));
            this.label_ChinhSuaThongTinNhanVien.Location = new System.Drawing.Point(13, 2);
            this.label_ChinhSuaThongTinNhanVien.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_ChinhSuaThongTinNhanVien.Name = "label_ChinhSuaThongTinNhanVien";
            this.label_ChinhSuaThongTinNhanVien.Size = new System.Drawing.Size(367, 32);
            this.label_ChinhSuaThongTinNhanVien.TabIndex = 15;
            this.label_ChinhSuaThongTinNhanVien.Text = "Chỉnh sửa Thông tin Nhân viên";
            this.label_ChinhSuaThongTinNhanVien.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // panel_SearchFunction
            // 
            this.panel_SearchFunction.BackColor = System.Drawing.Color.White;
            this.panel_SearchFunction.Controls.Add(this.panel_Main);
            this.panel_SearchFunction.Controls.Add(this.panel_Null1);
            this.panel_SearchFunction.Controls.Add(this.panel_Null2);
            this.panel_SearchFunction.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel_SearchFunction.Location = new System.Drawing.Point(0, 0);
            this.panel_SearchFunction.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.panel_SearchFunction.Name = "panel_SearchFunction";
            this.panel_SearchFunction.Size = new System.Drawing.Size(1737, 832);
            this.panel_SearchFunction.TabIndex = 2;
            // 
            // timer_ChinhSuaTaiKhoanTransition
            // 
            this.timer_ChinhSuaTaiKhoanTransition.Interval = 10;
            this.timer_ChinhSuaTaiKhoanTransition.Tick += new System.EventHandler(this.timer_ChinhSuaTaiKhoanTransition_Tick);
            // 
            // ff_ChinhSuaTaiKhoan
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1737, 832);
            this.Controls.Add(this.panel_SearchFunction);
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Name = "ff_ChinhSuaTaiKhoan";
            this.Text = "FormChinhSuaTaiKhoan";
            this.Resize += new System.EventHandler(this.Form_ChinhSuaTaiKhoan_Resize);
            this.panel_Search.ResumeLayout(false);
            this.panel_Search.PerformLayout();
            this.panel_Null3.ResumeLayout(false);
            this.panel_Null3.PerformLayout();
            this.panel_PhanTrang.ResumeLayout(false);
            this.panel_PhanTrang.PerformLayout();
            this.panel_Main.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_ChinhSuaTaiKhoan)).EndInit();
            this.panel_ChinhSuaTaiKhoan.ResumeLayout(false);
            this.panel_ChinhSuaTaiKhoan.PerformLayout();
            this.panel_NgayNhanViecInput.ResumeLayout(false);
            this.panel_NgaySinhInput.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_Exit)).EndInit();
            this.panel5.ResumeLayout(false);
            this.panel5.PerformLayout();
            this.panel_GioiTinhUpdateInput.ResumeLayout(false);
            this.panel_ChucVuUpdateInput.ResumeLayout(false);
            this.panel_HoVaTenUpdateInput.ResumeLayout(false);
            this.panel_HoVaTenUpdateInput.PerformLayout();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            this.panel_SearchFunction.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel_Null2;
        private System.Windows.Forms.Label label_ThongTinNhanVien;
        private System.Windows.Forms.Label label_SearchName;
        private System.Windows.Forms.TextBox textBox_SearchName;
        private System.Windows.Forms.Panel panel_Search;
        private System.Windows.Forms.Button button_ReturnLastPage;
        private System.Windows.Forms.Button button_ReturnFirstPage;
        private System.Windows.Forms.Label label_Previous;
        private System.Windows.Forms.Panel panel_Null3;
        private System.Windows.Forms.Button button_Search;
        private System.Windows.Forms.Button button_ChangePage3;
        private System.Windows.Forms.Label label_Next;
        private System.Windows.Forms.Button button_ChangePage2;
        private System.Windows.Forms.Panel panel_Null1;
        private System.Windows.Forms.Panel panel_PhanTrang;
        private System.Windows.Forms.Button button_ChangePage1;
        private System.Windows.Forms.Panel panel_Main;
        private System.Windows.Forms.DataGridView dataGridView_ChinhSuaTaiKhoan;
        private System.Windows.Forms.Panel panel_SearchFunction;
        private System.Windows.Forms.Timer timer_ChinhSuaTaiKhoanTransition;
        private System.Windows.Forms.Panel panel_ChinhSuaTaiKhoan;
        private System.Windows.Forms.PictureBox pictureBox_Exit;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.TextBox textBox_SoDienThoaiUpdateInput;
        private System.Windows.Forms.Label label_SoDienThoaiUpdateInput;
        private System.Windows.Forms.Panel panel_GioiTinhUpdateInput;
        private System.Windows.Forms.ComboBox comboBox_GioiTinhUpdateInput;
        private System.Windows.Forms.Label label_GioiTinh;
        private System.Windows.Forms.Panel panel_ChucVuUpdateInput;
        private System.Windows.Forms.ComboBox comboBox_ChucVuUpdateInput;
        private System.Windows.Forms.Label label_ChucVu;
        private System.Windows.Forms.Panel panel_HoVaTenUpdateInput;
        private System.Windows.Forms.TextBox textBox_HoVaTenUpdateInput;
        private System.Windows.Forms.Label label_HoVaTenUpdateInput;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.TextBox textBox_IDUpdateInput;
        private System.Windows.Forms.Button button_ResetUpdate;
        private System.Windows.Forms.Label label_IDUpdateInput;
        private System.Windows.Forms.Button button_SaveUpdate;
        private System.Windows.Forms.Label label_ChinhSuaThongTinNhanVien;
        private System.Windows.Forms.Panel panel_NgayNhanViecInput;
        private System.Windows.Forms.DateTimePicker dateTimePicker_NgayNhanViecInput;
        private System.Windows.Forms.Label label_NgayNhanViec;
        private System.Windows.Forms.Panel panel_NgaySinhInput;
        private System.Windows.Forms.DateTimePicker dateTimePicker_NgaySinhInput;
        private System.Windows.Forms.Label label_NgaySinh;
        private Guna.UI2.WinForms.Guna2AnimateWindow guna2AnimateWindow1;
    }
}