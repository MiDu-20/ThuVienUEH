﻿namespace QuanLiThuVienUeh.admin
{
    partial class ff_ThongTinSach
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ff_ThongTinSach));
            this.panel_Null2 = new System.Windows.Forms.Panel();
            this.label_ThongTinSach = new System.Windows.Forms.Label();
            this.label_SearchName = new System.Windows.Forms.Label();
            this.textBox_SearchName = new System.Windows.Forms.TextBox();
            this.panel_Search = new System.Windows.Forms.Panel();
            this.button_ReturnLastPage = new System.Windows.Forms.Button();
            this.button_ReturnFirstPage = new System.Windows.Forms.Button();
            this.label_Previous = new System.Windows.Forms.Label();
            this.panel_Null3 = new System.Windows.Forms.Panel();
            this.button_Search = new System.Windows.Forms.Button();
            this.button_ChangePage3 = new System.Windows.Forms.Button();
            this.label_Next = new System.Windows.Forms.Label();
            this.button_ChangePage2 = new System.Windows.Forms.Button();
            this.panel_Null1 = new System.Windows.Forms.Panel();
            this.panel_PhanTrang = new System.Windows.Forms.Panel();
            this.button_ChangePage1 = new System.Windows.Forms.Button();
            this.panel_Main = new System.Windows.Forms.Panel();
            this.dataGridView_ChinhSuaSach = new System.Windows.Forms.DataGridView();
            this.panel_ChinhSuaSach = new System.Windows.Forms.Panel();
            this.panel_NhaXuatBanUpdateInput = new System.Windows.Forms.Panel();
            this.textBox_NhaXuatBanUpdateInput = new System.Windows.Forms.TextBox();
            this.label_NhaXuatBanUpdateInput = new System.Windows.Forms.Label();
            this.panel_SoLuongUpdateInput = new System.Windows.Forms.Panel();
            this.textBox_SoLuongUpdateInput = new System.Windows.Forms.TextBox();
            this.label_SoLuongUpdateInput = new System.Windows.Forms.Label();
            this.panel_NamXuatBanUpdateInput = new System.Windows.Forms.Panel();
            this.dateTimePicker_NamXuatBanUpdateInput = new System.Windows.Forms.DateTimePicker();
            this.label_NamXuatBanUpdateInput = new System.Windows.Forms.Label();
            this.panel_TacGiaUpdateInput = new System.Windows.Forms.Panel();
            this.textBox_TacGiaUpdateInput = new System.Windows.Forms.TextBox();
            this.label_TacGiaUpdateInput = new System.Windows.Forms.Label();
            this.panel_TheLoaiUpdateInput = new System.Windows.Forms.Panel();
            this.textBox_TheLoaiUpdateInput = new System.Windows.Forms.TextBox();
            this.label_TheLoaiUpdateInput = new System.Windows.Forms.Label();
            this.panel_TenSachUpdateInput = new System.Windows.Forms.Panel();
            this.textBox_TenSachUpdateInput = new System.Windows.Forms.TextBox();
            this.label_TenSachUpdateInput = new System.Windows.Forms.Label();
            this.panel_IDSachUpdateInput = new System.Windows.Forms.Panel();
            this.textBox_IDSachUpdateInput = new System.Windows.Forms.TextBox();
            this.button_ResetUpdate = new System.Windows.Forms.Button();
            this.label_IDSachUpdateInput = new System.Windows.Forms.Label();
            this.button_SaveUpdate = new System.Windows.Forms.Button();
            this.label_ChinhSuaSach = new System.Windows.Forms.Label();
            this.panel_SearchFunction = new System.Windows.Forms.Panel();
            this.timer_ChinhSuaSachTransition = new System.Windows.Forms.Timer(this.components);
            this.button_Add = new System.Windows.Forms.Button();
            this.pictureBox_Exit = new System.Windows.Forms.PictureBox();
            this.panel_Search.SuspendLayout();
            this.panel_Null3.SuspendLayout();
            this.panel_PhanTrang.SuspendLayout();
            this.panel_Main.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_ChinhSuaSach)).BeginInit();
            this.panel_ChinhSuaSach.SuspendLayout();
            this.panel_NhaXuatBanUpdateInput.SuspendLayout();
            this.panel_SoLuongUpdateInput.SuspendLayout();
            this.panel_NamXuatBanUpdateInput.SuspendLayout();
            this.panel_TacGiaUpdateInput.SuspendLayout();
            this.panel_TheLoaiUpdateInput.SuspendLayout();
            this.panel_TenSachUpdateInput.SuspendLayout();
            this.panel_IDSachUpdateInput.SuspendLayout();
            this.panel_SearchFunction.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_Exit)).BeginInit();
            this.SuspendLayout();
            // 
            // panel_Null2
            // 
            this.panel_Null2.Dock = System.Windows.Forms.DockStyle.Right;
            this.panel_Null2.Location = new System.Drawing.Point(1708, 0);
            this.panel_Null2.Margin = new System.Windows.Forms.Padding(4);
            this.panel_Null2.Name = "panel_Null2";
            this.panel_Null2.Size = new System.Drawing.Size(29, 832);
            this.panel_Null2.TabIndex = 19;
            // 
            // label_ThongTinSach
            // 
            this.label_ThongTinSach.AutoSize = true;
            this.label_ThongTinSach.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_ThongTinSach.Location = new System.Drawing.Point(-7, 4);
            this.label_ThongTinSach.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_ThongTinSach.Name = "label_ThongTinSach";
            this.label_ThongTinSach.Size = new System.Drawing.Size(230, 37);
            this.label_ThongTinSach.TabIndex = 6;
            this.label_ThongTinSach.Text = "THÔNG TIN SÁCH";
            this.label_ThongTinSach.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label_SearchName
            // 
            this.label_SearchName.AutoSize = true;
            this.label_SearchName.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.label_SearchName.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_SearchName.ForeColor = System.Drawing.Color.DimGray;
            this.label_SearchName.Location = new System.Drawing.Point(16, 10);
            this.label_SearchName.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_SearchName.Name = "label_SearchName";
            this.label_SearchName.Size = new System.Drawing.Size(243, 28);
            this.label_SearchName.TabIndex = 10;
            this.label_SearchName.Text = "Search by id, name, book...";
            this.label_SearchName.Click += new System.EventHandler(this.label_SearchName_Click);
            // 
            // textBox_SearchName
            // 
            this.textBox_SearchName.BackColor = System.Drawing.Color.Gainsboro;
            this.textBox_SearchName.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox_SearchName.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox_SearchName.Location = new System.Drawing.Point(3, 10);
            this.textBox_SearchName.Margin = new System.Windows.Forms.Padding(4);
            this.textBox_SearchName.Name = "textBox_SearchName";
            this.textBox_SearchName.Size = new System.Drawing.Size(447, 27);
            this.textBox_SearchName.TabIndex = 7;
            this.textBox_SearchName.Click += new System.EventHandler(this.textBox_SearchName_Click);
            this.textBox_SearchName.TextChanged += new System.EventHandler(this.textBox_SearchName_TextChanged);
            // 
            // panel_Search
            // 
            this.panel_Search.BackColor = System.Drawing.Color.Gainsboro;
            this.panel_Search.Controls.Add(this.label_SearchName);
            this.panel_Search.Controls.Add(this.textBox_SearchName);
            this.panel_Search.Location = new System.Drawing.Point(0, 50);
            this.panel_Search.Margin = new System.Windows.Forms.Padding(4);
            this.panel_Search.Name = "panel_Search";
            this.panel_Search.Size = new System.Drawing.Size(640, 48);
            this.panel_Search.TabIndex = 9;
            // 
            // button_ReturnLastPage
            // 
            this.button_ReturnLastPage.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.button_ReturnLastPage.BackColor = System.Drawing.Color.White;
            this.button_ReturnLastPage.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button_ReturnLastPage.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(111)))), ((int)(((byte)(51)))));
            this.button_ReturnLastPage.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(95)))), ((int)(((byte)(105)))));
            this.button_ReturnLastPage.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_ReturnLastPage.Font = new System.Drawing.Font("Segoe UI Black", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_ReturnLastPage.ForeColor = System.Drawing.Color.Black;
            this.button_ReturnLastPage.Location = new System.Drawing.Point(1547, 11);
            this.button_ReturnLastPage.Margin = new System.Windows.Forms.Padding(4);
            this.button_ReturnLastPage.Name = "button_ReturnLastPage";
            this.button_ReturnLastPage.Size = new System.Drawing.Size(53, 49);
            this.button_ReturnLastPage.TabIndex = 19;
            this.button_ReturnLastPage.Text = ">>";
            this.button_ReturnLastPage.UseVisualStyleBackColor = false;
            this.button_ReturnLastPage.Click += new System.EventHandler(this.button_ReturnLastPage_Click);
            // 
            // button_ReturnFirstPage
            // 
            this.button_ReturnFirstPage.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.button_ReturnFirstPage.BackColor = System.Drawing.Color.White;
            this.button_ReturnFirstPage.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button_ReturnFirstPage.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(111)))), ((int)(((byte)(51)))));
            this.button_ReturnFirstPage.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(95)))), ((int)(((byte)(105)))));
            this.button_ReturnFirstPage.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_ReturnFirstPage.Font = new System.Drawing.Font("Segoe UI Black", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_ReturnFirstPage.ForeColor = System.Drawing.Color.Black;
            this.button_ReturnFirstPage.Location = new System.Drawing.Point(1233, 11);
            this.button_ReturnFirstPage.Margin = new System.Windows.Forms.Padding(4);
            this.button_ReturnFirstPage.Name = "button_ReturnFirstPage";
            this.button_ReturnFirstPage.Size = new System.Drawing.Size(53, 49);
            this.button_ReturnFirstPage.TabIndex = 18;
            this.button_ReturnFirstPage.Text = "<<";
            this.button_ReturnFirstPage.UseVisualStyleBackColor = false;
            this.button_ReturnFirstPage.Click += new System.EventHandler(this.button_ReturnFirstPage_Click);
            // 
            // label_Previous
            // 
            this.label_Previous.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.label_Previous.AutoSize = true;
            this.label_Previous.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label_Previous.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_Previous.Location = new System.Drawing.Point(1115, 21);
            this.label_Previous.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_Previous.Name = "label_Previous";
            this.label_Previous.Size = new System.Drawing.Size(104, 32);
            this.label_Previous.TabIndex = 12;
            this.label_Previous.Text = "Previous";
            // 
            // panel_Null3
            // 
            this.panel_Null3.Controls.Add(this.panel_Search);
            this.panel_Null3.Controls.Add(this.button_Search);
            this.panel_Null3.Controls.Add(this.label_ThongTinSach);
            this.panel_Null3.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel_Null3.Location = new System.Drawing.Point(0, 0);
            this.panel_Null3.Margin = new System.Windows.Forms.Padding(4);
            this.panel_Null3.Name = "panel_Null3";
            this.panel_Null3.Size = new System.Drawing.Size(1667, 110);
            this.panel_Null3.TabIndex = 0;
            // 
            // button_Search
            // 
            this.button_Search.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.button_Search.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(95)))), ((int)(((byte)(105)))));
            this.button_Search.FlatAppearance.BorderSize = 0;
            this.button_Search.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_Search.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_Search.ForeColor = System.Drawing.Color.White;
            this.button_Search.Location = new System.Drawing.Point(1461, 49);
            this.button_Search.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.button_Search.Name = "button_Search";
            this.button_Search.Size = new System.Drawing.Size(207, 48);
            this.button_Search.TabIndex = 4;
            this.button_Search.Text = "SEARCH";
            this.button_Search.UseVisualStyleBackColor = false;
            // 
            // button_ChangePage3
            // 
            this.button_ChangePage3.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.button_ChangePage3.BackColor = System.Drawing.Color.White;
            this.button_ChangePage3.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button_ChangePage3.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(111)))), ((int)(((byte)(51)))));
            this.button_ChangePage3.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(95)))), ((int)(((byte)(105)))));
            this.button_ChangePage3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_ChangePage3.Font = new System.Drawing.Font("Segoe UI Semibold", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_ChangePage3.ForeColor = System.Drawing.Color.Black;
            this.button_ChangePage3.Location = new System.Drawing.Point(1469, 11);
            this.button_ChangePage3.Margin = new System.Windows.Forms.Padding(4);
            this.button_ChangePage3.Name = "button_ChangePage3";
            this.button_ChangePage3.Size = new System.Drawing.Size(53, 49);
            this.button_ChangePage3.TabIndex = 17;
            this.button_ChangePage3.Text = "3";
            this.button_ChangePage3.UseVisualStyleBackColor = false;
            this.button_ChangePage3.Click += new System.EventHandler(this.button_ChangePage3_Click);
            // 
            // label_Next
            // 
            this.label_Next.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.label_Next.AutoSize = true;
            this.label_Next.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label_Next.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_Next.Location = new System.Drawing.Point(1607, 21);
            this.label_Next.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_Next.Name = "label_Next";
            this.label_Next.Size = new System.Drawing.Size(64, 32);
            this.label_Next.TabIndex = 16;
            this.label_Next.Text = "Next";
            // 
            // button_ChangePage2
            // 
            this.button_ChangePage2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.button_ChangePage2.BackColor = System.Drawing.Color.White;
            this.button_ChangePage2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button_ChangePage2.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(111)))), ((int)(((byte)(51)))));
            this.button_ChangePage2.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(95)))), ((int)(((byte)(105)))));
            this.button_ChangePage2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_ChangePage2.Font = new System.Drawing.Font("Segoe UI Semibold", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_ChangePage2.ForeColor = System.Drawing.Color.Black;
            this.button_ChangePage2.Location = new System.Drawing.Point(1392, 11);
            this.button_ChangePage2.Margin = new System.Windows.Forms.Padding(4);
            this.button_ChangePage2.Name = "button_ChangePage2";
            this.button_ChangePage2.Size = new System.Drawing.Size(53, 49);
            this.button_ChangePage2.TabIndex = 14;
            this.button_ChangePage2.Text = "2";
            this.button_ChangePage2.UseVisualStyleBackColor = false;
            this.button_ChangePage2.Click += new System.EventHandler(this.button_ChangePage2_Click);
            // 
            // panel_Null1
            // 
            this.panel_Null1.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel_Null1.Location = new System.Drawing.Point(0, 0);
            this.panel_Null1.Margin = new System.Windows.Forms.Padding(4);
            this.panel_Null1.Name = "panel_Null1";
            this.panel_Null1.Size = new System.Drawing.Size(41, 832);
            this.panel_Null1.TabIndex = 18;
            // 
            // panel_PhanTrang
            // 
            this.panel_PhanTrang.Controls.Add(this.button_Add);
            this.panel_PhanTrang.Controls.Add(this.button_ReturnLastPage);
            this.panel_PhanTrang.Controls.Add(this.button_ReturnFirstPage);
            this.panel_PhanTrang.Controls.Add(this.label_Previous);
            this.panel_PhanTrang.Controls.Add(this.button_ChangePage3);
            this.panel_PhanTrang.Controls.Add(this.button_ChangePage1);
            this.panel_PhanTrang.Controls.Add(this.label_Next);
            this.panel_PhanTrang.Controls.Add(this.button_ChangePage2);
            this.panel_PhanTrang.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel_PhanTrang.Location = new System.Drawing.Point(0, 519);
            this.panel_PhanTrang.Margin = new System.Windows.Forms.Padding(4);
            this.panel_PhanTrang.Name = "panel_PhanTrang";
            this.panel_PhanTrang.Size = new System.Drawing.Size(1667, 73);
            this.panel_PhanTrang.TabIndex = 1;
            // 
            // button_ChangePage1
            // 
            this.button_ChangePage1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.button_ChangePage1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(95)))), ((int)(((byte)(105)))));
            this.button_ChangePage1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button_ChangePage1.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(111)))), ((int)(((byte)(51)))));
            this.button_ChangePage1.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(95)))), ((int)(((byte)(105)))));
            this.button_ChangePage1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_ChangePage1.Font = new System.Drawing.Font("Segoe UI Semibold", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_ChangePage1.ForeColor = System.Drawing.Color.White;
            this.button_ChangePage1.Location = new System.Drawing.Point(1313, 11);
            this.button_ChangePage1.Margin = new System.Windows.Forms.Padding(4);
            this.button_ChangePage1.Name = "button_ChangePage1";
            this.button_ChangePage1.Size = new System.Drawing.Size(53, 49);
            this.button_ChangePage1.TabIndex = 13;
            this.button_ChangePage1.Text = "1";
            this.button_ChangePage1.UseVisualStyleBackColor = false;
            this.button_ChangePage1.Click += new System.EventHandler(this.button_ChangePage1_Click);
            // 
            // panel_Main
            // 
            this.panel_Main.Controls.Add(this.dataGridView_ChinhSuaSach);
            this.panel_Main.Controls.Add(this.panel_PhanTrang);
            this.panel_Main.Controls.Add(this.panel_Null3);
            this.panel_Main.Controls.Add(this.panel_ChinhSuaSach);
            this.panel_Main.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel_Main.Location = new System.Drawing.Point(41, 0);
            this.panel_Main.Margin = new System.Windows.Forms.Padding(4);
            this.panel_Main.Name = "panel_Main";
            this.panel_Main.Size = new System.Drawing.Size(1667, 832);
            this.panel_Main.TabIndex = 20;
            // 
            // dataGridView_ChinhSuaSach
            // 
            this.dataGridView_ChinhSuaSach.AllowUserToAddRows = false;
            this.dataGridView_ChinhSuaSach.AllowUserToDeleteRows = false;
            this.dataGridView_ChinhSuaSach.AllowUserToResizeColumns = false;
            this.dataGridView_ChinhSuaSach.AllowUserToResizeRows = false;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.White;
            this.dataGridView_ChinhSuaSach.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.dataGridView_ChinhSuaSach.BackgroundColor = System.Drawing.Color.White;
            this.dataGridView_ChinhSuaSach.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(111)))), ((int)(((byte)(51)))));
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.Color.White;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView_ChinhSuaSach.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            this.dataGridView_ChinhSuaSach.ColumnHeadersHeight = 40;
            this.dataGridView_ChinhSuaSach.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            this.dataGridView_ChinhSuaSach.Cursor = System.Windows.Forms.Cursors.Hand;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle3.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridView_ChinhSuaSach.DefaultCellStyle = dataGridViewCellStyle3;
            this.dataGridView_ChinhSuaSach.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridView_ChinhSuaSach.EnableHeadersVisualStyles = false;
            this.dataGridView_ChinhSuaSach.GridColor = System.Drawing.Color.White;
            this.dataGridView_ChinhSuaSach.Location = new System.Drawing.Point(0, 110);
            this.dataGridView_ChinhSuaSach.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.dataGridView_ChinhSuaSach.MultiSelect = false;
            this.dataGridView_ChinhSuaSach.Name = "dataGridView_ChinhSuaSach";
            this.dataGridView_ChinhSuaSach.ReadOnly = true;
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle4.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle4.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle4.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle4.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle4.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView_ChinhSuaSach.RowHeadersDefaultCellStyle = dataGridViewCellStyle4;
            this.dataGridView_ChinhSuaSach.RowHeadersVisible = false;
            this.dataGridView_ChinhSuaSach.RowHeadersWidth = 100;
            this.dataGridView_ChinhSuaSach.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            dataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle5.BackColor = System.Drawing.Color.DimGray;
            dataGridViewCellStyle5.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(95)))), ((int)(((byte)(105)))));
            this.dataGridView_ChinhSuaSach.RowsDefaultCellStyle = dataGridViewCellStyle5;
            this.dataGridView_ChinhSuaSach.RowTemplate.DefaultCellStyle.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.dataGridView_ChinhSuaSach.RowTemplate.DefaultCellStyle.BackColor = System.Drawing.Color.White;
            this.dataGridView_ChinhSuaSach.RowTemplate.Height = 24;
            this.dataGridView_ChinhSuaSach.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView_ChinhSuaSach.Size = new System.Drawing.Size(1667, 409);
            this.dataGridView_ChinhSuaSach.TabIndex = 0;
            this.dataGridView_ChinhSuaSach.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView_ChinhSuaSach_CellClick);
            this.dataGridView_ChinhSuaSach.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView_ChinhSuaSach_CellDoubleClick);
            this.dataGridView_ChinhSuaSach.Resize += new System.EventHandler(this.dataGridView_ChinhSuaSach_Resize);
            // 
            // panel_ChinhSuaSach
            // 
            this.panel_ChinhSuaSach.Controls.Add(this.panel_NhaXuatBanUpdateInput);
            this.panel_ChinhSuaSach.Controls.Add(this.label_NhaXuatBanUpdateInput);
            this.panel_ChinhSuaSach.Controls.Add(this.panel_SoLuongUpdateInput);
            this.panel_ChinhSuaSach.Controls.Add(this.label_SoLuongUpdateInput);
            this.panel_ChinhSuaSach.Controls.Add(this.panel_NamXuatBanUpdateInput);
            this.panel_ChinhSuaSach.Controls.Add(this.label_NamXuatBanUpdateInput);
            this.panel_ChinhSuaSach.Controls.Add(this.panel_TacGiaUpdateInput);
            this.panel_ChinhSuaSach.Controls.Add(this.label_TacGiaUpdateInput);
            this.panel_ChinhSuaSach.Controls.Add(this.pictureBox_Exit);
            this.panel_ChinhSuaSach.Controls.Add(this.panel_TheLoaiUpdateInput);
            this.panel_ChinhSuaSach.Controls.Add(this.label_TheLoaiUpdateInput);
            this.panel_ChinhSuaSach.Controls.Add(this.panel_TenSachUpdateInput);
            this.panel_ChinhSuaSach.Controls.Add(this.label_TenSachUpdateInput);
            this.panel_ChinhSuaSach.Controls.Add(this.panel_IDSachUpdateInput);
            this.panel_ChinhSuaSach.Controls.Add(this.button_ResetUpdate);
            this.panel_ChinhSuaSach.Controls.Add(this.label_IDSachUpdateInput);
            this.panel_ChinhSuaSach.Controls.Add(this.button_SaveUpdate);
            this.panel_ChinhSuaSach.Controls.Add(this.label_ChinhSuaSach);
            this.panel_ChinhSuaSach.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel_ChinhSuaSach.Location = new System.Drawing.Point(0, 592);
            this.panel_ChinhSuaSach.Margin = new System.Windows.Forms.Padding(4);
            this.panel_ChinhSuaSach.Name = "panel_ChinhSuaSach";
            this.panel_ChinhSuaSach.Size = new System.Drawing.Size(1667, 240);
            this.panel_ChinhSuaSach.TabIndex = 2;
            // 
            // panel_NhaXuatBanUpdateInput
            // 
            this.panel_NhaXuatBanUpdateInput.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(221)))), ((int)(((byte)(222)))), ((int)(((byte)(238)))));
            this.panel_NhaXuatBanUpdateInput.Controls.Add(this.textBox_NhaXuatBanUpdateInput);
            this.panel_NhaXuatBanUpdateInput.ForeColor = System.Drawing.SystemColors.Control;
            this.panel_NhaXuatBanUpdateInput.Location = new System.Drawing.Point(351, 174);
            this.panel_NhaXuatBanUpdateInput.Margin = new System.Windows.Forms.Padding(4);
            this.panel_NhaXuatBanUpdateInput.Name = "panel_NhaXuatBanUpdateInput";
            this.panel_NhaXuatBanUpdateInput.Size = new System.Drawing.Size(340, 55);
            this.panel_NhaXuatBanUpdateInput.TabIndex = 41;
            // 
            // textBox_NhaXuatBanUpdateInput
            // 
            this.textBox_NhaXuatBanUpdateInput.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(221)))), ((int)(((byte)(222)))), ((int)(((byte)(238)))));
            this.textBox_NhaXuatBanUpdateInput.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox_NhaXuatBanUpdateInput.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox_NhaXuatBanUpdateInput.Location = new System.Drawing.Point(3, 12);
            this.textBox_NhaXuatBanUpdateInput.Margin = new System.Windows.Forms.Padding(4);
            this.textBox_NhaXuatBanUpdateInput.Name = "textBox_NhaXuatBanUpdateInput";
            this.textBox_NhaXuatBanUpdateInput.Size = new System.Drawing.Size(333, 32);
            this.textBox_NhaXuatBanUpdateInput.TabIndex = 2;
            // 
            // label_NhaXuatBanUpdateInput
            // 
            this.label_NhaXuatBanUpdateInput.AutoSize = true;
            this.label_NhaXuatBanUpdateInput.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label_NhaXuatBanUpdateInput.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_NhaXuatBanUpdateInput.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label_NhaXuatBanUpdateInput.Location = new System.Drawing.Point(345, 139);
            this.label_NhaXuatBanUpdateInput.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_NhaXuatBanUpdateInput.Name = "label_NhaXuatBanUpdateInput";
            this.label_NhaXuatBanUpdateInput.Size = new System.Drawing.Size(174, 32);
            this.label_NhaXuatBanUpdateInput.TabIndex = 40;
            this.label_NhaXuatBanUpdateInput.Text = "Nhà xuất bản *";
            // 
            // panel_SoLuongUpdateInput
            // 
            this.panel_SoLuongUpdateInput.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(221)))), ((int)(((byte)(222)))), ((int)(((byte)(238)))));
            this.panel_SoLuongUpdateInput.Controls.Add(this.textBox_SoLuongUpdateInput);
            this.panel_SoLuongUpdateInput.ForeColor = System.Drawing.SystemColors.Control;
            this.panel_SoLuongUpdateInput.Location = new System.Drawing.Point(16, 174);
            this.panel_SoLuongUpdateInput.Margin = new System.Windows.Forms.Padding(4);
            this.panel_SoLuongUpdateInput.Name = "panel_SoLuongUpdateInput";
            this.panel_SoLuongUpdateInput.Size = new System.Drawing.Size(177, 55);
            this.panel_SoLuongUpdateInput.TabIndex = 41;
            // 
            // textBox_SoLuongUpdateInput
            // 
            this.textBox_SoLuongUpdateInput.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(221)))), ((int)(((byte)(222)))), ((int)(((byte)(238)))));
            this.textBox_SoLuongUpdateInput.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox_SoLuongUpdateInput.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox_SoLuongUpdateInput.Location = new System.Drawing.Point(3, 12);
            this.textBox_SoLuongUpdateInput.Margin = new System.Windows.Forms.Padding(4);
            this.textBox_SoLuongUpdateInput.Name = "textBox_SoLuongUpdateInput";
            this.textBox_SoLuongUpdateInput.Size = new System.Drawing.Size(171, 32);
            this.textBox_SoLuongUpdateInput.TabIndex = 2;
            // 
            // label_SoLuongUpdateInput
            // 
            this.label_SoLuongUpdateInput.AutoSize = true;
            this.label_SoLuongUpdateInput.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label_SoLuongUpdateInput.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_SoLuongUpdateInput.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label_SoLuongUpdateInput.Location = new System.Drawing.Point(11, 139);
            this.label_SoLuongUpdateInput.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_SoLuongUpdateInput.Name = "label_SoLuongUpdateInput";
            this.label_SoLuongUpdateInput.Size = new System.Drawing.Size(127, 32);
            this.label_SoLuongUpdateInput.TabIndex = 40;
            this.label_SoLuongUpdateInput.Text = "Số lượng *";
            // 
            // panel_NamXuatBanUpdateInput
            // 
            this.panel_NamXuatBanUpdateInput.BackColor = System.Drawing.Color.White;
            this.panel_NamXuatBanUpdateInput.Controls.Add(this.dateTimePicker_NamXuatBanUpdateInput);
            this.panel_NamXuatBanUpdateInput.ForeColor = System.Drawing.SystemColors.Control;
            this.panel_NamXuatBanUpdateInput.Location = new System.Drawing.Point(828, 174);
            this.panel_NamXuatBanUpdateInput.Margin = new System.Windows.Forms.Padding(4);
            this.panel_NamXuatBanUpdateInput.Name = "panel_NamXuatBanUpdateInput";
            this.panel_NamXuatBanUpdateInput.Size = new System.Drawing.Size(308, 55);
            this.panel_NamXuatBanUpdateInput.TabIndex = 53;
            // 
            // dateTimePicker_NamXuatBanUpdateInput
            // 
            this.dateTimePicker_NamXuatBanUpdateInput.CalendarForeColor = System.Drawing.Color.White;
            this.dateTimePicker_NamXuatBanUpdateInput.CalendarTitleBackColor = System.Drawing.Color.White;
            this.dateTimePicker_NamXuatBanUpdateInput.CustomFormat = "dd/MM/yyyy";
            this.dateTimePicker_NamXuatBanUpdateInput.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dateTimePicker_NamXuatBanUpdateInput.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dateTimePicker_NamXuatBanUpdateInput.Location = new System.Drawing.Point(1, 7);
            this.dateTimePicker_NamXuatBanUpdateInput.Margin = new System.Windows.Forms.Padding(4);
            this.dateTimePicker_NamXuatBanUpdateInput.Name = "dateTimePicker_NamXuatBanUpdateInput";
            this.dateTimePicker_NamXuatBanUpdateInput.Size = new System.Drawing.Size(305, 39);
            this.dateTimePicker_NamXuatBanUpdateInput.TabIndex = 3;
            this.dateTimePicker_NamXuatBanUpdateInput.Value = new System.DateTime(2024, 3, 8, 0, 0, 0, 0);
            // 
            // label_NamXuatBanUpdateInput
            // 
            this.label_NamXuatBanUpdateInput.AutoSize = true;
            this.label_NamXuatBanUpdateInput.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label_NamXuatBanUpdateInput.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_NamXuatBanUpdateInput.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label_NamXuatBanUpdateInput.Location = new System.Drawing.Point(821, 139);
            this.label_NamXuatBanUpdateInput.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_NamXuatBanUpdateInput.Name = "label_NamXuatBanUpdateInput";
            this.label_NamXuatBanUpdateInput.Size = new System.Drawing.Size(181, 32);
            this.label_NamXuatBanUpdateInput.TabIndex = 52;
            this.label_NamXuatBanUpdateInput.Text = "Năm xuất bản *";
            // 
            // panel_TacGiaUpdateInput
            // 
            this.panel_TacGiaUpdateInput.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(221)))), ((int)(((byte)(222)))), ((int)(((byte)(238)))));
            this.panel_TacGiaUpdateInput.Controls.Add(this.textBox_TacGiaUpdateInput);
            this.panel_TacGiaUpdateInput.ForeColor = System.Drawing.SystemColors.Control;
            this.panel_TacGiaUpdateInput.Location = new System.Drawing.Point(828, 78);
            this.panel_TacGiaUpdateInput.Margin = new System.Windows.Forms.Padding(4);
            this.panel_TacGiaUpdateInput.Name = "panel_TacGiaUpdateInput";
            this.panel_TacGiaUpdateInput.Size = new System.Drawing.Size(363, 55);
            this.panel_TacGiaUpdateInput.TabIndex = 46;
            // 
            // textBox_TacGiaUpdateInput
            // 
            this.textBox_TacGiaUpdateInput.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(221)))), ((int)(((byte)(222)))), ((int)(((byte)(238)))));
            this.textBox_TacGiaUpdateInput.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox_TacGiaUpdateInput.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox_TacGiaUpdateInput.Location = new System.Drawing.Point(3, 11);
            this.textBox_TacGiaUpdateInput.Margin = new System.Windows.Forms.Padding(4);
            this.textBox_TacGiaUpdateInput.Name = "textBox_TacGiaUpdateInput";
            this.textBox_TacGiaUpdateInput.Size = new System.Drawing.Size(356, 32);
            this.textBox_TacGiaUpdateInput.TabIndex = 2;
            // 
            // label_TacGiaUpdateInput
            // 
            this.label_TacGiaUpdateInput.AutoSize = true;
            this.label_TacGiaUpdateInput.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label_TacGiaUpdateInput.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_TacGiaUpdateInput.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label_TacGiaUpdateInput.Location = new System.Drawing.Point(821, 43);
            this.label_TacGiaUpdateInput.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_TacGiaUpdateInput.Name = "label_TacGiaUpdateInput";
            this.label_TacGiaUpdateInput.Size = new System.Drawing.Size(103, 32);
            this.label_TacGiaUpdateInput.TabIndex = 45;
            this.label_TacGiaUpdateInput.Text = "Tác giả *";
            // 
            // panel_TheLoaiUpdateInput
            // 
            this.panel_TheLoaiUpdateInput.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(221)))), ((int)(((byte)(222)))), ((int)(((byte)(238)))));
            this.panel_TheLoaiUpdateInput.Controls.Add(this.textBox_TheLoaiUpdateInput);
            this.panel_TheLoaiUpdateInput.ForeColor = System.Drawing.SystemColors.Control;
            this.panel_TheLoaiUpdateInput.Location = new System.Drawing.Point(1327, 78);
            this.panel_TheLoaiUpdateInput.Margin = new System.Windows.Forms.Padding(4);
            this.panel_TheLoaiUpdateInput.Name = "panel_TheLoaiUpdateInput";
            this.panel_TheLoaiUpdateInput.Size = new System.Drawing.Size(273, 55);
            this.panel_TheLoaiUpdateInput.TabIndex = 39;
            // 
            // textBox_TheLoaiUpdateInput
            // 
            this.textBox_TheLoaiUpdateInput.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(221)))), ((int)(((byte)(222)))), ((int)(((byte)(238)))));
            this.textBox_TheLoaiUpdateInput.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox_TheLoaiUpdateInput.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox_TheLoaiUpdateInput.Location = new System.Drawing.Point(3, 12);
            this.textBox_TheLoaiUpdateInput.Margin = new System.Windows.Forms.Padding(4);
            this.textBox_TheLoaiUpdateInput.Name = "textBox_TheLoaiUpdateInput";
            this.textBox_TheLoaiUpdateInput.Size = new System.Drawing.Size(267, 32);
            this.textBox_TheLoaiUpdateInput.TabIndex = 2;
            // 
            // label_TheLoaiUpdateInput
            // 
            this.label_TheLoaiUpdateInput.AutoSize = true;
            this.label_TheLoaiUpdateInput.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label_TheLoaiUpdateInput.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_TheLoaiUpdateInput.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label_TheLoaiUpdateInput.Location = new System.Drawing.Point(1321, 43);
            this.label_TheLoaiUpdateInput.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_TheLoaiUpdateInput.Name = "label_TheLoaiUpdateInput";
            this.label_TheLoaiUpdateInput.Size = new System.Drawing.Size(116, 32);
            this.label_TheLoaiUpdateInput.TabIndex = 37;
            this.label_TheLoaiUpdateInput.Text = "Thể loại *";
            // 
            // panel_TenSachUpdateInput
            // 
            this.panel_TenSachUpdateInput.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(221)))), ((int)(((byte)(222)))), ((int)(((byte)(238)))));
            this.panel_TenSachUpdateInput.Controls.Add(this.textBox_TenSachUpdateInput);
            this.panel_TenSachUpdateInput.ForeColor = System.Drawing.SystemColors.Control;
            this.panel_TenSachUpdateInput.Location = new System.Drawing.Point(348, 78);
            this.panel_TenSachUpdateInput.Margin = new System.Windows.Forms.Padding(4);
            this.panel_TenSachUpdateInput.Name = "panel_TenSachUpdateInput";
            this.panel_TenSachUpdateInput.Size = new System.Drawing.Size(339, 55);
            this.panel_TenSachUpdateInput.TabIndex = 44;
            // 
            // textBox_TenSachUpdateInput
            // 
            this.textBox_TenSachUpdateInput.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(221)))), ((int)(((byte)(222)))), ((int)(((byte)(238)))));
            this.textBox_TenSachUpdateInput.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox_TenSachUpdateInput.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox_TenSachUpdateInput.Location = new System.Drawing.Point(3, 11);
            this.textBox_TenSachUpdateInput.Margin = new System.Windows.Forms.Padding(4);
            this.textBox_TenSachUpdateInput.Name = "textBox_TenSachUpdateInput";
            this.textBox_TenSachUpdateInput.Size = new System.Drawing.Size(332, 32);
            this.textBox_TenSachUpdateInput.TabIndex = 2;
            // 
            // label_TenSachUpdateInput
            // 
            this.label_TenSachUpdateInput.AutoSize = true;
            this.label_TenSachUpdateInput.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label_TenSachUpdateInput.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_TenSachUpdateInput.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label_TenSachUpdateInput.Location = new System.Drawing.Point(341, 43);
            this.label_TenSachUpdateInput.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_TenSachUpdateInput.Name = "label_TenSachUpdateInput";
            this.label_TenSachUpdateInput.Size = new System.Drawing.Size(123, 32);
            this.label_TenSachUpdateInput.TabIndex = 43;
            this.label_TenSachUpdateInput.Text = "Tên sách *";
            // 
            // panel_IDSachUpdateInput
            // 
            this.panel_IDSachUpdateInput.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(221)))), ((int)(((byte)(222)))), ((int)(((byte)(238)))));
            this.panel_IDSachUpdateInput.Controls.Add(this.textBox_IDSachUpdateInput);
            this.panel_IDSachUpdateInput.Enabled = false;
            this.panel_IDSachUpdateInput.ForeColor = System.Drawing.SystemColors.Control;
            this.panel_IDSachUpdateInput.Location = new System.Drawing.Point(13, 78);
            this.panel_IDSachUpdateInput.Margin = new System.Windows.Forms.Padding(4);
            this.panel_IDSachUpdateInput.Name = "panel_IDSachUpdateInput";
            this.panel_IDSachUpdateInput.Size = new System.Drawing.Size(180, 55);
            this.panel_IDSachUpdateInput.TabIndex = 40;
            // 
            // textBox_IDSachUpdateInput
            // 
            this.textBox_IDSachUpdateInput.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(221)))), ((int)(((byte)(222)))), ((int)(((byte)(238)))));
            this.textBox_IDSachUpdateInput.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox_IDSachUpdateInput.Enabled = false;
            this.textBox_IDSachUpdateInput.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox_IDSachUpdateInput.Location = new System.Drawing.Point(3, 11);
            this.textBox_IDSachUpdateInput.Margin = new System.Windows.Forms.Padding(4);
            this.textBox_IDSachUpdateInput.Name = "textBox_IDSachUpdateInput";
            this.textBox_IDSachUpdateInput.Size = new System.Drawing.Size(173, 32);
            this.textBox_IDSachUpdateInput.TabIndex = 2;
            // 
            // button_ResetUpdate
            // 
            this.button_ResetUpdate.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(95)))), ((int)(((byte)(105)))));
            this.button_ResetUpdate.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button_ResetUpdate.FlatAppearance.BorderSize = 0;
            this.button_ResetUpdate.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_ResetUpdate.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_ResetUpdate.ForeColor = System.Drawing.Color.White;
            this.button_ResetUpdate.Location = new System.Drawing.Point(1472, 166);
            this.button_ResetUpdate.Margin = new System.Windows.Forms.Padding(4);
            this.button_ResetUpdate.Name = "button_ResetUpdate";
            this.button_ResetUpdate.Size = new System.Drawing.Size(128, 59);
            this.button_ResetUpdate.TabIndex = 42;
            this.button_ResetUpdate.Text = "Reset";
            this.button_ResetUpdate.UseVisualStyleBackColor = false;
            this.button_ResetUpdate.Click += new System.EventHandler(this.button_ResetUpdate_Click);
            // 
            // label_IDSachUpdateInput
            // 
            this.label_IDSachUpdateInput.AutoSize = true;
            this.label_IDSachUpdateInput.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label_IDSachUpdateInput.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_IDSachUpdateInput.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label_IDSachUpdateInput.Location = new System.Drawing.Point(9, 43);
            this.label_IDSachUpdateInput.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_IDSachUpdateInput.Name = "label_IDSachUpdateInput";
            this.label_IDSachUpdateInput.Size = new System.Drawing.Size(111, 32);
            this.label_IDSachUpdateInput.TabIndex = 38;
            this.label_IDSachUpdateInput.Text = "ID Sách *";
            // 
            // button_SaveUpdate
            // 
            this.button_SaveUpdate.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(111)))), ((int)(((byte)(51)))));
            this.button_SaveUpdate.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button_SaveUpdate.FlatAppearance.BorderSize = 0;
            this.button_SaveUpdate.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_SaveUpdate.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_SaveUpdate.ForeColor = System.Drawing.Color.White;
            this.button_SaveUpdate.Location = new System.Drawing.Point(1336, 167);
            this.button_SaveUpdate.Margin = new System.Windows.Forms.Padding(4);
            this.button_SaveUpdate.Name = "button_SaveUpdate";
            this.button_SaveUpdate.Size = new System.Drawing.Size(128, 59);
            this.button_SaveUpdate.TabIndex = 41;
            this.button_SaveUpdate.Text = "Save";
            this.button_SaveUpdate.UseVisualStyleBackColor = false;
            this.button_SaveUpdate.Click += new System.EventHandler(this.button_SaveUpdate_Click);
            // 
            // label_ChinhSuaSach
            // 
            this.label_ChinhSuaSach.AutoSize = true;
            this.label_ChinhSuaSach.BackColor = System.Drawing.Color.White;
            this.label_ChinhSuaSach.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_ChinhSuaSach.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(95)))), ((int)(((byte)(105)))));
            this.label_ChinhSuaSach.Location = new System.Drawing.Point(5, 6);
            this.label_ChinhSuaSach.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_ChinhSuaSach.Name = "label_ChinhSuaSach";
            this.label_ChinhSuaSach.Size = new System.Drawing.Size(185, 32);
            this.label_ChinhSuaSach.TabIndex = 32;
            this.label_ChinhSuaSach.Text = "Chỉnh sửa Sách";
            this.label_ChinhSuaSach.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // panel_SearchFunction
            // 
            this.panel_SearchFunction.BackColor = System.Drawing.Color.White;
            this.panel_SearchFunction.Controls.Add(this.panel_Main);
            this.panel_SearchFunction.Controls.Add(this.panel_Null1);
            this.panel_SearchFunction.Controls.Add(this.panel_Null2);
            this.panel_SearchFunction.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel_SearchFunction.Location = new System.Drawing.Point(0, 0);
            this.panel_SearchFunction.Margin = new System.Windows.Forms.Padding(4);
            this.panel_SearchFunction.Name = "panel_SearchFunction";
            this.panel_SearchFunction.Size = new System.Drawing.Size(1737, 832);
            this.panel_SearchFunction.TabIndex = 2;
            // 
            // timer_ChinhSuaSachTransition
            // 
            this.timer_ChinhSuaSachTransition.Interval = 10;
            this.timer_ChinhSuaSachTransition.Tick += new System.EventHandler(this.timer_ChinhSuaSachTransition_Tick);
            // 
            // button_Add
            // 
            this.button_Add.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.button_Add.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button_Add.FlatAppearance.BorderSize = 0;
            this.button_Add.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_Add.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_Add.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(95)))), ((int)(((byte)(105)))));
            this.button_Add.Image = ((System.Drawing.Image)(resources.GetObject("button_Add.Image")));
            this.button_Add.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button_Add.Location = new System.Drawing.Point(0, 14);
            this.button_Add.Margin = new System.Windows.Forms.Padding(4);
            this.button_Add.Name = "button_Add";
            this.button_Add.Size = new System.Drawing.Size(231, 49);
            this.button_Add.TabIndex = 20;
            this.button_Add.Text = "      Insert/ Delete";
            this.button_Add.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button_Add.UseVisualStyleBackColor = true;
            this.button_Add.Click += new System.EventHandler(this.button_InsertDelete_Click);
            // 
            // pictureBox_Exit
            // 
            this.pictureBox_Exit.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBox_Exit.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBox_Exit.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox_Exit.Image")));
            this.pictureBox_Exit.Location = new System.Drawing.Point(1607, 4);
            this.pictureBox_Exit.Margin = new System.Windows.Forms.Padding(4);
            this.pictureBox_Exit.Name = "pictureBox_Exit";
            this.pictureBox_Exit.Size = new System.Drawing.Size(55, 50);
            this.pictureBox_Exit.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox_Exit.TabIndex = 49;
            this.pictureBox_Exit.TabStop = false;
            this.pictureBox_Exit.Click += new System.EventHandler(this.pictureBox_Exit_Click);
            // 
            // ff_ThongTinSach
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1737, 832);
            this.Controls.Add(this.panel_SearchFunction);
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "ff_ThongTinSach";
            this.Text = "FormThongTinSach";
            this.Resize += new System.EventHandler(this.Form_ChinhSuaSach_Resize);
            this.panel_Search.ResumeLayout(false);
            this.panel_Search.PerformLayout();
            this.panel_Null3.ResumeLayout(false);
            this.panel_Null3.PerformLayout();
            this.panel_PhanTrang.ResumeLayout(false);
            this.panel_PhanTrang.PerformLayout();
            this.panel_Main.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_ChinhSuaSach)).EndInit();
            this.panel_ChinhSuaSach.ResumeLayout(false);
            this.panel_ChinhSuaSach.PerformLayout();
            this.panel_NhaXuatBanUpdateInput.ResumeLayout(false);
            this.panel_NhaXuatBanUpdateInput.PerformLayout();
            this.panel_SoLuongUpdateInput.ResumeLayout(false);
            this.panel_SoLuongUpdateInput.PerformLayout();
            this.panel_NamXuatBanUpdateInput.ResumeLayout(false);
            this.panel_TacGiaUpdateInput.ResumeLayout(false);
            this.panel_TacGiaUpdateInput.PerformLayout();
            this.panel_TheLoaiUpdateInput.ResumeLayout(false);
            this.panel_TheLoaiUpdateInput.PerformLayout();
            this.panel_TenSachUpdateInput.ResumeLayout(false);
            this.panel_TenSachUpdateInput.PerformLayout();
            this.panel_IDSachUpdateInput.ResumeLayout(false);
            this.panel_IDSachUpdateInput.PerformLayout();
            this.panel_SearchFunction.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_Exit)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel_Null2;
        private System.Windows.Forms.Label label_ThongTinSach;
        private System.Windows.Forms.Label label_SearchName;
        private System.Windows.Forms.TextBox textBox_SearchName;
        private System.Windows.Forms.Panel panel_Search;
        private System.Windows.Forms.Button button_ReturnLastPage;
        private System.Windows.Forms.Button button_ReturnFirstPage;
        private System.Windows.Forms.Label label_Previous;
        private System.Windows.Forms.Panel panel_Null3;
        private System.Windows.Forms.Button button_Search;
        private System.Windows.Forms.Button button_ChangePage3;
        private System.Windows.Forms.Label label_Next;
        private System.Windows.Forms.Button button_ChangePage2;
        private System.Windows.Forms.Panel panel_Null1;
        private System.Windows.Forms.Panel panel_PhanTrang;
        private System.Windows.Forms.Button button_ChangePage1;
        private System.Windows.Forms.Panel panel_Main;
        private System.Windows.Forms.DataGridView dataGridView_ChinhSuaSach;
        private System.Windows.Forms.Panel panel_SearchFunction;
        private System.Windows.Forms.Timer timer_ChinhSuaSachTransition;
        private System.Windows.Forms.Panel panel_ChinhSuaSach;
        private System.Windows.Forms.PictureBox pictureBox_Exit;
        private System.Windows.Forms.Panel panel_TheLoaiUpdateInput;
        private System.Windows.Forms.TextBox textBox_TheLoaiUpdateInput;
        private System.Windows.Forms.Label label_TheLoaiUpdateInput;
        private System.Windows.Forms.Panel panel_TenSachUpdateInput;
        private System.Windows.Forms.TextBox textBox_TenSachUpdateInput;
        private System.Windows.Forms.Label label_TenSachUpdateInput;
        private System.Windows.Forms.Panel panel_IDSachUpdateInput;
        private System.Windows.Forms.TextBox textBox_IDSachUpdateInput;
        private System.Windows.Forms.Button button_ResetUpdate;
        private System.Windows.Forms.Label label_IDSachUpdateInput;
        private System.Windows.Forms.Button button_SaveUpdate;
        private System.Windows.Forms.Label label_ChinhSuaSach;
        private System.Windows.Forms.Button button_Add;
        private System.Windows.Forms.Panel panel_TacGiaUpdateInput;
        private System.Windows.Forms.TextBox textBox_TacGiaUpdateInput;
        private System.Windows.Forms.Label label_TacGiaUpdateInput;
        private System.Windows.Forms.Panel panel_NamXuatBanUpdateInput;
        private System.Windows.Forms.DateTimePicker dateTimePicker_NamXuatBanUpdateInput;
        private System.Windows.Forms.Label label_NamXuatBanUpdateInput;
        private System.Windows.Forms.Panel panel_NhaXuatBanUpdateInput;
        private System.Windows.Forms.TextBox textBox_NhaXuatBanUpdateInput;
        private System.Windows.Forms.Label label_NhaXuatBanUpdateInput;
        private System.Windows.Forms.Panel panel_SoLuongUpdateInput;
        private System.Windows.Forms.TextBox textBox_SoLuongUpdateInput;
        private System.Windows.Forms.Label label_SoLuongUpdateInput;
    }
}