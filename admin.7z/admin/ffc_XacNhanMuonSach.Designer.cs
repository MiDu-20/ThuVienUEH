﻿namespace QuanLiThuVienUeh.admin
{
    partial class ffc_XacNhanMuonSach
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            this.label_XacNhanMuonSach = new System.Windows.Forms.Label();
            this.panel_HoVaTenNguoiDung = new System.Windows.Forms.Panel();
            this.textBox_HoVaTenNguoiDung = new System.Windows.Forms.TextBox();
            this.label_HoVaTenNguoiDung = new System.Windows.Forms.Label();
            this.panel_IDNguoiDung = new System.Windows.Forms.Panel();
            this.textBox_IDNguoiDung = new System.Windows.Forms.TextBox();
            this.label_IDNguoiDung = new System.Windows.Forms.Label();
            this.panel_IDSach = new System.Windows.Forms.Panel();
            this.textBox_IDSach = new System.Windows.Forms.TextBox();
            this.label_IDSach = new System.Windows.Forms.Label();
            this.panel_TenSach = new System.Windows.Forms.Panel();
            this.textBox_TenSach = new System.Windows.Forms.TextBox();
            this.label_TenSach = new System.Windows.Forms.Label();
            this.button_ResetInsert = new System.Windows.Forms.Button();
            this.button_SaveInsert = new System.Windows.Forms.Button();
            this.panel_NgayMuonSach = new System.Windows.Forms.Panel();
            this.dateTimePicker_NgayMuonSach = new System.Windows.Forms.DateTimePicker();
            this.label_NgayMuonSach = new System.Windows.Forms.Label();
            this.panel_Null1 = new System.Windows.Forms.Panel();
            this.dataGridView_PhieuMuonSach = new System.Windows.Forms.DataGridView();
            this.panel_Search = new System.Windows.Forms.Panel();
            this.label_SearchName = new System.Windows.Forms.Label();
            this.textBox_SearchName = new System.Windows.Forms.TextBox();
            this.button_ReturnLastPage = new System.Windows.Forms.Button();
            this.button_ReturnFirstPage = new System.Windows.Forms.Button();
            this.label_Previous = new System.Windows.Forms.Label();
            this.button_ChangePage3 = new System.Windows.Forms.Button();
            this.button_ChangePage1 = new System.Windows.Forms.Button();
            this.label_Next = new System.Windows.Forms.Label();
            this.button_ChangePage2 = new System.Windows.Forms.Button();
            this.panel_HoVaTenNguoiDung.SuspendLayout();
            this.panel_IDNguoiDung.SuspendLayout();
            this.panel_IDSach.SuspendLayout();
            this.panel_TenSach.SuspendLayout();
            this.panel_NgayMuonSach.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_PhieuMuonSach)).BeginInit();
            this.panel_Search.SuspendLayout();
            this.SuspendLayout();
            // 
            // label_XacNhanMuonSach
            // 
            this.label_XacNhanMuonSach.AutoSize = true;
            this.label_XacNhanMuonSach.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label_XacNhanMuonSach.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_XacNhanMuonSach.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(95)))), ((int)(((byte)(105)))));
            this.label_XacNhanMuonSach.Location = new System.Drawing.Point(27, 14);
            this.label_XacNhanMuonSach.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_XacNhanMuonSach.Name = "label_XacNhanMuonSach";
            this.label_XacNhanMuonSach.Size = new System.Drawing.Size(251, 32);
            this.label_XacNhanMuonSach.TabIndex = 23;
            this.label_XacNhanMuonSach.Text = "Xác nhận mượn sách";
            // 
            // panel_HoVaTenNguoiDung
            // 
            this.panel_HoVaTenNguoiDung.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(221)))), ((int)(((byte)(222)))), ((int)(((byte)(238)))));
            this.panel_HoVaTenNguoiDung.Controls.Add(this.textBox_HoVaTenNguoiDung);
            this.panel_HoVaTenNguoiDung.ForeColor = System.Drawing.SystemColors.Control;
            this.panel_HoVaTenNguoiDung.Location = new System.Drawing.Point(308, 590);
            this.panel_HoVaTenNguoiDung.Margin = new System.Windows.Forms.Padding(4);
            this.panel_HoVaTenNguoiDung.Name = "panel_HoVaTenNguoiDung";
            this.panel_HoVaTenNguoiDung.Size = new System.Drawing.Size(324, 55);
            this.panel_HoVaTenNguoiDung.TabIndex = 26;
            // 
            // textBox_HoVaTenNguoiDung
            // 
            this.textBox_HoVaTenNguoiDung.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(221)))), ((int)(((byte)(222)))), ((int)(((byte)(238)))));
            this.textBox_HoVaTenNguoiDung.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox_HoVaTenNguoiDung.Enabled = false;
            this.textBox_HoVaTenNguoiDung.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox_HoVaTenNguoiDung.Location = new System.Drawing.Point(3, 11);
            this.textBox_HoVaTenNguoiDung.Margin = new System.Windows.Forms.Padding(4);
            this.textBox_HoVaTenNguoiDung.Name = "textBox_HoVaTenNguoiDung";
            this.textBox_HoVaTenNguoiDung.Size = new System.Drawing.Size(317, 32);
            this.textBox_HoVaTenNguoiDung.TabIndex = 2;
            // 
            // label_HoVaTenNguoiDung
            // 
            this.label_HoVaTenNguoiDung.AutoSize = true;
            this.label_HoVaTenNguoiDung.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label_HoVaTenNguoiDung.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_HoVaTenNguoiDung.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label_HoVaTenNguoiDung.Location = new System.Drawing.Point(303, 549);
            this.label_HoVaTenNguoiDung.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_HoVaTenNguoiDung.Name = "label_HoVaTenNguoiDung";
            this.label_HoVaTenNguoiDung.Size = new System.Drawing.Size(135, 32);
            this.label_HoVaTenNguoiDung.TabIndex = 25;
            this.label_HoVaTenNguoiDung.Text = "Họ và tên *";
            // 
            // panel_IDNguoiDung
            // 
            this.panel_IDNguoiDung.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(221)))), ((int)(((byte)(222)))), ((int)(((byte)(238)))));
            this.panel_IDNguoiDung.Controls.Add(this.textBox_IDNguoiDung);
            this.panel_IDNguoiDung.ForeColor = System.Drawing.SystemColors.Control;
            this.panel_IDNguoiDung.Location = new System.Drawing.Point(33, 590);
            this.panel_IDNguoiDung.Margin = new System.Windows.Forms.Padding(4);
            this.panel_IDNguoiDung.Name = "panel_IDNguoiDung";
            this.panel_IDNguoiDung.Size = new System.Drawing.Size(216, 55);
            this.panel_IDNguoiDung.TabIndex = 28;
            // 
            // textBox_IDNguoiDung
            // 
            this.textBox_IDNguoiDung.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(221)))), ((int)(((byte)(222)))), ((int)(((byte)(238)))));
            this.textBox_IDNguoiDung.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox_IDNguoiDung.Enabled = false;
            this.textBox_IDNguoiDung.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox_IDNguoiDung.Location = new System.Drawing.Point(3, 11);
            this.textBox_IDNguoiDung.Margin = new System.Windows.Forms.Padding(4);
            this.textBox_IDNguoiDung.Name = "textBox_IDNguoiDung";
            this.textBox_IDNguoiDung.Size = new System.Drawing.Size(209, 32);
            this.textBox_IDNguoiDung.TabIndex = 2;
            // 
            // label_IDNguoiDung
            // 
            this.label_IDNguoiDung.AutoSize = true;
            this.label_IDNguoiDung.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label_IDNguoiDung.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_IDNguoiDung.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label_IDNguoiDung.Location = new System.Drawing.Point(28, 549);
            this.label_IDNguoiDung.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_IDNguoiDung.Name = "label_IDNguoiDung";
            this.label_IDNguoiDung.Size = new System.Drawing.Size(94, 32);
            this.label_IDNguoiDung.TabIndex = 27;
            this.label_IDNguoiDung.Text = "MSSV *";
            // 
            // panel_IDSach
            // 
            this.panel_IDSach.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(221)))), ((int)(((byte)(222)))), ((int)(((byte)(238)))));
            this.panel_IDSach.Controls.Add(this.textBox_IDSach);
            this.panel_IDSach.ForeColor = System.Drawing.SystemColors.Control;
            this.panel_IDSach.Location = new System.Drawing.Point(692, 590);
            this.panel_IDSach.Margin = new System.Windows.Forms.Padding(4);
            this.panel_IDSach.Name = "panel_IDSach";
            this.panel_IDSach.Size = new System.Drawing.Size(147, 55);
            this.panel_IDSach.TabIndex = 32;
            // 
            // textBox_IDSach
            // 
            this.textBox_IDSach.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(221)))), ((int)(((byte)(222)))), ((int)(((byte)(238)))));
            this.textBox_IDSach.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox_IDSach.Enabled = false;
            this.textBox_IDSach.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox_IDSach.Location = new System.Drawing.Point(3, 11);
            this.textBox_IDSach.Margin = new System.Windows.Forms.Padding(4);
            this.textBox_IDSach.Name = "textBox_IDSach";
            this.textBox_IDSach.Size = new System.Drawing.Size(140, 32);
            this.textBox_IDSach.TabIndex = 2;
            // 
            // label_IDSach
            // 
            this.label_IDSach.AutoSize = true;
            this.label_IDSach.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label_IDSach.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_IDSach.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label_IDSach.Location = new System.Drawing.Point(687, 549);
            this.label_IDSach.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_IDSach.Name = "label_IDSach";
            this.label_IDSach.Size = new System.Drawing.Size(111, 32);
            this.label_IDSach.TabIndex = 31;
            this.label_IDSach.Text = "ID Sách *";
            // 
            // panel_TenSach
            // 
            this.panel_TenSach.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(221)))), ((int)(((byte)(222)))), ((int)(((byte)(238)))));
            this.panel_TenSach.Controls.Add(this.textBox_TenSach);
            this.panel_TenSach.ForeColor = System.Drawing.SystemColors.Control;
            this.panel_TenSach.Location = new System.Drawing.Point(885, 590);
            this.panel_TenSach.Margin = new System.Windows.Forms.Padding(4);
            this.panel_TenSach.Name = "panel_TenSach";
            this.panel_TenSach.Size = new System.Drawing.Size(324, 55);
            this.panel_TenSach.TabIndex = 28;
            // 
            // textBox_TenSach
            // 
            this.textBox_TenSach.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(221)))), ((int)(((byte)(222)))), ((int)(((byte)(238)))));
            this.textBox_TenSach.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox_TenSach.Enabled = false;
            this.textBox_TenSach.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox_TenSach.Location = new System.Drawing.Point(3, 11);
            this.textBox_TenSach.Margin = new System.Windows.Forms.Padding(4);
            this.textBox_TenSach.Name = "textBox_TenSach";
            this.textBox_TenSach.Size = new System.Drawing.Size(317, 32);
            this.textBox_TenSach.TabIndex = 2;
            // 
            // label_TenSach
            // 
            this.label_TenSach.AutoSize = true;
            this.label_TenSach.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label_TenSach.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_TenSach.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label_TenSach.Location = new System.Drawing.Point(880, 549);
            this.label_TenSach.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_TenSach.Name = "label_TenSach";
            this.label_TenSach.Size = new System.Drawing.Size(123, 32);
            this.label_TenSach.TabIndex = 27;
            this.label_TenSach.Text = "Tên sách *";
            // 
            // button_ResetInsert
            // 
            this.button_ResetInsert.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(95)))), ((int)(((byte)(105)))));
            this.button_ResetInsert.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button_ResetInsert.FlatAppearance.BorderSize = 0;
            this.button_ResetInsert.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_ResetInsert.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_ResetInsert.ForeColor = System.Drawing.Color.White;
            this.button_ResetInsert.Location = new System.Drawing.Point(1080, 715);
            this.button_ResetInsert.Margin = new System.Windows.Forms.Padding(4);
            this.button_ResetInsert.Name = "button_ResetInsert";
            this.button_ResetInsert.Size = new System.Drawing.Size(128, 59);
            this.button_ResetInsert.TabIndex = 34;
            this.button_ResetInsert.Text = "Reset";
            this.button_ResetInsert.UseVisualStyleBackColor = false;
            this.button_ResetInsert.Click += new System.EventHandler(this.button_ResetInsert_Click);
            // 
            // button_SaveInsert
            // 
            this.button_SaveInsert.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(111)))), ((int)(((byte)(51)))));
            this.button_SaveInsert.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button_SaveInsert.FlatAppearance.BorderSize = 0;
            this.button_SaveInsert.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_SaveInsert.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_SaveInsert.ForeColor = System.Drawing.Color.White;
            this.button_SaveInsert.Location = new System.Drawing.Point(944, 716);
            this.button_SaveInsert.Margin = new System.Windows.Forms.Padding(4);
            this.button_SaveInsert.Name = "button_SaveInsert";
            this.button_SaveInsert.Size = new System.Drawing.Size(128, 59);
            this.button_SaveInsert.TabIndex = 33;
            this.button_SaveInsert.Text = "Save";
            this.button_SaveInsert.UseVisualStyleBackColor = false;
            this.button_SaveInsert.Click += new System.EventHandler(this.button_SaveInsert_Click);
            // 
            // panel_NgayMuonSach
            // 
            this.panel_NgayMuonSach.BackColor = System.Drawing.Color.White;
            this.panel_NgayMuonSach.Controls.Add(this.dateTimePicker_NgayMuonSach);
            this.panel_NgayMuonSach.ForeColor = System.Drawing.SystemColors.Control;
            this.panel_NgayMuonSach.Location = new System.Drawing.Point(33, 720);
            this.panel_NgayMuonSach.Margin = new System.Windows.Forms.Padding(4);
            this.panel_NgayMuonSach.Name = "panel_NgayMuonSach";
            this.panel_NgayMuonSach.Size = new System.Drawing.Size(308, 55);
            this.panel_NgayMuonSach.TabIndex = 36;
            // 
            // dateTimePicker_NgayMuonSach
            // 
            this.dateTimePicker_NgayMuonSach.CalendarFont = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dateTimePicker_NgayMuonSach.CalendarForeColor = System.Drawing.Color.White;
            this.dateTimePicker_NgayMuonSach.CalendarTitleBackColor = System.Drawing.Color.White;
            this.dateTimePicker_NgayMuonSach.CustomFormat = "dd/MM/yyyy";
            this.dateTimePicker_NgayMuonSach.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dateTimePicker_NgayMuonSach.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dateTimePicker_NgayMuonSach.Location = new System.Drawing.Point(1, 7);
            this.dateTimePicker_NgayMuonSach.Margin = new System.Windows.Forms.Padding(4);
            this.dateTimePicker_NgayMuonSach.Name = "dateTimePicker_NgayMuonSach";
            this.dateTimePicker_NgayMuonSach.Size = new System.Drawing.Size(305, 39);
            this.dateTimePicker_NgayMuonSach.TabIndex = 3;
            this.dateTimePicker_NgayMuonSach.Value = new System.DateTime(2024, 3, 8, 0, 0, 0, 0);
            // 
            // label_NgayMuonSach
            // 
            this.label_NgayMuonSach.AutoSize = true;
            this.label_NgayMuonSach.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label_NgayMuonSach.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_NgayMuonSach.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label_NgayMuonSach.Location = new System.Drawing.Point(28, 678);
            this.label_NgayMuonSach.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_NgayMuonSach.Name = "label_NgayMuonSach";
            this.label_NgayMuonSach.Size = new System.Drawing.Size(211, 32);
            this.label_NgayMuonSach.TabIndex = 35;
            this.label_NgayMuonSach.Text = "Ngày mượn sách *";
            // 
            // panel_Null1
            // 
            this.panel_Null1.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel_Null1.Location = new System.Drawing.Point(0, 0);
            this.panel_Null1.Margin = new System.Windows.Forms.Padding(4);
            this.panel_Null1.Name = "panel_Null1";
            this.panel_Null1.Size = new System.Drawing.Size(28, 791);
            this.panel_Null1.TabIndex = 37;
            // 
            // dataGridView_PhieuMuonSach
            // 
            this.dataGridView_PhieuMuonSach.AllowUserToAddRows = false;
            this.dataGridView_PhieuMuonSach.AllowUserToDeleteRows = false;
            this.dataGridView_PhieuMuonSach.AllowUserToResizeColumns = false;
            this.dataGridView_PhieuMuonSach.AllowUserToResizeRows = false;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.White;
            this.dataGridView_PhieuMuonSach.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.dataGridView_PhieuMuonSach.BackgroundColor = System.Drawing.Color.White;
            this.dataGridView_PhieuMuonSach.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(111)))), ((int)(((byte)(51)))));
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.Color.White;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView_PhieuMuonSach.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            this.dataGridView_PhieuMuonSach.ColumnHeadersHeight = 40;
            this.dataGridView_PhieuMuonSach.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            this.dataGridView_PhieuMuonSach.Cursor = System.Windows.Forms.Cursors.Hand;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle3.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridView_PhieuMuonSach.DefaultCellStyle = dataGridViewCellStyle3;
            this.dataGridView_PhieuMuonSach.EnableHeadersVisualStyles = false;
            this.dataGridView_PhieuMuonSach.GridColor = System.Drawing.Color.White;
            this.dataGridView_PhieuMuonSach.Location = new System.Drawing.Point(33, 114);
            this.dataGridView_PhieuMuonSach.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.dataGridView_PhieuMuonSach.MultiSelect = false;
            this.dataGridView_PhieuMuonSach.Name = "dataGridView_PhieuMuonSach";
            this.dataGridView_PhieuMuonSach.ReadOnly = true;
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle4.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle4.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle4.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle4.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle4.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView_PhieuMuonSach.RowHeadersDefaultCellStyle = dataGridViewCellStyle4;
            this.dataGridView_PhieuMuonSach.RowHeadersVisible = false;
            this.dataGridView_PhieuMuonSach.RowHeadersWidth = 100;
            this.dataGridView_PhieuMuonSach.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            dataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle5.BackColor = System.Drawing.Color.DimGray;
            dataGridViewCellStyle5.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(95)))), ((int)(((byte)(105)))));
            this.dataGridView_PhieuMuonSach.RowsDefaultCellStyle = dataGridViewCellStyle5;
            this.dataGridView_PhieuMuonSach.RowTemplate.DefaultCellStyle.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.dataGridView_PhieuMuonSach.RowTemplate.DefaultCellStyle.BackColor = System.Drawing.Color.White;
            this.dataGridView_PhieuMuonSach.RowTemplate.Height = 24;
            this.dataGridView_PhieuMuonSach.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView_PhieuMuonSach.Size = new System.Drawing.Size(1176, 342);
            this.dataGridView_PhieuMuonSach.TabIndex = 38;
            this.dataGridView_PhieuMuonSach.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView_PhieuMuonSach_CellClick);
            this.dataGridView_PhieuMuonSach.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView_PhieuMuonSach_CellDoubleClick);
            // 
            // panel_Search
            // 
            this.panel_Search.BackColor = System.Drawing.Color.Gainsboro;
            this.panel_Search.Controls.Add(this.label_SearchName);
            this.panel_Search.Controls.Add(this.textBox_SearchName);
            this.panel_Search.Location = new System.Drawing.Point(35, 60);
            this.panel_Search.Margin = new System.Windows.Forms.Padding(4);
            this.panel_Search.Name = "panel_Search";
            this.panel_Search.Size = new System.Drawing.Size(640, 48);
            this.panel_Search.TabIndex = 39;
            // 
            // label_SearchName
            // 
            this.label_SearchName.AutoSize = true;
            this.label_SearchName.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.label_SearchName.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_SearchName.ForeColor = System.Drawing.Color.DimGray;
            this.label_SearchName.Location = new System.Drawing.Point(16, 10);
            this.label_SearchName.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_SearchName.Name = "label_SearchName";
            this.label_SearchName.Size = new System.Drawing.Size(243, 28);
            this.label_SearchName.TabIndex = 10;
            this.label_SearchName.Text = "Search by id, name, book...";
            this.label_SearchName.Click += new System.EventHandler(this.label_SearchName_Click);
            // 
            // textBox_SearchName
            // 
            this.textBox_SearchName.BackColor = System.Drawing.Color.Gainsboro;
            this.textBox_SearchName.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox_SearchName.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox_SearchName.Location = new System.Drawing.Point(3, 10);
            this.textBox_SearchName.Margin = new System.Windows.Forms.Padding(4);
            this.textBox_SearchName.Name = "textBox_SearchName";
            this.textBox_SearchName.Size = new System.Drawing.Size(633, 27);
            this.textBox_SearchName.TabIndex = 7;
            this.textBox_SearchName.Click += new System.EventHandler(this.textBox_SearchName_Click);
            this.textBox_SearchName.TextChanged += new System.EventHandler(this.textBox_SearchName_TextChanged);
            // 
            // button_ReturnLastPage
            // 
            this.button_ReturnLastPage.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.button_ReturnLastPage.BackColor = System.Drawing.Color.White;
            this.button_ReturnLastPage.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button_ReturnLastPage.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(111)))), ((int)(((byte)(51)))));
            this.button_ReturnLastPage.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(95)))), ((int)(((byte)(105)))));
            this.button_ReturnLastPage.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_ReturnLastPage.Font = new System.Drawing.Font("Segoe UI Black", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_ReturnLastPage.ForeColor = System.Drawing.Color.Black;
            this.button_ReturnLastPage.Location = new System.Drawing.Point(1081, 469);
            this.button_ReturnLastPage.Margin = new System.Windows.Forms.Padding(4);
            this.button_ReturnLastPage.Name = "button_ReturnLastPage";
            this.button_ReturnLastPage.Size = new System.Drawing.Size(53, 49);
            this.button_ReturnLastPage.TabIndex = 46;
            this.button_ReturnLastPage.Text = ">>";
            this.button_ReturnLastPage.UseVisualStyleBackColor = false;
            this.button_ReturnLastPage.Click += new System.EventHandler(this.button_ReturnLastPage_Click);
            // 
            // button_ReturnFirstPage
            // 
            this.button_ReturnFirstPage.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.button_ReturnFirstPage.BackColor = System.Drawing.Color.White;
            this.button_ReturnFirstPage.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button_ReturnFirstPage.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(111)))), ((int)(((byte)(51)))));
            this.button_ReturnFirstPage.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(95)))), ((int)(((byte)(105)))));
            this.button_ReturnFirstPage.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_ReturnFirstPage.Font = new System.Drawing.Font("Segoe UI Black", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_ReturnFirstPage.ForeColor = System.Drawing.Color.Black;
            this.button_ReturnFirstPage.Location = new System.Drawing.Point(768, 469);
            this.button_ReturnFirstPage.Margin = new System.Windows.Forms.Padding(4);
            this.button_ReturnFirstPage.Name = "button_ReturnFirstPage";
            this.button_ReturnFirstPage.Size = new System.Drawing.Size(53, 49);
            this.button_ReturnFirstPage.TabIndex = 45;
            this.button_ReturnFirstPage.Text = "<<";
            this.button_ReturnFirstPage.UseVisualStyleBackColor = false;
            this.button_ReturnFirstPage.Click += new System.EventHandler(this.button_ReturnFirstPage_Click);
            // 
            // label_Previous
            // 
            this.label_Previous.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.label_Previous.AutoSize = true;
            this.label_Previous.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label_Previous.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_Previous.Location = new System.Drawing.Point(649, 479);
            this.label_Previous.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_Previous.Name = "label_Previous";
            this.label_Previous.Size = new System.Drawing.Size(104, 32);
            this.label_Previous.TabIndex = 40;
            this.label_Previous.Text = "Previous";
            // 
            // button_ChangePage3
            // 
            this.button_ChangePage3.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.button_ChangePage3.BackColor = System.Drawing.Color.White;
            this.button_ChangePage3.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button_ChangePage3.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(111)))), ((int)(((byte)(51)))));
            this.button_ChangePage3.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(95)))), ((int)(((byte)(105)))));
            this.button_ChangePage3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_ChangePage3.Font = new System.Drawing.Font("Segoe UI Semibold", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_ChangePage3.ForeColor = System.Drawing.Color.Black;
            this.button_ChangePage3.Location = new System.Drawing.Point(1004, 469);
            this.button_ChangePage3.Margin = new System.Windows.Forms.Padding(4);
            this.button_ChangePage3.Name = "button_ChangePage3";
            this.button_ChangePage3.Size = new System.Drawing.Size(53, 49);
            this.button_ChangePage3.TabIndex = 44;
            this.button_ChangePage3.Text = "3";
            this.button_ChangePage3.UseVisualStyleBackColor = false;
            this.button_ChangePage3.Click += new System.EventHandler(this.button_ChangePage3_Click);
            // 
            // button_ChangePage1
            // 
            this.button_ChangePage1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.button_ChangePage1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(95)))), ((int)(((byte)(105)))));
            this.button_ChangePage1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button_ChangePage1.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(111)))), ((int)(((byte)(51)))));
            this.button_ChangePage1.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(95)))), ((int)(((byte)(105)))));
            this.button_ChangePage1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_ChangePage1.Font = new System.Drawing.Font("Segoe UI Semibold", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_ChangePage1.ForeColor = System.Drawing.Color.White;
            this.button_ChangePage1.Location = new System.Drawing.Point(848, 469);
            this.button_ChangePage1.Margin = new System.Windows.Forms.Padding(4);
            this.button_ChangePage1.Name = "button_ChangePage1";
            this.button_ChangePage1.Size = new System.Drawing.Size(53, 49);
            this.button_ChangePage1.TabIndex = 41;
            this.button_ChangePage1.Text = "1";
            this.button_ChangePage1.UseVisualStyleBackColor = false;
            this.button_ChangePage1.Click += new System.EventHandler(this.button_ChangePage1_Click);
            // 
            // label_Next
            // 
            this.label_Next.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.label_Next.AutoSize = true;
            this.label_Next.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label_Next.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_Next.Location = new System.Drawing.Point(1141, 479);
            this.label_Next.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_Next.Name = "label_Next";
            this.label_Next.Size = new System.Drawing.Size(64, 32);
            this.label_Next.TabIndex = 43;
            this.label_Next.Text = "Next";
            // 
            // button_ChangePage2
            // 
            this.button_ChangePage2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.button_ChangePage2.BackColor = System.Drawing.Color.White;
            this.button_ChangePage2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button_ChangePage2.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(111)))), ((int)(((byte)(51)))));
            this.button_ChangePage2.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(95)))), ((int)(((byte)(105)))));
            this.button_ChangePage2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_ChangePage2.Font = new System.Drawing.Font("Segoe UI Semibold", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_ChangePage2.ForeColor = System.Drawing.Color.Black;
            this.button_ChangePage2.Location = new System.Drawing.Point(927, 469);
            this.button_ChangePage2.Margin = new System.Windows.Forms.Padding(4);
            this.button_ChangePage2.Name = "button_ChangePage2";
            this.button_ChangePage2.Size = new System.Drawing.Size(53, 49);
            this.button_ChangePage2.TabIndex = 42;
            this.button_ChangePage2.Text = "2";
            this.button_ChangePage2.UseVisualStyleBackColor = false;
            this.button_ChangePage2.Click += new System.EventHandler(this.button_ChangePage2_Click);
            // 
            // ffc_XacNhanMuonSach
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1244, 791);
            this.Controls.Add(this.button_ReturnLastPage);
            this.Controls.Add(this.button_ReturnFirstPage);
            this.Controls.Add(this.label_Previous);
            this.Controls.Add(this.button_ChangePage3);
            this.Controls.Add(this.button_ChangePage1);
            this.Controls.Add(this.label_Next);
            this.Controls.Add(this.button_ChangePage2);
            this.Controls.Add(this.panel_Search);
            this.Controls.Add(this.dataGridView_PhieuMuonSach);
            this.Controls.Add(this.panel_Null1);
            this.Controls.Add(this.panel_NgayMuonSach);
            this.Controls.Add(this.label_NgayMuonSach);
            this.Controls.Add(this.button_ResetInsert);
            this.Controls.Add(this.button_SaveInsert);
            this.Controls.Add(this.panel_TenSach);
            this.Controls.Add(this.label_TenSach);
            this.Controls.Add(this.panel_IDSach);
            this.Controls.Add(this.panel_IDNguoiDung);
            this.Controls.Add(this.label_IDSach);
            this.Controls.Add(this.label_IDNguoiDung);
            this.Controls.Add(this.panel_HoVaTenNguoiDung);
            this.Controls.Add(this.label_HoVaTenNguoiDung);
            this.Controls.Add(this.label_XacNhanMuonSach);
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "ffc_XacNhanMuonSach";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "XacNhanMuonSach";
            this.Load += new System.EventHandler(this.ffc_XacNhanMuonSach_Load);
            this.panel_HoVaTenNguoiDung.ResumeLayout(false);
            this.panel_HoVaTenNguoiDung.PerformLayout();
            this.panel_IDNguoiDung.ResumeLayout(false);
            this.panel_IDNguoiDung.PerformLayout();
            this.panel_IDSach.ResumeLayout(false);
            this.panel_IDSach.PerformLayout();
            this.panel_TenSach.ResumeLayout(false);
            this.panel_TenSach.PerformLayout();
            this.panel_NgayMuonSach.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_PhieuMuonSach)).EndInit();
            this.panel_Search.ResumeLayout(false);
            this.panel_Search.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label label_XacNhanMuonSach;
        private System.Windows.Forms.Panel panel_HoVaTenNguoiDung;
        private System.Windows.Forms.TextBox textBox_HoVaTenNguoiDung;
        private System.Windows.Forms.Label label_HoVaTenNguoiDung;
        private System.Windows.Forms.Panel panel_IDNguoiDung;
        private System.Windows.Forms.TextBox textBox_IDNguoiDung;
        private System.Windows.Forms.Label label_IDNguoiDung;
        private System.Windows.Forms.Panel panel_IDSach;
        private System.Windows.Forms.TextBox textBox_IDSach;
        private System.Windows.Forms.Label label_IDSach;
        private System.Windows.Forms.Panel panel_TenSach;
        private System.Windows.Forms.TextBox textBox_TenSach;
        private System.Windows.Forms.Label label_TenSach;
        private System.Windows.Forms.Button button_ResetInsert;
        private System.Windows.Forms.Button button_SaveInsert;
        private System.Windows.Forms.Panel panel_NgayMuonSach;
        private System.Windows.Forms.DateTimePicker dateTimePicker_NgayMuonSach;
        private System.Windows.Forms.Label label_NgayMuonSach;
        private System.Windows.Forms.Panel panel_Null1;
        private System.Windows.Forms.DataGridView dataGridView_PhieuMuonSach;
        private System.Windows.Forms.Panel panel_Search;
        private System.Windows.Forms.Label label_SearchName;
        private System.Windows.Forms.TextBox textBox_SearchName;
        private System.Windows.Forms.Button button_ReturnLastPage;
        private System.Windows.Forms.Button button_ReturnFirstPage;
        private System.Windows.Forms.Label label_Previous;
        private System.Windows.Forms.Button button_ChangePage3;
        private System.Windows.Forms.Button button_ChangePage1;
        private System.Windows.Forms.Label label_Next;
        private System.Windows.Forms.Button button_ChangePage2;
    }
}