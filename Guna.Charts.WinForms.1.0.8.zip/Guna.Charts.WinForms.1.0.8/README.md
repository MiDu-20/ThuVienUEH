﻿WARNING: PLEASE BE CAREFUL WITH FAKE PACKAGES! 
Please visit 'https://www.nuget.org/profiles/Sobatdata' to check the authenticity of the package.

A modern WinForms charting library that lets you easily build interactive data visualizations.

16 chart types:
- Visualize your data in 16 different chart types (Area, Bar, Bubble, Doughnut, HorizontalBar, Line, Pie, PolarArea, Radar, Scatter, Spline, SplineArea, StackedBar, StackedHorizontalBar, SteppedArea, SteppedLine).

Responsive:
- Easily respond to changes in screen size.

Live charts:
- Creating a real-time data dashboard is now very easy.

Mixed chart types:
- Mix several chart types such as Bar and Line/Area.



## .NET
- .NET Framework v4.0 or higher
- .NETCoreApp 3.1 or higher
- .NET 6

## IDE
- Visual Studio 2012 or higger
 
## Links
- [Homepage](https://gunaui.com/)  
- [Demos](https://github.com/sobatdata/GunaChartExamples)
- [Nuget Profile](https://www.nuget.org/profiles/Sobatdata)
- [Youtube](https://www.youtube.com/@gunaui4933/)