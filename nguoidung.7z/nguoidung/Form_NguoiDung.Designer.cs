﻿namespace QuanLiThuVienUeh
{
    partial class Form_NguoiDung
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form_NguoiDung));
            this.panel_Sidebar = new System.Windows.Forms.Panel();
            this.panel_LogoutButton = new System.Windows.Forms.Panel();
            this.button_Logout = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.button_ChangePassword = new System.Windows.Forms.Button();
            this.panel_SettingButton = new System.Windows.Forms.Panel();
            this.panel_Null4 = new System.Windows.Forms.Panel();
            this.button_Null2 = new System.Windows.Forms.Button();
            this.panel_Null3 = new System.Windows.Forms.Panel();
            this.button_Null1 = new System.Windows.Forms.Button();
            this.panel_Null2 = new System.Windows.Forms.Panel();
            this.panel_Null1 = new System.Windows.Forms.Panel();
            this.panel_RatingButton = new System.Windows.Forms.Panel();
            this.panel_HistoryButton = new System.Windows.Forms.Panel();
            this.button_History = new System.Windows.Forms.Button();
            this.panel_BookingButton = new System.Windows.Forms.Panel();
            this.button_Booking = new System.Windows.Forms.Button();
            this.panel_SearchingButton = new System.Windows.Forms.Panel();
            this.button_Searching = new System.Windows.Forms.Button();
            this.panel_ProfileButton = new System.Windows.Forms.Panel();
            this.button_Profile = new System.Windows.Forms.Button();
            this.panel_HomeButton = new System.Windows.Forms.Panel();
            this.button_Home = new System.Windows.Forms.Button();
            this.panel_LogoUeh = new System.Windows.Forms.Panel();
            this.pictureBox_LogoUeh = new System.Windows.Forms.PictureBox();
            this.pictureBox_MenuIcon = new System.Windows.Forms.PictureBox();
            this.panel_SearchContainer = new System.Windows.Forms.Panel();
            this.panel_SearchFunction = new System.Windows.Forms.Panel();
            this.label_SearchFunction = new System.Windows.Forms.Label();
            this.pictureBox_SearchIcon = new System.Windows.Forms.PictureBox();
            this.textBox_SearchFunction = new System.Windows.Forms.TextBox();
            this.panel_ChildForm = new System.Windows.Forms.Panel();
            this.panel_Sidebar.SuspendLayout();
            this.panel_LogoutButton.SuspendLayout();
            this.panel1.SuspendLayout();
            this.panel_Null4.SuspendLayout();
            this.panel_Null3.SuspendLayout();
            this.panel_HistoryButton.SuspendLayout();
            this.panel_BookingButton.SuspendLayout();
            this.panel_SearchingButton.SuspendLayout();
            this.panel_ProfileButton.SuspendLayout();
            this.panel_HomeButton.SuspendLayout();
            this.panel_LogoUeh.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_LogoUeh)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_MenuIcon)).BeginInit();
            this.panel_SearchContainer.SuspendLayout();
            this.panel_SearchFunction.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_SearchIcon)).BeginInit();
            this.SuspendLayout();
            // 
            // panel_Sidebar
            // 
            this.panel_Sidebar.Controls.Add(this.panel_LogoutButton);
            this.panel_Sidebar.Controls.Add(this.panel1);
            this.panel_Sidebar.Controls.Add(this.panel_SettingButton);
            this.panel_Sidebar.Controls.Add(this.panel_Null4);
            this.panel_Sidebar.Controls.Add(this.panel_Null3);
            this.panel_Sidebar.Controls.Add(this.panel_Null2);
            this.panel_Sidebar.Controls.Add(this.panel_Null1);
            this.panel_Sidebar.Controls.Add(this.panel_RatingButton);
            this.panel_Sidebar.Controls.Add(this.panel_HistoryButton);
            this.panel_Sidebar.Controls.Add(this.panel_BookingButton);
            this.panel_Sidebar.Controls.Add(this.panel_SearchingButton);
            this.panel_Sidebar.Controls.Add(this.panel_ProfileButton);
            this.panel_Sidebar.Controls.Add(this.panel_HomeButton);
            this.panel_Sidebar.Controls.Add(this.panel_LogoUeh);
            this.panel_Sidebar.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel_Sidebar.Location = new System.Drawing.Point(0, 0);
            this.panel_Sidebar.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panel_Sidebar.Name = "panel_Sidebar";
            this.panel_Sidebar.Size = new System.Drawing.Size(289, 1014);
            this.panel_Sidebar.TabIndex = 13;
            // 
            // panel_LogoutButton
            // 
            this.panel_LogoutButton.Controls.Add(this.button_Logout);
            this.panel_LogoutButton.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel_LogoutButton.Location = new System.Drawing.Point(0, 794);
            this.panel_LogoutButton.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panel_LogoutButton.Name = "panel_LogoutButton";
            this.panel_LogoutButton.Size = new System.Drawing.Size(289, 57);
            this.panel_LogoutButton.TabIndex = 20;
            // 
            // button_Logout
            // 
            this.button_Logout.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button_Logout.FlatAppearance.BorderSize = 0;
            this.button_Logout.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_Logout.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_Logout.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(95)))), ((int)(((byte)(105)))));
            this.button_Logout.Image = ((System.Drawing.Image)(resources.GetObject("button_Logout.Image")));
            this.button_Logout.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button_Logout.Location = new System.Drawing.Point(31, 2);
            this.button_Logout.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.button_Logout.Name = "button_Logout";
            this.button_Logout.Size = new System.Drawing.Size(223, 48);
            this.button_Logout.TabIndex = 14;
            this.button_Logout.Text = "         Log Out";
            this.button_Logout.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button_Logout.UseVisualStyleBackColor = true;
            this.button_Logout.Click += new System.EventHandler(this.button_Logout_Click);
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.button_ChangePassword);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 737);
            this.panel1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(289, 57);
            this.panel1.TabIndex = 21;
            // 
            // button_ChangePassword
            // 
            this.button_ChangePassword.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button_ChangePassword.FlatAppearance.BorderSize = 0;
            this.button_ChangePassword.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_ChangePassword.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_ChangePassword.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(95)))), ((int)(((byte)(105)))));
            this.button_ChangePassword.Image = ((System.Drawing.Image)(resources.GetObject("button_ChangePassword.Image")));
            this.button_ChangePassword.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button_ChangePassword.Location = new System.Drawing.Point(21, 2);
            this.button_ChangePassword.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.button_ChangePassword.Name = "button_ChangePassword";
            this.button_ChangePassword.Size = new System.Drawing.Size(241, 48);
            this.button_ChangePassword.TabIndex = 14;
            this.button_ChangePassword.Text = "      Change Password";
            this.button_ChangePassword.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button_ChangePassword.UseVisualStyleBackColor = true;
            this.button_ChangePassword.Click += new System.EventHandler(this.button_ChangePassword_Click);
            // 
            // panel_SettingButton
            // 
            this.panel_SettingButton.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel_SettingButton.Location = new System.Drawing.Point(0, 680);
            this.panel_SettingButton.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panel_SettingButton.Name = "panel_SettingButton";
            this.panel_SettingButton.Size = new System.Drawing.Size(289, 57);
            this.panel_SettingButton.TabIndex = 19;
            // 
            // panel_Null4
            // 
            this.panel_Null4.Controls.Add(this.button_Null2);
            this.panel_Null4.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel_Null4.Location = new System.Drawing.Point(0, 623);
            this.panel_Null4.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panel_Null4.Name = "panel_Null4";
            this.panel_Null4.Size = new System.Drawing.Size(289, 57);
            this.panel_Null4.TabIndex = 18;
            // 
            // button_Null2
            // 
            this.button_Null2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button_Null2.Enabled = false;
            this.button_Null2.FlatAppearance.BorderSize = 0;
            this.button_Null2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_Null2.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_Null2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(95)))), ((int)(((byte)(105)))));
            this.button_Null2.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button_Null2.Location = new System.Drawing.Point(31, 2);
            this.button_Null2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.button_Null2.Name = "button_Null2";
            this.button_Null2.Size = new System.Drawing.Size(223, 48);
            this.button_Null2.TabIndex = 14;
            this.button_Null2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button_Null2.UseVisualStyleBackColor = true;
            // 
            // panel_Null3
            // 
            this.panel_Null3.Controls.Add(this.button_Null1);
            this.panel_Null3.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel_Null3.Enabled = false;
            this.panel_Null3.Location = new System.Drawing.Point(0, 566);
            this.panel_Null3.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panel_Null3.Name = "panel_Null3";
            this.panel_Null3.Size = new System.Drawing.Size(289, 57);
            this.panel_Null3.TabIndex = 17;
            // 
            // button_Null1
            // 
            this.button_Null1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button_Null1.FlatAppearance.BorderSize = 0;
            this.button_Null1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_Null1.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_Null1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(95)))), ((int)(((byte)(105)))));
            this.button_Null1.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button_Null1.Location = new System.Drawing.Point(31, 2);
            this.button_Null1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.button_Null1.Name = "button_Null1";
            this.button_Null1.Size = new System.Drawing.Size(223, 48);
            this.button_Null1.TabIndex = 14;
            this.button_Null1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button_Null1.UseVisualStyleBackColor = true;
            // 
            // panel_Null2
            // 
            this.panel_Null2.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel_Null2.Location = new System.Drawing.Point(0, 509);
            this.panel_Null2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panel_Null2.Name = "panel_Null2";
            this.panel_Null2.Size = new System.Drawing.Size(289, 57);
            this.panel_Null2.TabIndex = 17;
            // 
            // panel_Null1
            // 
            this.panel_Null1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel_Null1.Location = new System.Drawing.Point(0, 452);
            this.panel_Null1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panel_Null1.Name = "panel_Null1";
            this.panel_Null1.Size = new System.Drawing.Size(289, 57);
            this.panel_Null1.TabIndex = 16;
            // 
            // panel_RatingButton
            // 
            this.panel_RatingButton.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel_RatingButton.Location = new System.Drawing.Point(0, 395);
            this.panel_RatingButton.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panel_RatingButton.Name = "panel_RatingButton";
            this.panel_RatingButton.Size = new System.Drawing.Size(289, 57);
            this.panel_RatingButton.TabIndex = 16;
            // 
            // panel_HistoryButton
            // 
            this.panel_HistoryButton.Controls.Add(this.button_History);
            this.panel_HistoryButton.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel_HistoryButton.Location = new System.Drawing.Point(0, 338);
            this.panel_HistoryButton.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panel_HistoryButton.Name = "panel_HistoryButton";
            this.panel_HistoryButton.Size = new System.Drawing.Size(289, 57);
            this.panel_HistoryButton.TabIndex = 16;
            // 
            // button_History
            // 
            this.button_History.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button_History.FlatAppearance.BorderSize = 0;
            this.button_History.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_History.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_History.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(95)))), ((int)(((byte)(105)))));
            this.button_History.Image = ((System.Drawing.Image)(resources.GetObject("button_History.Image")));
            this.button_History.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button_History.Location = new System.Drawing.Point(31, 2);
            this.button_History.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.button_History.Name = "button_History";
            this.button_History.Size = new System.Drawing.Size(221, 48);
            this.button_History.TabIndex = 14;
            this.button_History.Text = "         History";
            this.button_History.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button_History.UseVisualStyleBackColor = true;
            this.button_History.Click += new System.EventHandler(this.button_History_Click);
            // 
            // panel_BookingButton
            // 
            this.panel_BookingButton.Controls.Add(this.button_Booking);
            this.panel_BookingButton.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel_BookingButton.Location = new System.Drawing.Point(0, 281);
            this.panel_BookingButton.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panel_BookingButton.Name = "panel_BookingButton";
            this.panel_BookingButton.Size = new System.Drawing.Size(289, 57);
            this.panel_BookingButton.TabIndex = 16;
            // 
            // button_Booking
            // 
            this.button_Booking.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button_Booking.FlatAppearance.BorderSize = 0;
            this.button_Booking.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_Booking.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_Booking.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(95)))), ((int)(((byte)(105)))));
            this.button_Booking.Image = ((System.Drawing.Image)(resources.GetObject("button_Booking.Image")));
            this.button_Booking.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button_Booking.Location = new System.Drawing.Point(31, 2);
            this.button_Booking.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.button_Booking.Name = "button_Booking";
            this.button_Booking.Size = new System.Drawing.Size(221, 48);
            this.button_Booking.TabIndex = 14;
            this.button_Booking.Text = "         Booking";
            this.button_Booking.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button_Booking.UseVisualStyleBackColor = true;
            this.button_Booking.Click += new System.EventHandler(this.button_Booking_Click);
            // 
            // panel_SearchingButton
            // 
            this.panel_SearchingButton.Controls.Add(this.button_Searching);
            this.panel_SearchingButton.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel_SearchingButton.Location = new System.Drawing.Point(0, 224);
            this.panel_SearchingButton.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panel_SearchingButton.Name = "panel_SearchingButton";
            this.panel_SearchingButton.Size = new System.Drawing.Size(289, 57);
            this.panel_SearchingButton.TabIndex = 16;
            // 
            // button_Searching
            // 
            this.button_Searching.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button_Searching.FlatAppearance.BorderSize = 0;
            this.button_Searching.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_Searching.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_Searching.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(95)))), ((int)(((byte)(105)))));
            this.button_Searching.Image = ((System.Drawing.Image)(resources.GetObject("button_Searching.Image")));
            this.button_Searching.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button_Searching.Location = new System.Drawing.Point(31, 2);
            this.button_Searching.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.button_Searching.Name = "button_Searching";
            this.button_Searching.Size = new System.Drawing.Size(221, 48);
            this.button_Searching.TabIndex = 14;
            this.button_Searching.Text = "         Searching";
            this.button_Searching.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button_Searching.UseVisualStyleBackColor = true;
            this.button_Searching.Click += new System.EventHandler(this.button_Searching_Click);
            // 
            // panel_ProfileButton
            // 
            this.panel_ProfileButton.Controls.Add(this.button_Profile);
            this.panel_ProfileButton.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel_ProfileButton.Location = new System.Drawing.Point(0, 167);
            this.panel_ProfileButton.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panel_ProfileButton.Name = "panel_ProfileButton";
            this.panel_ProfileButton.Size = new System.Drawing.Size(289, 57);
            this.panel_ProfileButton.TabIndex = 16;
            // 
            // button_Profile
            // 
            this.button_Profile.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button_Profile.FlatAppearance.BorderSize = 0;
            this.button_Profile.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_Profile.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_Profile.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(95)))), ((int)(((byte)(105)))));
            this.button_Profile.Image = ((System.Drawing.Image)(resources.GetObject("button_Profile.Image")));
            this.button_Profile.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button_Profile.Location = new System.Drawing.Point(32, 2);
            this.button_Profile.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.button_Profile.Name = "button_Profile";
            this.button_Profile.Size = new System.Drawing.Size(221, 48);
            this.button_Profile.TabIndex = 14;
            this.button_Profile.Text = "         Profile";
            this.button_Profile.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button_Profile.UseVisualStyleBackColor = true;
            this.button_Profile.Click += new System.EventHandler(this.button_Profile_Click);
            // 
            // panel_HomeButton
            // 
            this.panel_HomeButton.Controls.Add(this.button_Home);
            this.panel_HomeButton.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel_HomeButton.Location = new System.Drawing.Point(0, 110);
            this.panel_HomeButton.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panel_HomeButton.Name = "panel_HomeButton";
            this.panel_HomeButton.Size = new System.Drawing.Size(289, 57);
            this.panel_HomeButton.TabIndex = 15;
            // 
            // button_Home
            // 
            this.button_Home.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button_Home.FlatAppearance.BorderSize = 0;
            this.button_Home.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_Home.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_Home.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(95)))), ((int)(((byte)(105)))));
            this.button_Home.Image = ((System.Drawing.Image)(resources.GetObject("button_Home.Image")));
            this.button_Home.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button_Home.Location = new System.Drawing.Point(31, 2);
            this.button_Home.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.button_Home.Name = "button_Home";
            this.button_Home.Size = new System.Drawing.Size(221, 48);
            this.button_Home.TabIndex = 14;
            this.button_Home.Text = "         Home";
            this.button_Home.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button_Home.UseVisualStyleBackColor = true;
            this.button_Home.Click += new System.EventHandler(this.button_Home_Click);
            // 
            // panel_LogoUeh
            // 
            this.panel_LogoUeh.Controls.Add(this.pictureBox_LogoUeh);
            this.panel_LogoUeh.Controls.Add(this.pictureBox_MenuIcon);
            this.panel_LogoUeh.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel_LogoUeh.Location = new System.Drawing.Point(0, 0);
            this.panel_LogoUeh.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panel_LogoUeh.Name = "panel_LogoUeh";
            this.panel_LogoUeh.Size = new System.Drawing.Size(289, 110);
            this.panel_LogoUeh.TabIndex = 14;
            // 
            // pictureBox_LogoUeh
            // 
            this.pictureBox_LogoUeh.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox_LogoUeh.Image")));
            this.pictureBox_LogoUeh.Location = new System.Drawing.Point(52, 5);
            this.pictureBox_LogoUeh.Margin = new System.Windows.Forms.Padding(5);
            this.pictureBox_LogoUeh.Name = "pictureBox_LogoUeh";
            this.pictureBox_LogoUeh.Size = new System.Drawing.Size(132, 91);
            this.pictureBox_LogoUeh.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox_LogoUeh.TabIndex = 3;
            this.pictureBox_LogoUeh.TabStop = false;
            // 
            // pictureBox_MenuIcon
            // 
            this.pictureBox_MenuIcon.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.pictureBox_MenuIcon.BackColor = System.Drawing.Color.White;
            this.pictureBox_MenuIcon.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBox_MenuIcon.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox_MenuIcon.Image")));
            this.pictureBox_MenuIcon.Location = new System.Drawing.Point(212, 37);
            this.pictureBox_MenuIcon.Margin = new System.Windows.Forms.Padding(4, 2, 4, 2);
            this.pictureBox_MenuIcon.Name = "pictureBox_MenuIcon";
            this.pictureBox_MenuIcon.Size = new System.Drawing.Size(40, 37);
            this.pictureBox_MenuIcon.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox_MenuIcon.TabIndex = 12;
            this.pictureBox_MenuIcon.TabStop = false;
            // 
            // panel_SearchContainer
            // 
            this.panel_SearchContainer.Controls.Add(this.panel_SearchFunction);
            this.panel_SearchContainer.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel_SearchContainer.Location = new System.Drawing.Point(289, 0);
            this.panel_SearchContainer.Margin = new System.Windows.Forms.Padding(4);
            this.panel_SearchContainer.Name = "panel_SearchContainer";
            this.panel_SearchContainer.Size = new System.Drawing.Size(1635, 134);
            this.panel_SearchContainer.TabIndex = 14;
            // 
            // panel_SearchFunction
            // 
            this.panel_SearchFunction.BackColor = System.Drawing.Color.Gainsboro;
            this.panel_SearchFunction.Controls.Add(this.label_SearchFunction);
            this.panel_SearchFunction.Controls.Add(this.pictureBox_SearchIcon);
            this.panel_SearchFunction.Controls.Add(this.textBox_SearchFunction);
            this.panel_SearchFunction.Location = new System.Drawing.Point(83, 23);
            this.panel_SearchFunction.Margin = new System.Windows.Forms.Padding(4);
            this.panel_SearchFunction.Name = "panel_SearchFunction";
            this.panel_SearchFunction.Size = new System.Drawing.Size(396, 50);
            this.panel_SearchFunction.TabIndex = 15;
            // 
            // label_SearchFunction
            // 
            this.label_SearchFunction.AutoSize = true;
            this.label_SearchFunction.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.label_SearchFunction.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_SearchFunction.ForeColor = System.Drawing.Color.DimGray;
            this.label_SearchFunction.Location = new System.Drawing.Point(64, 11);
            this.label_SearchFunction.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_SearchFunction.Name = "label_SearchFunction";
            this.label_SearchFunction.Size = new System.Drawing.Size(138, 28);
            this.label_SearchFunction.TabIndex = 15;
            this.label_SearchFunction.Text = "Search or type";
            this.label_SearchFunction.Click += new System.EventHandler(this.label_SearchFunction_Click);
            // 
            // pictureBox_SearchIcon
            // 
            this.pictureBox_SearchIcon.BackColor = System.Drawing.Color.Gainsboro;
            this.pictureBox_SearchIcon.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox_SearchIcon.Image")));
            this.pictureBox_SearchIcon.Location = new System.Drawing.Point(16, 10);
            this.pictureBox_SearchIcon.Margin = new System.Windows.Forms.Padding(4);
            this.pictureBox_SearchIcon.Name = "pictureBox_SearchIcon";
            this.pictureBox_SearchIcon.Size = new System.Drawing.Size(33, 31);
            this.pictureBox_SearchIcon.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox_SearchIcon.TabIndex = 15;
            this.pictureBox_SearchIcon.TabStop = false;
            // 
            // textBox_SearchFunction
            // 
            this.textBox_SearchFunction.BackColor = System.Drawing.Color.Gainsboro;
            this.textBox_SearchFunction.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox_SearchFunction.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox_SearchFunction.Location = new System.Drawing.Point(59, 12);
            this.textBox_SearchFunction.Margin = new System.Windows.Forms.Padding(4);
            this.textBox_SearchFunction.Name = "textBox_SearchFunction";
            this.textBox_SearchFunction.Size = new System.Drawing.Size(320, 27);
            this.textBox_SearchFunction.TabIndex = 0;
            this.textBox_SearchFunction.Click += new System.EventHandler(this.textBox_SearchFunction_Click);
            this.textBox_SearchFunction.TextChanged += new System.EventHandler(this.textBox_SearchFunction_TextChanged);
            // 
            // panel_ChildForm
            // 
            this.panel_ChildForm.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel_ChildForm.Location = new System.Drawing.Point(289, 134);
            this.panel_ChildForm.Margin = new System.Windows.Forms.Padding(4);
            this.panel_ChildForm.Name = "panel_ChildForm";
            this.panel_ChildForm.Size = new System.Drawing.Size(1635, 880);
            this.panel_ChildForm.TabIndex = 15;
            // 
            // Form_NguoiDung
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1924, 1014);
            this.Controls.Add(this.panel_ChildForm);
            this.Controls.Add(this.panel_SearchContainer);
            this.Controls.Add(this.panel_Sidebar);
            this.Margin = new System.Windows.Forms.Padding(4);
            this.MinimumSize = new System.Drawing.Size(1194, 726);
            this.Name = "Form_NguoiDung";
            this.ShowIcon = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form_NguoiDung";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.panel_Sidebar.ResumeLayout(false);
            this.panel_LogoutButton.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.panel_Null4.ResumeLayout(false);
            this.panel_Null3.ResumeLayout(false);
            this.panel_HistoryButton.ResumeLayout(false);
            this.panel_BookingButton.ResumeLayout(false);
            this.panel_SearchingButton.ResumeLayout(false);
            this.panel_ProfileButton.ResumeLayout(false);
            this.panel_HomeButton.ResumeLayout(false);
            this.panel_LogoUeh.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_LogoUeh)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_MenuIcon)).EndInit();
            this.panel_SearchContainer.ResumeLayout(false);
            this.panel_SearchFunction.ResumeLayout(false);
            this.panel_SearchFunction.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_SearchIcon)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.PictureBox pictureBox_MenuIcon;
        private System.Windows.Forms.PictureBox pictureBox_LogoUeh;
        private System.Windows.Forms.Panel panel_Sidebar;
        private System.Windows.Forms.Panel panel_LogoUeh;
        private System.Windows.Forms.Panel panel_ProfileButton;
        private System.Windows.Forms.Button button_Profile;
        private System.Windows.Forms.Panel panel_HomeButton;
        private System.Windows.Forms.Button button_Home;
        private System.Windows.Forms.Panel panel_HistoryButton;
        private System.Windows.Forms.Button button_History;
        private System.Windows.Forms.Panel panel_BookingButton;
        private System.Windows.Forms.Button button_Booking;
        private System.Windows.Forms.Panel panel_SearchingButton;
        private System.Windows.Forms.Button button_Searching;
        private System.Windows.Forms.Panel panel_Null1;
        private System.Windows.Forms.Panel panel_RatingButton;
        private System.Windows.Forms.Panel panel_Null4;
        private System.Windows.Forms.Button button_Null2;
        private System.Windows.Forms.Panel panel_Null3;
        private System.Windows.Forms.Button button_Null1;
        private System.Windows.Forms.Panel panel_Null2;
        private System.Windows.Forms.Panel panel_SearchContainer;
        private System.Windows.Forms.Panel panel_SearchFunction;
        private System.Windows.Forms.PictureBox pictureBox_SearchIcon;
        private System.Windows.Forms.TextBox textBox_SearchFunction;
        private System.Windows.Forms.Label label_SearchFunction;
        private System.Windows.Forms.Panel panel_SettingButton;
        private System.Windows.Forms.Panel panel_LogoutButton;
        private System.Windows.Forms.Button button_Logout;
        private System.Windows.Forms.Panel panel_ChildForm;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button button_ChangePassword;
    }
}