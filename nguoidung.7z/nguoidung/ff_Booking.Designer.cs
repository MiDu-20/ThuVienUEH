﻿namespace QuanLiThuVienUeh.nguoidung
{
    partial class ff_Booking
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ff_Booking));
            this.panel_Pms1 = new System.Windows.Forms.Panel();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label_CouponInfoPms1 = new System.Windows.Forms.Label();
            this.label_CouponPms1 = new System.Windows.Forms.Label();
            this.label_IDSachInfoPms1 = new System.Windows.Forms.Label();
            this.label_IDSachPms1 = new System.Windows.Forms.Label();
            this.label_TenSachPms1 = new System.Windows.Forms.Label();
            this.pictureBox_AvatarPms1 = new System.Windows.Forms.PictureBox();
            this.panel_Pms2 = new System.Windows.Forms.Panel();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox_AvatarPms2 = new System.Windows.Forms.PictureBox();
            this.label_CouponInfoPms2 = new System.Windows.Forms.Label();
            this.label_CouponPms2 = new System.Windows.Forms.Label();
            this.label_TenSachPms2 = new System.Windows.Forms.Label();
            this.label_IDSachInfoPms2 = new System.Windows.Forms.Label();
            this.label_IDSachPms2 = new System.Windows.Forms.Label();
            this.panel_Pms3 = new System.Windows.Forms.Panel();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.pictureBox_AvatarPms3 = new System.Windows.Forms.PictureBox();
            this.label_CouponInfoPms3 = new System.Windows.Forms.Label();
            this.label_CouponPms3 = new System.Windows.Forms.Label();
            this.label_IDSachInfoPms3 = new System.Windows.Forms.Label();
            this.label_IDSachPms3 = new System.Windows.Forms.Label();
            this.label_TenSachPms3 = new System.Windows.Forms.Label();
            this.panel_Null1 = new System.Windows.Forms.Panel();
            this.label_PhieuMuonSach = new System.Windows.Forms.Label();
            this.panel_Null2 = new System.Windows.Forms.Panel();
            this.button_Next = new Guna.UI2.WinForms.Guna2CircleButton();
            this.button_Previous = new Guna.UI2.WinForms.Guna2CircleButton();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.panel_Pms1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_AvatarPms1)).BeginInit();
            this.panel_Pms2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_AvatarPms2)).BeginInit();
            this.panel_Pms3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_AvatarPms3)).BeginInit();
            this.panel_Null1.SuspendLayout();
            this.panel_Null2.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel_Pms1
            // 
            this.panel_Pms1.BackColor = System.Drawing.Color.White;
            this.panel_Pms1.Controls.Add(this.pictureBox1);
            this.panel_Pms1.Controls.Add(this.label_CouponInfoPms1);
            this.panel_Pms1.Controls.Add(this.label_CouponPms1);
            this.panel_Pms1.Controls.Add(this.label_IDSachInfoPms1);
            this.panel_Pms1.Controls.Add(this.label_IDSachPms1);
            this.panel_Pms1.Controls.Add(this.label_TenSachPms1);
            this.panel_Pms1.Controls.Add(this.pictureBox_AvatarPms1);
            this.panel_Pms1.Location = new System.Drawing.Point(47, 71);
            this.panel_Pms1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.panel_Pms1.Name = "panel_Pms1";
            this.panel_Pms1.Size = new System.Drawing.Size(1643, 222);
            this.panel_Pms1.TabIndex = 0;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(1363, 26);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(235, 165);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 37;
            this.pictureBox1.TabStop = false;
            // 
            // label_CouponInfoPms1
            // 
            this.label_CouponInfoPms1.AutoSize = true;
            this.label_CouponInfoPms1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label_CouponInfoPms1.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_CouponInfoPms1.ForeColor = System.Drawing.Color.Black;
            this.label_CouponInfoPms1.Location = new System.Drawing.Point(363, 127);
            this.label_CouponInfoPms1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_CouponInfoPms1.Name = "label_CouponInfoPms1";
            this.label_CouponInfoPms1.Size = new System.Drawing.Size(29, 32);
            this.label_CouponInfoPms1.TabIndex = 36;
            this.label_CouponInfoPms1.Text = "...";
            // 
            // label_CouponPms1
            // 
            this.label_CouponPms1.AutoSize = true;
            this.label_CouponPms1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label_CouponPms1.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_CouponPms1.ForeColor = System.Drawing.Color.Black;
            this.label_CouponPms1.Location = new System.Drawing.Point(249, 127);
            this.label_CouponPms1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_CouponPms1.Name = "label_CouponPms1";
            this.label_CouponPms1.Size = new System.Drawing.Size(104, 32);
            this.label_CouponPms1.TabIndex = 35;
            this.label_CouponPms1.Text = "Coupon:";
            // 
            // label_IDSachInfoPms1
            // 
            this.label_IDSachInfoPms1.AutoSize = true;
            this.label_IDSachInfoPms1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label_IDSachInfoPms1.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_IDSachInfoPms1.ForeColor = System.Drawing.Color.Black;
            this.label_IDSachInfoPms1.Location = new System.Drawing.Point(363, 80);
            this.label_IDSachInfoPms1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_IDSachInfoPms1.Name = "label_IDSachInfoPms1";
            this.label_IDSachInfoPms1.Size = new System.Drawing.Size(29, 32);
            this.label_IDSachInfoPms1.TabIndex = 34;
            this.label_IDSachInfoPms1.Text = "...";
            // 
            // label_IDSachPms1
            // 
            this.label_IDSachPms1.AutoSize = true;
            this.label_IDSachPms1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label_IDSachPms1.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_IDSachPms1.ForeColor = System.Drawing.Color.Black;
            this.label_IDSachPms1.Location = new System.Drawing.Point(249, 80);
            this.label_IDSachPms1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_IDSachPms1.Name = "label_IDSachPms1";
            this.label_IDSachPms1.Size = new System.Drawing.Size(99, 32);
            this.label_IDSachPms1.TabIndex = 28;
            this.label_IDSachPms1.Text = "ID Sách:";
            // 
            // label_TenSachPms1
            // 
            this.label_TenSachPms1.AutoSize = true;
            this.label_TenSachPms1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label_TenSachPms1.Font = new System.Drawing.Font("Segoe UI Semibold", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_TenSachPms1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(95)))), ((int)(((byte)(105)))));
            this.label_TenSachPms1.Location = new System.Drawing.Point(248, 26);
            this.label_TenSachPms1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_TenSachPms1.Name = "label_TenSachPms1";
            this.label_TenSachPms1.Size = new System.Drawing.Size(202, 41);
            this.label_TenSachPms1.TabIndex = 27;
            this.label_TenSachPms1.Text = "Đào Gia Phúc";
            this.label_TenSachPms1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // pictureBox_AvatarPms1
            // 
            this.pictureBox_AvatarPms1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox_AvatarPms1.Image")));
            this.pictureBox_AvatarPms1.Location = new System.Drawing.Point(44, 26);
            this.pictureBox_AvatarPms1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.pictureBox_AvatarPms1.Name = "pictureBox_AvatarPms1";
            this.pictureBox_AvatarPms1.Size = new System.Drawing.Size(169, 165);
            this.pictureBox_AvatarPms1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox_AvatarPms1.TabIndex = 23;
            this.pictureBox_AvatarPms1.TabStop = false;
            // 
            // panel_Pms2
            // 
            this.panel_Pms2.BackColor = System.Drawing.Color.White;
            this.panel_Pms2.Controls.Add(this.pictureBox2);
            this.panel_Pms2.Controls.Add(this.pictureBox_AvatarPms2);
            this.panel_Pms2.Controls.Add(this.label_CouponInfoPms2);
            this.panel_Pms2.Controls.Add(this.label_CouponPms2);
            this.panel_Pms2.Controls.Add(this.label_TenSachPms2);
            this.panel_Pms2.Controls.Add(this.label_IDSachInfoPms2);
            this.panel_Pms2.Controls.Add(this.label_IDSachPms2);
            this.panel_Pms2.Location = new System.Drawing.Point(47, 314);
            this.panel_Pms2.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.panel_Pms2.Name = "panel_Pms2";
            this.panel_Pms2.Size = new System.Drawing.Size(1643, 222);
            this.panel_Pms2.TabIndex = 1;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(1363, 26);
            this.pictureBox2.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(235, 165);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox2.TabIndex = 38;
            this.pictureBox2.TabStop = false;
            // 
            // pictureBox_AvatarPms2
            // 
            this.pictureBox_AvatarPms2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox_AvatarPms2.Image")));
            this.pictureBox_AvatarPms2.Location = new System.Drawing.Point(44, 26);
            this.pictureBox_AvatarPms2.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.pictureBox_AvatarPms2.Name = "pictureBox_AvatarPms2";
            this.pictureBox_AvatarPms2.Size = new System.Drawing.Size(169, 165);
            this.pictureBox_AvatarPms2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox_AvatarPms2.TabIndex = 43;
            this.pictureBox_AvatarPms2.TabStop = false;
            // 
            // label_CouponInfoPms2
            // 
            this.label_CouponInfoPms2.AutoSize = true;
            this.label_CouponInfoPms2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label_CouponInfoPms2.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_CouponInfoPms2.ForeColor = System.Drawing.Color.Black;
            this.label_CouponInfoPms2.Location = new System.Drawing.Point(363, 127);
            this.label_CouponInfoPms2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_CouponInfoPms2.Name = "label_CouponInfoPms2";
            this.label_CouponInfoPms2.Size = new System.Drawing.Size(29, 32);
            this.label_CouponInfoPms2.TabIndex = 42;
            this.label_CouponInfoPms2.Text = "...";
            // 
            // label_CouponPms2
            // 
            this.label_CouponPms2.AutoSize = true;
            this.label_CouponPms2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label_CouponPms2.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_CouponPms2.ForeColor = System.Drawing.Color.Black;
            this.label_CouponPms2.Location = new System.Drawing.Point(249, 127);
            this.label_CouponPms2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_CouponPms2.Name = "label_CouponPms2";
            this.label_CouponPms2.Size = new System.Drawing.Size(104, 32);
            this.label_CouponPms2.TabIndex = 41;
            this.label_CouponPms2.Text = "Coupon:";
            // 
            // label_TenSachPms2
            // 
            this.label_TenSachPms2.AutoSize = true;
            this.label_TenSachPms2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label_TenSachPms2.Font = new System.Drawing.Font("Segoe UI Semibold", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_TenSachPms2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(95)))), ((int)(((byte)(105)))));
            this.label_TenSachPms2.Location = new System.Drawing.Point(248, 26);
            this.label_TenSachPms2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_TenSachPms2.Name = "label_TenSachPms2";
            this.label_TenSachPms2.Size = new System.Drawing.Size(202, 41);
            this.label_TenSachPms2.TabIndex = 38;
            this.label_TenSachPms2.Text = "Đào Gia Phúc";
            this.label_TenSachPms2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label_IDSachInfoPms2
            // 
            this.label_IDSachInfoPms2.AutoSize = true;
            this.label_IDSachInfoPms2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label_IDSachInfoPms2.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_IDSachInfoPms2.ForeColor = System.Drawing.Color.Black;
            this.label_IDSachInfoPms2.Location = new System.Drawing.Point(363, 80);
            this.label_IDSachInfoPms2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_IDSachInfoPms2.Name = "label_IDSachInfoPms2";
            this.label_IDSachInfoPms2.Size = new System.Drawing.Size(29, 32);
            this.label_IDSachInfoPms2.TabIndex = 40;
            this.label_IDSachInfoPms2.Text = "...";
            // 
            // label_IDSachPms2
            // 
            this.label_IDSachPms2.AutoSize = true;
            this.label_IDSachPms2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label_IDSachPms2.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_IDSachPms2.ForeColor = System.Drawing.Color.Black;
            this.label_IDSachPms2.Location = new System.Drawing.Point(249, 80);
            this.label_IDSachPms2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_IDSachPms2.Name = "label_IDSachPms2";
            this.label_IDSachPms2.Size = new System.Drawing.Size(99, 32);
            this.label_IDSachPms2.TabIndex = 39;
            this.label_IDSachPms2.Text = "ID Sách:";
            // 
            // panel_Pms3
            // 
            this.panel_Pms3.BackColor = System.Drawing.Color.White;
            this.panel_Pms3.Controls.Add(this.pictureBox3);
            this.panel_Pms3.Controls.Add(this.pictureBox_AvatarPms3);
            this.panel_Pms3.Controls.Add(this.label_CouponInfoPms3);
            this.panel_Pms3.Controls.Add(this.label_CouponPms3);
            this.panel_Pms3.Controls.Add(this.label_IDSachInfoPms3);
            this.panel_Pms3.Controls.Add(this.label_IDSachPms3);
            this.panel_Pms3.Controls.Add(this.label_TenSachPms3);
            this.panel_Pms3.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel_Pms3.Location = new System.Drawing.Point(47, 555);
            this.panel_Pms3.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.panel_Pms3.Name = "panel_Pms3";
            this.panel_Pms3.Size = new System.Drawing.Size(1642, 222);
            this.panel_Pms3.TabIndex = 2;
            // 
            // pictureBox3
            // 
            this.pictureBox3.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox3.Image")));
            this.pictureBox3.Location = new System.Drawing.Point(1363, 23);
            this.pictureBox3.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(235, 165);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox3.TabIndex = 44;
            this.pictureBox3.TabStop = false;
            // 
            // pictureBox_AvatarPms3
            // 
            this.pictureBox_AvatarPms3.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox_AvatarPms3.Image")));
            this.pictureBox_AvatarPms3.Location = new System.Drawing.Point(44, 23);
            this.pictureBox_AvatarPms3.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.pictureBox_AvatarPms3.Name = "pictureBox_AvatarPms3";
            this.pictureBox_AvatarPms3.Size = new System.Drawing.Size(169, 165);
            this.pictureBox_AvatarPms3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox_AvatarPms3.TabIndex = 44;
            this.pictureBox_AvatarPms3.TabStop = false;
            // 
            // label_CouponInfoPms3
            // 
            this.label_CouponInfoPms3.AutoSize = true;
            this.label_CouponInfoPms3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label_CouponInfoPms3.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_CouponInfoPms3.ForeColor = System.Drawing.Color.Black;
            this.label_CouponInfoPms3.Location = new System.Drawing.Point(363, 124);
            this.label_CouponInfoPms3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_CouponInfoPms3.Name = "label_CouponInfoPms3";
            this.label_CouponInfoPms3.Size = new System.Drawing.Size(29, 32);
            this.label_CouponInfoPms3.TabIndex = 42;
            this.label_CouponInfoPms3.Text = "...";
            // 
            // label_CouponPms3
            // 
            this.label_CouponPms3.AutoSize = true;
            this.label_CouponPms3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label_CouponPms3.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_CouponPms3.ForeColor = System.Drawing.Color.Black;
            this.label_CouponPms3.Location = new System.Drawing.Point(249, 124);
            this.label_CouponPms3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_CouponPms3.Name = "label_CouponPms3";
            this.label_CouponPms3.Size = new System.Drawing.Size(104, 32);
            this.label_CouponPms3.TabIndex = 41;
            this.label_CouponPms3.Text = "Coupon:";
            // 
            // label_IDSachInfoPms3
            // 
            this.label_IDSachInfoPms3.AutoSize = true;
            this.label_IDSachInfoPms3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label_IDSachInfoPms3.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_IDSachInfoPms3.ForeColor = System.Drawing.Color.Black;
            this.label_IDSachInfoPms3.Location = new System.Drawing.Point(363, 78);
            this.label_IDSachInfoPms3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_IDSachInfoPms3.Name = "label_IDSachInfoPms3";
            this.label_IDSachInfoPms3.Size = new System.Drawing.Size(29, 32);
            this.label_IDSachInfoPms3.TabIndex = 40;
            this.label_IDSachInfoPms3.Text = "...";
            // 
            // label_IDSachPms3
            // 
            this.label_IDSachPms3.AutoSize = true;
            this.label_IDSachPms3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label_IDSachPms3.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_IDSachPms3.ForeColor = System.Drawing.Color.Black;
            this.label_IDSachPms3.Location = new System.Drawing.Point(249, 78);
            this.label_IDSachPms3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_IDSachPms3.Name = "label_IDSachPms3";
            this.label_IDSachPms3.Size = new System.Drawing.Size(99, 32);
            this.label_IDSachPms3.TabIndex = 39;
            this.label_IDSachPms3.Text = "ID Sách:";
            // 
            // label_TenSachPms3
            // 
            this.label_TenSachPms3.AutoSize = true;
            this.label_TenSachPms3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label_TenSachPms3.Font = new System.Drawing.Font("Segoe UI Semibold", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_TenSachPms3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(95)))), ((int)(((byte)(105)))));
            this.label_TenSachPms3.Location = new System.Drawing.Point(248, 23);
            this.label_TenSachPms3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_TenSachPms3.Name = "label_TenSachPms3";
            this.label_TenSachPms3.Size = new System.Drawing.Size(202, 41);
            this.label_TenSachPms3.TabIndex = 38;
            this.label_TenSachPms3.Text = "Đào Gia Phúc";
            this.label_TenSachPms3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // panel_Null1
            // 
            this.panel_Null1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(95)))), ((int)(((byte)(105)))));
            this.panel_Null1.Controls.Add(this.label_PhieuMuonSach);
            this.panel_Null1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel_Null1.Location = new System.Drawing.Point(0, 0);
            this.panel_Null1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panel_Null1.Name = "panel_Null1";
            this.panel_Null1.Size = new System.Drawing.Size(1737, 55);
            this.panel_Null1.TabIndex = 3;
            // 
            // label_PhieuMuonSach
            // 
            this.label_PhieuMuonSach.AutoSize = true;
            this.label_PhieuMuonSach.Font = new System.Drawing.Font("Segoe UI Semibold", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_PhieuMuonSach.ForeColor = System.Drawing.Color.White;
            this.label_PhieuMuonSach.Location = new System.Drawing.Point(13, 9);
            this.label_PhieuMuonSach.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_PhieuMuonSach.Name = "label_PhieuMuonSach";
            this.label_PhieuMuonSach.Size = new System.Drawing.Size(265, 37);
            this.label_PhieuMuonSach.TabIndex = 7;
            this.label_PhieuMuonSach.Text = "PHIẾU MƯỢN SÁCH";
            this.label_PhieuMuonSach.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // panel_Null2
            // 
            this.panel_Null2.BackColor = System.Drawing.Color.Gainsboro;
            this.panel_Null2.Controls.Add(this.button_Next);
            this.panel_Null2.Controls.Add(this.button_Previous);
            this.panel_Null2.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel_Null2.Location = new System.Drawing.Point(47, 777);
            this.panel_Null2.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.panel_Null2.Name = "panel_Null2";
            this.panel_Null2.Size = new System.Drawing.Size(1642, 55);
            this.panel_Null2.TabIndex = 4;
            // 
            // button_Next
            // 
            this.button_Next.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.button_Next.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.button_Next.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.button_Next.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.button_Next.FillColor = System.Drawing.Color.Cyan;
            this.button_Next.Font = new System.Drawing.Font("Segoe UI", 26.25F);
            this.button_Next.ForeColor = System.Drawing.Color.Black;
            this.button_Next.Image = global::QuanLiThuVienUeh.Properties.Resources.Right;
            this.button_Next.ImageSize = new System.Drawing.Size(40, 40);
            this.button_Next.Location = new System.Drawing.Point(1551, 4);
            this.button_Next.Margin = new System.Windows.Forms.Padding(4, 4, 45, 4);
            this.button_Next.Name = "button_Next";
            this.button_Next.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle;
            this.button_Next.Size = new System.Drawing.Size(47, 43);
            this.button_Next.TabIndex = 4;
            this.button_Next.Click += new System.EventHandler(this.button_Next_Click);
            // 
            // button_Previous
            // 
            this.button_Previous.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.button_Previous.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.button_Previous.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.button_Previous.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.button_Previous.FillColor = System.Drawing.Color.Cyan;
            this.button_Previous.Font = new System.Drawing.Font("Segoe UI", 26.25F);
            this.button_Previous.ForeColor = System.Drawing.Color.Black;
            this.button_Previous.Image = global::QuanLiThuVienUeh.Properties.Resources.Left;
            this.button_Previous.ImageSize = new System.Drawing.Size(40, 40);
            this.button_Previous.Location = new System.Drawing.Point(44, 4);
            this.button_Previous.Margin = new System.Windows.Forms.Padding(45, 4, 4, 4);
            this.button_Previous.Name = "button_Previous";
            this.button_Previous.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle;
            this.button_Previous.Size = new System.Drawing.Size(47, 43);
            this.button_Previous.TabIndex = 3;
            this.button_Previous.Click += new System.EventHandler(this.button_Previous_Click);
            // 
            // panel1
            // 
            this.panel1.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel1.Location = new System.Drawing.Point(0, 55);
            this.panel1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(47, 777);
            this.panel1.TabIndex = 5;
            // 
            // panel2
            // 
            this.panel2.Dock = System.Windows.Forms.DockStyle.Right;
            this.panel2.Location = new System.Drawing.Point(1689, 55);
            this.panel2.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(48, 777);
            this.panel2.TabIndex = 6;
            // 
            // ff_Booking
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Gainsboro;
            this.ClientSize = new System.Drawing.Size(1737, 832);
            this.Controls.Add(this.panel_Pms2);
            this.Controls.Add(this.panel_Pms1);
            this.Controls.Add(this.panel_Pms3);
            this.Controls.Add(this.panel_Null2);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.panel_Null1);
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Name = "ff_Booking";
            this.ShowIcon = false;
            this.Text = "FormBooking";
            this.panel_Pms1.ResumeLayout(false);
            this.panel_Pms1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_AvatarPms1)).EndInit();
            this.panel_Pms2.ResumeLayout(false);
            this.panel_Pms2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_AvatarPms2)).EndInit();
            this.panel_Pms3.ResumeLayout(false);
            this.panel_Pms3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_AvatarPms3)).EndInit();
            this.panel_Null1.ResumeLayout(false);
            this.panel_Null1.PerformLayout();
            this.panel_Null2.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel_Pms1;
        private System.Windows.Forms.Panel panel_Pms2;
        private System.Windows.Forms.Panel panel_Pms3;
        private System.Windows.Forms.PictureBox pictureBox_AvatarPms1;
        private System.Windows.Forms.Panel panel_Null1;
        private System.Windows.Forms.Label label_PhieuMuonSach;
        private System.Windows.Forms.Label label_TenSachPms1;
        private System.Windows.Forms.Label label_IDSachPms1;
        private System.Windows.Forms.Label label_IDSachInfoPms1;
        private System.Windows.Forms.Label label_CouponPms1;
        private System.Windows.Forms.Label label_CouponInfoPms1;
        private System.Windows.Forms.Label label_CouponInfoPms2;
        private System.Windows.Forms.Label label_CouponPms2;
        private System.Windows.Forms.Label label_TenSachPms2;
        private System.Windows.Forms.Label label_IDSachInfoPms2;
        private System.Windows.Forms.Label label_IDSachPms2;
        private System.Windows.Forms.Label label_CouponInfoPms3;
        private System.Windows.Forms.Label label_CouponPms3;
        private System.Windows.Forms.Label label_IDSachInfoPms3;
        private System.Windows.Forms.Label label_IDSachPms3;
        private System.Windows.Forms.Label label_TenSachPms3;
        private System.Windows.Forms.Panel panel_Null2;
        private Guna.UI2.WinForms.Guna2CircleButton button_Previous;
        private Guna.UI2.WinForms.Guna2CircleButton button_Next;
        private System.Windows.Forms.PictureBox pictureBox_AvatarPms2;
        private System.Windows.Forms.PictureBox pictureBox_AvatarPms3;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.PictureBox pictureBox3;
    }
}