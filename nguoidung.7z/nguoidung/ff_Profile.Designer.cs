﻿namespace QuanLiThuVienUeh.nguoidung
{
    partial class ff_Profile
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ff_Profile));
            this.label_NgaySinhInfo = new System.Windows.Forms.Label();
            this.label_NgaySinh = new System.Windows.Forms.Label();
            this.label_ChuyenNganhInfo = new System.Windows.Forms.Label();
            this.label_SoDienThoaiInfo = new System.Windows.Forms.Label();
            this.label_EmailInfo = new System.Windows.Forms.Label();
            this.label_LopInfo = new System.Windows.Forms.Label();
            this.label_GioiTinhInfo = new System.Windows.Forms.Label();
            this.label_HoVaTenInfo = new System.Windows.Forms.Label();
            this.label_IDInfo = new System.Windows.Forms.Label();
            this.label_ChuyenNganh = new System.Windows.Forms.Label();
            this.label_SoDienThoai = new System.Windows.Forms.Label();
            this.label_Email = new System.Windows.Forms.Label();
            this.label_Lop = new System.Windows.Forms.Label();
            this.label_GioiTinh = new System.Windows.Forms.Label();
            this.label_HoVaTen = new System.Windows.Forms.Label();
            this.label_ID = new System.Windows.Forms.Label();
            this.label_NhanVienName = new System.Windows.Forms.Label();
            this.textBox_GioiThieu = new System.Windows.Forms.TextBox();
            this.pictureBox_UehLogoIcon = new System.Windows.Forms.PictureBox();
            this.pictureBox_Avatar = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_UehLogoIcon)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_Avatar)).BeginInit();
            this.SuspendLayout();
            // 
            // label_NgaySinhInfo
            // 
            this.label_NgaySinhInfo.AutoSize = true;
            this.label_NgaySinhInfo.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label_NgaySinhInfo.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_NgaySinhInfo.ForeColor = System.Drawing.Color.Black;
            this.label_NgaySinhInfo.Location = new System.Drawing.Point(471, 350);
            this.label_NgaySinhInfo.Name = "label_NgaySinhInfo";
            this.label_NgaySinhInfo.Size = new System.Drawing.Size(24, 25);
            this.label_NgaySinhInfo.TabIndex = 61;
            this.label_NgaySinhInfo.Text = "...";
            // 
            // label_NgaySinh
            // 
            this.label_NgaySinh.AutoSize = true;
            this.label_NgaySinh.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label_NgaySinh.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_NgaySinh.ForeColor = System.Drawing.Color.Black;
            this.label_NgaySinh.Location = new System.Drawing.Point(282, 350);
            this.label_NgaySinh.Name = "label_NgaySinh";
            this.label_NgaySinh.Size = new System.Drawing.Size(100, 25);
            this.label_NgaySinh.TabIndex = 60;
            this.label_NgaySinh.Text = "Ngày sinh:";
            // 
            // label_ChuyenNganhInfo
            // 
            this.label_ChuyenNganhInfo.AutoSize = true;
            this.label_ChuyenNganhInfo.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label_ChuyenNganhInfo.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_ChuyenNganhInfo.ForeColor = System.Drawing.Color.Black;
            this.label_ChuyenNganhInfo.Location = new System.Drawing.Point(471, 435);
            this.label_ChuyenNganhInfo.Name = "label_ChuyenNganhInfo";
            this.label_ChuyenNganhInfo.Size = new System.Drawing.Size(24, 25);
            this.label_ChuyenNganhInfo.TabIndex = 59;
            this.label_ChuyenNganhInfo.Text = "...";
            // 
            // label_SoDienThoaiInfo
            // 
            this.label_SoDienThoaiInfo.AutoSize = true;
            this.label_SoDienThoaiInfo.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label_SoDienThoaiInfo.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_SoDienThoaiInfo.ForeColor = System.Drawing.Color.Black;
            this.label_SoDienThoaiInfo.Location = new System.Drawing.Point(471, 519);
            this.label_SoDienThoaiInfo.Name = "label_SoDienThoaiInfo";
            this.label_SoDienThoaiInfo.Size = new System.Drawing.Size(24, 25);
            this.label_SoDienThoaiInfo.TabIndex = 58;
            this.label_SoDienThoaiInfo.Text = "...";
            // 
            // label_EmailInfo
            // 
            this.label_EmailInfo.AutoSize = true;
            this.label_EmailInfo.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label_EmailInfo.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_EmailInfo.ForeColor = System.Drawing.Color.Black;
            this.label_EmailInfo.Location = new System.Drawing.Point(471, 478);
            this.label_EmailInfo.Name = "label_EmailInfo";
            this.label_EmailInfo.Size = new System.Drawing.Size(24, 25);
            this.label_EmailInfo.TabIndex = 57;
            this.label_EmailInfo.Text = "...";
            // 
            // label_LopInfo
            // 
            this.label_LopInfo.AutoSize = true;
            this.label_LopInfo.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label_LopInfo.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_LopInfo.ForeColor = System.Drawing.Color.Black;
            this.label_LopInfo.Location = new System.Drawing.Point(471, 394);
            this.label_LopInfo.Name = "label_LopInfo";
            this.label_LopInfo.Size = new System.Drawing.Size(24, 25);
            this.label_LopInfo.TabIndex = 56;
            this.label_LopInfo.Text = "...";
            // 
            // label_GioiTinhInfo
            // 
            this.label_GioiTinhInfo.AutoSize = true;
            this.label_GioiTinhInfo.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label_GioiTinhInfo.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_GioiTinhInfo.ForeColor = System.Drawing.Color.Black;
            this.label_GioiTinhInfo.Location = new System.Drawing.Point(471, 308);
            this.label_GioiTinhInfo.Name = "label_GioiTinhInfo";
            this.label_GioiTinhInfo.Size = new System.Drawing.Size(24, 25);
            this.label_GioiTinhInfo.TabIndex = 55;
            this.label_GioiTinhInfo.Text = "...";
            // 
            // label_HoVaTenInfo
            // 
            this.label_HoVaTenInfo.AutoSize = true;
            this.label_HoVaTenInfo.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label_HoVaTenInfo.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_HoVaTenInfo.ForeColor = System.Drawing.Color.Black;
            this.label_HoVaTenInfo.Location = new System.Drawing.Point(471, 266);
            this.label_HoVaTenInfo.Name = "label_HoVaTenInfo";
            this.label_HoVaTenInfo.Size = new System.Drawing.Size(24, 25);
            this.label_HoVaTenInfo.TabIndex = 54;
            this.label_HoVaTenInfo.Text = "...";
            // 
            // label_IDInfo
            // 
            this.label_IDInfo.AutoSize = true;
            this.label_IDInfo.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label_IDInfo.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_IDInfo.ForeColor = System.Drawing.Color.Black;
            this.label_IDInfo.Location = new System.Drawing.Point(471, 227);
            this.label_IDInfo.Name = "label_IDInfo";
            this.label_IDInfo.Size = new System.Drawing.Size(24, 25);
            this.label_IDInfo.TabIndex = 53;
            this.label_IDInfo.Text = "...";
            // 
            // label_ChuyenNganh
            // 
            this.label_ChuyenNganh.AutoSize = true;
            this.label_ChuyenNganh.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label_ChuyenNganh.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_ChuyenNganh.ForeColor = System.Drawing.Color.Black;
            this.label_ChuyenNganh.Location = new System.Drawing.Point(282, 435);
            this.label_ChuyenNganh.Name = "label_ChuyenNganh";
            this.label_ChuyenNganh.Size = new System.Drawing.Size(139, 25);
            this.label_ChuyenNganh.TabIndex = 52;
            this.label_ChuyenNganh.Text = "Chuyên ngành:";
            // 
            // label_SoDienThoai
            // 
            this.label_SoDienThoai.AutoSize = true;
            this.label_SoDienThoai.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label_SoDienThoai.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_SoDienThoai.ForeColor = System.Drawing.Color.Black;
            this.label_SoDienThoai.Location = new System.Drawing.Point(282, 519);
            this.label_SoDienThoai.Name = "label_SoDienThoai";
            this.label_SoDienThoai.Size = new System.Drawing.Size(127, 25);
            this.label_SoDienThoai.TabIndex = 51;
            this.label_SoDienThoai.Text = "Số điện thoại:";
            // 
            // label_Email
            // 
            this.label_Email.AutoSize = true;
            this.label_Email.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label_Email.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_Email.ForeColor = System.Drawing.Color.Black;
            this.label_Email.Location = new System.Drawing.Point(282, 478);
            this.label_Email.Name = "label_Email";
            this.label_Email.Size = new System.Drawing.Size(62, 25);
            this.label_Email.TabIndex = 50;
            this.label_Email.Text = "Email:";
            // 
            // label_Lop
            // 
            this.label_Lop.AutoSize = true;
            this.label_Lop.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label_Lop.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_Lop.ForeColor = System.Drawing.Color.Black;
            this.label_Lop.Location = new System.Drawing.Point(282, 394);
            this.label_Lop.Name = "label_Lop";
            this.label_Lop.Size = new System.Drawing.Size(47, 25);
            this.label_Lop.TabIndex = 49;
            this.label_Lop.Text = "Lớp:";
            // 
            // label_GioiTinh
            // 
            this.label_GioiTinh.AutoSize = true;
            this.label_GioiTinh.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label_GioiTinh.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_GioiTinh.ForeColor = System.Drawing.Color.Black;
            this.label_GioiTinh.Location = new System.Drawing.Point(282, 308);
            this.label_GioiTinh.Name = "label_GioiTinh";
            this.label_GioiTinh.Size = new System.Drawing.Size(88, 25);
            this.label_GioiTinh.TabIndex = 48;
            this.label_GioiTinh.Text = "Giới tính:";
            // 
            // label_HoVaTen
            // 
            this.label_HoVaTen.AutoSize = true;
            this.label_HoVaTen.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label_HoVaTen.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_HoVaTen.ForeColor = System.Drawing.Color.Black;
            this.label_HoVaTen.Location = new System.Drawing.Point(282, 266);
            this.label_HoVaTen.Name = "label_HoVaTen";
            this.label_HoVaTen.Size = new System.Drawing.Size(96, 25);
            this.label_HoVaTen.TabIndex = 47;
            this.label_HoVaTen.Text = "Họ và tên:";
            // 
            // label_ID
            // 
            this.label_ID.AutoSize = true;
            this.label_ID.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label_ID.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_ID.ForeColor = System.Drawing.Color.Black;
            this.label_ID.Location = new System.Drawing.Point(282, 227);
            this.label_ID.Name = "label_ID";
            this.label_ID.Size = new System.Drawing.Size(34, 25);
            this.label_ID.TabIndex = 46;
            this.label_ID.Text = "ID:";
            // 
            // label_NhanVienName
            // 
            this.label_NhanVienName.AutoSize = true;
            this.label_NhanVienName.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label_NhanVienName.Font = new System.Drawing.Font("Segoe UI Semibold", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_NhanVienName.ForeColor = System.Drawing.Color.MediumBlue;
            this.label_NhanVienName.Location = new System.Drawing.Point(282, 88);
            this.label_NhanVienName.Name = "label_NhanVienName";
            this.label_NhanVienName.Size = new System.Drawing.Size(48, 25);
            this.label_NhanVienName.TabIndex = 45;
            this.label_NhanVienName.Text = "ABC";
            this.label_NhanVienName.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // textBox_GioiThieu
            // 
            this.textBox_GioiThieu.BackColor = System.Drawing.Color.White;
            this.textBox_GioiThieu.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox_GioiThieu.Enabled = false;
            this.textBox_GioiThieu.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox_GioiThieu.ForeColor = System.Drawing.Color.Black;
            this.textBox_GioiThieu.Location = new System.Drawing.Point(284, 126);
            this.textBox_GioiThieu.Multiline = true;
            this.textBox_GioiThieu.Name = "textBox_GioiThieu";
            this.textBox_GioiThieu.Size = new System.Drawing.Size(374, 98);
            this.textBox_GioiThieu.TabIndex = 44;
            this.textBox_GioiThieu.Text = "...";
            // 
            // pictureBox_UehLogoIcon
            // 
            this.pictureBox_UehLogoIcon.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox_UehLogoIcon.Image")));
            this.pictureBox_UehLogoIcon.Location = new System.Drawing.Point(53, 22);
            this.pictureBox_UehLogoIcon.Name = "pictureBox_UehLogoIcon";
            this.pictureBox_UehLogoIcon.Size = new System.Drawing.Size(66, 47);
            this.pictureBox_UehLogoIcon.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox_UehLogoIcon.TabIndex = 43;
            this.pictureBox_UehLogoIcon.TabStop = false;
            // 
            // pictureBox_Avatar
            // 
            this.pictureBox_Avatar.Location = new System.Drawing.Point(53, 88);
            this.pictureBox_Avatar.Name = "pictureBox_Avatar";
            this.pictureBox_Avatar.Size = new System.Drawing.Size(163, 167);
            this.pictureBox_Avatar.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox_Avatar.TabIndex = 42;
            this.pictureBox_Avatar.TabStop = false;
            // 
            // ff_Profile
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(710, 567);
            this.Controls.Add(this.label_NgaySinhInfo);
            this.Controls.Add(this.label_NgaySinh);
            this.Controls.Add(this.label_ChuyenNganhInfo);
            this.Controls.Add(this.label_SoDienThoaiInfo);
            this.Controls.Add(this.label_EmailInfo);
            this.Controls.Add(this.label_LopInfo);
            this.Controls.Add(this.label_GioiTinhInfo);
            this.Controls.Add(this.label_HoVaTenInfo);
            this.Controls.Add(this.label_IDInfo);
            this.Controls.Add(this.label_ChuyenNganh);
            this.Controls.Add(this.label_SoDienThoai);
            this.Controls.Add(this.label_Email);
            this.Controls.Add(this.label_Lop);
            this.Controls.Add(this.label_GioiTinh);
            this.Controls.Add(this.label_HoVaTen);
            this.Controls.Add(this.label_ID);
            this.Controls.Add(this.label_NhanVienName);
            this.Controls.Add(this.textBox_GioiThieu);
            this.Controls.Add(this.pictureBox_UehLogoIcon);
            this.Controls.Add(this.pictureBox_Avatar);
            this.Name = "ff_Profile";
            this.Text = "Form_Profile";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_UehLogoIcon)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_Avatar)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label_NgaySinhInfo;
        private System.Windows.Forms.Label label_NgaySinh;
        private System.Windows.Forms.Label label_ChuyenNganhInfo;
        private System.Windows.Forms.Label label_SoDienThoaiInfo;
        private System.Windows.Forms.Label label_EmailInfo;
        private System.Windows.Forms.Label label_LopInfo;
        private System.Windows.Forms.Label label_GioiTinhInfo;
        private System.Windows.Forms.Label label_HoVaTenInfo;
        private System.Windows.Forms.Label label_IDInfo;
        private System.Windows.Forms.Label label_ChuyenNganh;
        private System.Windows.Forms.Label label_SoDienThoai;
        private System.Windows.Forms.Label label_Email;
        private System.Windows.Forms.Label label_Lop;
        private System.Windows.Forms.Label label_GioiTinh;
        private System.Windows.Forms.Label label_HoVaTen;
        private System.Windows.Forms.Label label_ID;
        private System.Windows.Forms.Label label_NhanVienName;
        private System.Windows.Forms.TextBox textBox_GioiThieu;
        private System.Windows.Forms.PictureBox pictureBox_UehLogoIcon;
        private System.Windows.Forms.PictureBox pictureBox_Avatar;
    }
}