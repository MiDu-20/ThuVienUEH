﻿namespace QuanLiThuVienUeh.nguoidung
{
    partial class ff_Home
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.panelThongTin = new System.Windows.Forms.Panel();
            this.flowLayoutPanel1 = new System.Windows.Forms.FlowLayoutPanel();
            this.panelSachMoi = new Guna.UI2.WinForms.Guna2Panel();
            this.panel11 = new System.Windows.Forms.Panel();
            this.panel18 = new System.Windows.Forms.Panel();
            this.lblNoiDung = new System.Windows.Forms.Label();
            this.panel17 = new System.Windows.Forms.Panel();
            this.panel16 = new System.Windows.Forms.Panel();
            this.lblTacGia = new System.Windows.Forms.Label();
            this.panel15 = new System.Windows.Forms.Panel();
            this.lblTuaDe = new System.Windows.Forms.Label();
            this.pictureBook = new System.Windows.Forms.PictureBox();
            this.panel13 = new System.Windows.Forms.Panel();
            this.panel12 = new System.Windows.Forms.Panel();
            this.panel7 = new System.Windows.Forms.Panel();
            this.panel8 = new System.Windows.Forms.Panel();
            this.btnRightNewBook = new Guna.UI2.WinForms.Guna2CircleButton();
            this.panel9 = new System.Windows.Forms.Panel();
            this.panel10 = new System.Windows.Forms.Panel();
            this.panel4 = new System.Windows.Forms.Panel();
            this.panel3 = new System.Windows.Forms.Panel();
            this.btnLeftNewBook = new Guna.UI2.WinForms.Guna2CircleButton();
            this.panel5 = new System.Windows.Forms.Panel();
            this.panel14 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.panel6 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panelSachGoiY = new Guna.UI2.WinForms.Guna2Panel();
            this.panel19 = new System.Windows.Forms.Panel();
            this.panel20 = new System.Windows.Forms.Panel();
            this.lblNoiDungRequest = new System.Windows.Forms.Label();
            this.panel21 = new System.Windows.Forms.Panel();
            this.panel22 = new System.Windows.Forms.Panel();
            this.lblTacGiaRequest = new System.Windows.Forms.Label();
            this.panel23 = new System.Windows.Forms.Panel();
            this.lblTuaDeRequest = new System.Windows.Forms.Label();
            this.pictureRequestBook = new System.Windows.Forms.PictureBox();
            this.panel24 = new System.Windows.Forms.Panel();
            this.panel25 = new System.Windows.Forms.Panel();
            this.panel26 = new System.Windows.Forms.Panel();
            this.panel27 = new System.Windows.Forms.Panel();
            this.btnRightRequestBook = new Guna.UI2.WinForms.Guna2CircleButton();
            this.panel28 = new System.Windows.Forms.Panel();
            this.panel29 = new System.Windows.Forms.Panel();
            this.panel30 = new System.Windows.Forms.Panel();
            this.panel31 = new System.Windows.Forms.Panel();
            this.btnLeftRequestBook = new Guna.UI2.WinForms.Guna2CircleButton();
            this.panel32 = new System.Windows.Forms.Panel();
            this.panel33 = new System.Windows.Forms.Panel();
            this.label5 = new System.Windows.Forms.Label();
            this.panel34 = new System.Windows.Forms.Panel();
            this.panel35 = new System.Windows.Forms.Panel();
            this.panel36 = new System.Windows.Forms.Panel();
            this.lblTimer = new System.Windows.Forms.Timer(this.components);
            this.flowLayoutPanel1.SuspendLayout();
            this.panelSachMoi.SuspendLayout();
            this.panel11.SuspendLayout();
            this.panel18.SuspendLayout();
            this.panel16.SuspendLayout();
            this.panel15.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBook)).BeginInit();
            this.panel7.SuspendLayout();
            this.panel8.SuspendLayout();
            this.panel4.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel5.SuspendLayout();
            this.panel14.SuspendLayout();
            this.panelSachGoiY.SuspendLayout();
            this.panel19.SuspendLayout();
            this.panel20.SuspendLayout();
            this.panel22.SuspendLayout();
            this.panel23.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureRequestBook)).BeginInit();
            this.panel26.SuspendLayout();
            this.panel27.SuspendLayout();
            this.panel30.SuspendLayout();
            this.panel31.SuspendLayout();
            this.panel32.SuspendLayout();
            this.panel33.SuspendLayout();
            this.SuspendLayout();
            // 
            // panelThongTin
            // 
            this.panelThongTin.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(111)))), ((int)(((byte)(51)))));
            this.panelThongTin.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.panelThongTin.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelThongTin.Location = new System.Drawing.Point(0, 0);
            this.panelThongTin.Margin = new System.Windows.Forms.Padding(4);
            this.panelThongTin.Name = "panelThongTin";
            this.panelThongTin.Size = new System.Drawing.Size(1540, 268);
            this.panelThongTin.TabIndex = 0;
            // 
            // flowLayoutPanel1
            // 
            this.flowLayoutPanel1.Controls.Add(this.panelSachMoi);
            this.flowLayoutPanel1.Controls.Add(this.panelSachGoiY);
            this.flowLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.flowLayoutPanel1.Location = new System.Drawing.Point(0, 268);
            this.flowLayoutPanel1.Margin = new System.Windows.Forms.Padding(4);
            this.flowLayoutPanel1.Name = "flowLayoutPanel1";
            this.flowLayoutPanel1.Size = new System.Drawing.Size(1540, 564);
            this.flowLayoutPanel1.TabIndex = 1;
            // 
            // panelSachMoi
            // 
            this.panelSachMoi.BackColor = System.Drawing.Color.White;
            this.panelSachMoi.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.panelSachMoi.BorderRadius = 30;
            this.panelSachMoi.BorderStyle = System.Drawing.Drawing2D.DashStyle.Dash;
            this.panelSachMoi.BorderThickness = 10;
            this.panelSachMoi.Controls.Add(this.panel11);
            this.panelSachMoi.Controls.Add(this.panel7);
            this.panelSachMoi.Controls.Add(this.panel4);
            this.panelSachMoi.Controls.Add(this.panel2);
            this.panelSachMoi.Controls.Add(this.panel1);
            this.panelSachMoi.FillColor = System.Drawing.Color.White;
            this.panelSachMoi.Location = new System.Drawing.Point(35, 14);
            this.panelSachMoi.Margin = new System.Windows.Forms.Padding(35, 14, 20, 4);
            this.panelSachMoi.Name = "panelSachMoi";
            this.panelSachMoi.Size = new System.Drawing.Size(1687, 265);
            this.panelSachMoi.TabIndex = 2;
            // 
            // panel11
            // 
            this.panel11.Controls.Add(this.panel18);
            this.panel11.Controls.Add(this.panel17);
            this.panel11.Controls.Add(this.panel16);
            this.panel11.Controls.Add(this.panel15);
            this.panel11.Controls.Add(this.pictureBook);
            this.panel11.Controls.Add(this.panel13);
            this.panel11.Controls.Add(this.panel12);
            this.panel11.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel11.Location = new System.Drawing.Point(166, 0);
            this.panel11.Margin = new System.Windows.Forms.Padding(4);
            this.panel11.Name = "panel11";
            this.panel11.Size = new System.Drawing.Size(1355, 265);
            this.panel11.TabIndex = 9;
            // 
            // panel18
            // 
            this.panel18.Controls.Add(this.lblNoiDung);
            this.panel18.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel18.Location = new System.Drawing.Point(217, 109);
            this.panel18.Margin = new System.Windows.Forms.Padding(4);
            this.panel18.Name = "panel18";
            this.panel18.Size = new System.Drawing.Size(1138, 144);
            this.panel18.TabIndex = 6;
            // 
            // lblNoiDung
            // 
            this.lblNoiDung.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblNoiDung.Font = new System.Drawing.Font("Segoe UI Semibold", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNoiDung.Location = new System.Drawing.Point(0, 0);
            this.lblNoiDung.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblNoiDung.Name = "lblNoiDung";
            this.lblNoiDung.Size = new System.Drawing.Size(1138, 144);
            this.lblNoiDung.TabIndex = 0;
            this.lblNoiDung.Text = "Anh vợ nay dởm ác";
            // 
            // panel17
            // 
            this.panel17.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel17.Location = new System.Drawing.Point(217, 84);
            this.panel17.Margin = new System.Windows.Forms.Padding(4);
            this.panel17.Name = "panel17";
            this.panel17.Size = new System.Drawing.Size(1138, 25);
            this.panel17.TabIndex = 5;
            // 
            // panel16
            // 
            this.panel16.Controls.Add(this.lblTacGia);
            this.panel16.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel16.Location = new System.Drawing.Point(217, 46);
            this.panel16.Margin = new System.Windows.Forms.Padding(4);
            this.panel16.Name = "panel16";
            this.panel16.Size = new System.Drawing.Size(1138, 38);
            this.panel16.TabIndex = 4;
            // 
            // lblTacGia
            // 
            this.lblTacGia.AutoSize = true;
            this.lblTacGia.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.lblTacGia.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTacGia.Location = new System.Drawing.Point(0, 10);
            this.lblTacGia.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblTacGia.Name = "lblTacGia";
            this.lblTacGia.Size = new System.Drawing.Size(222, 28);
            this.lblTacGia.TabIndex = 1;
            this.lblTacGia.Text = "Tác giả: Mạch Gia Huy";
            // 
            // panel15
            // 
            this.panel15.Controls.Add(this.lblTuaDe);
            this.panel15.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel15.Location = new System.Drawing.Point(217, 12);
            this.panel15.Margin = new System.Windows.Forms.Padding(4);
            this.panel15.Name = "panel15";
            this.panel15.Size = new System.Drawing.Size(1138, 34);
            this.panel15.TabIndex = 3;
            // 
            // lblTuaDe
            // 
            this.lblTuaDe.AutoSize = true;
            this.lblTuaDe.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.lblTuaDe.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTuaDe.Location = new System.Drawing.Point(0, 2);
            this.lblTuaDe.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblTuaDe.Name = "lblTuaDe";
            this.lblTuaDe.Size = new System.Drawing.Size(193, 32);
            this.lblTuaDe.TabIndex = 0;
            this.lblTuaDe.Text = "ĐÂY LÀ TỰA ĐỀ";
            // 
            // pictureBook
            // 
            this.pictureBook.Dock = System.Windows.Forms.DockStyle.Left;
            this.pictureBook.Location = new System.Drawing.Point(0, 12);
            this.pictureBook.Margin = new System.Windows.Forms.Padding(4);
            this.pictureBook.Name = "pictureBook";
            this.pictureBook.Size = new System.Drawing.Size(217, 241);
            this.pictureBook.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBook.TabIndex = 2;
            this.pictureBook.TabStop = false;
            // 
            // panel13
            // 
            this.panel13.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel13.Location = new System.Drawing.Point(0, 253);
            this.panel13.Margin = new System.Windows.Forms.Padding(4);
            this.panel13.Name = "panel13";
            this.panel13.Size = new System.Drawing.Size(1355, 12);
            this.panel13.TabIndex = 1;
            // 
            // panel12
            // 
            this.panel12.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel12.Location = new System.Drawing.Point(0, 0);
            this.panel12.Margin = new System.Windows.Forms.Padding(4);
            this.panel12.Name = "panel12";
            this.panel12.Size = new System.Drawing.Size(1355, 12);
            this.panel12.TabIndex = 0;
            // 
            // panel7
            // 
            this.panel7.Controls.Add(this.panel8);
            this.panel7.Controls.Add(this.panel9);
            this.panel7.Controls.Add(this.panel10);
            this.panel7.Dock = System.Windows.Forms.DockStyle.Right;
            this.panel7.Location = new System.Drawing.Point(1521, 0);
            this.panel7.Margin = new System.Windows.Forms.Padding(4);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(121, 265);
            this.panel7.TabIndex = 8;
            // 
            // panel8
            // 
            this.panel8.Controls.Add(this.btnRightNewBook);
            this.panel8.Dock = System.Windows.Forms.DockStyle.Right;
            this.panel8.Location = new System.Drawing.Point(48, 98);
            this.panel8.Margin = new System.Windows.Forms.Padding(4);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(73, 69);
            this.panel8.TabIndex = 6;
            // 
            // btnRightNewBook
            // 
            this.btnRightNewBook.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.btnRightNewBook.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.btnRightNewBook.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.btnRightNewBook.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.btnRightNewBook.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnRightNewBook.FillColor = System.Drawing.Color.PaleTurquoise;
            this.btnRightNewBook.Font = new System.Drawing.Font("Segoe UI", 26.25F);
            this.btnRightNewBook.ForeColor = System.Drawing.Color.Black;
            this.btnRightNewBook.Image = global::QuanLiThuVienUeh.Properties.Resources.Right;
            this.btnRightNewBook.ImageSize = new System.Drawing.Size(40, 40);
            this.btnRightNewBook.Location = new System.Drawing.Point(0, 0);
            this.btnRightNewBook.Margin = new System.Windows.Forms.Padding(4, 4, 45, 4);
            this.btnRightNewBook.Name = "btnRightNewBook";
            this.btnRightNewBook.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle;
            this.btnRightNewBook.Size = new System.Drawing.Size(73, 69);
            this.btnRightNewBook.TabIndex = 1;
            this.btnRightNewBook.Click += new System.EventHandler(this.btnRightNewBook_Click);
            // 
            // panel9
            // 
            this.panel9.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel9.Location = new System.Drawing.Point(0, 0);
            this.panel9.Margin = new System.Windows.Forms.Padding(4);
            this.panel9.Name = "panel9";
            this.panel9.Size = new System.Drawing.Size(121, 98);
            this.panel9.TabIndex = 0;
            // 
            // panel10
            // 
            this.panel10.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel10.Location = new System.Drawing.Point(0, 167);
            this.panel10.Margin = new System.Windows.Forms.Padding(4);
            this.panel10.Name = "panel10";
            this.panel10.Size = new System.Drawing.Size(121, 98);
            this.panel10.TabIndex = 1;
            // 
            // panel4
            // 
            this.panel4.Controls.Add(this.panel3);
            this.panel4.Controls.Add(this.panel5);
            this.panel4.Controls.Add(this.panel6);
            this.panel4.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel4.Location = new System.Drawing.Point(45, 0);
            this.panel4.Margin = new System.Windows.Forms.Padding(4);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(121, 265);
            this.panel4.TabIndex = 7;
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.btnLeftNewBook);
            this.panel3.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel3.Location = new System.Drawing.Point(0, 98);
            this.panel3.Margin = new System.Windows.Forms.Padding(4);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(73, 69);
            this.panel3.TabIndex = 6;
            // 
            // btnLeftNewBook
            // 
            this.btnLeftNewBook.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.btnLeftNewBook.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.btnLeftNewBook.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.btnLeftNewBook.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.btnLeftNewBook.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnLeftNewBook.FillColor = System.Drawing.Color.PaleTurquoise;
            this.btnLeftNewBook.Font = new System.Drawing.Font("Segoe UI", 26.25F);
            this.btnLeftNewBook.ForeColor = System.Drawing.Color.Black;
            this.btnLeftNewBook.Image = global::QuanLiThuVienUeh.Properties.Resources.Left;
            this.btnLeftNewBook.ImageSize = new System.Drawing.Size(40, 40);
            this.btnLeftNewBook.Location = new System.Drawing.Point(0, 0);
            this.btnLeftNewBook.Margin = new System.Windows.Forms.Padding(45, 4, 4, 4);
            this.btnLeftNewBook.Name = "btnLeftNewBook";
            this.btnLeftNewBook.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle;
            this.btnLeftNewBook.Size = new System.Drawing.Size(73, 69);
            this.btnLeftNewBook.TabIndex = 2;
            this.btnLeftNewBook.Click += new System.EventHandler(this.btnLeftNewBook_Click);
            // 
            // panel5
            // 
            this.panel5.Controls.Add(this.panel14);
            this.panel5.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel5.Location = new System.Drawing.Point(0, 0);
            this.panel5.Margin = new System.Windows.Forms.Padding(4);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(121, 98);
            this.panel5.TabIndex = 0;
            // 
            // panel14
            // 
            this.panel14.Controls.Add(this.label1);
            this.panel14.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel14.Location = new System.Drawing.Point(0, 0);
            this.panel14.Margin = new System.Windows.Forms.Padding(4);
            this.panel14.Name = "panel14";
            this.panel14.Size = new System.Drawing.Size(121, 46);
            this.panel14.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label1.Font = new System.Drawing.Font("Segoe UI Semibold", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(95)))), ((int)(((byte)(105)))));
            this.label1.Location = new System.Drawing.Point(0, 0);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(121, 46);
            this.label1.TabIndex = 0;
            this.label1.Text = "SÁCH MỚI";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panel6
            // 
            this.panel6.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel6.Location = new System.Drawing.Point(0, 167);
            this.panel6.Margin = new System.Windows.Forms.Padding(4);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(121, 98);
            this.panel6.TabIndex = 1;
            // 
            // panel2
            // 
            this.panel2.Dock = System.Windows.Forms.DockStyle.Right;
            this.panel2.Location = new System.Drawing.Point(1642, 0);
            this.panel2.Margin = new System.Windows.Forms.Padding(4);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(45, 265);
            this.panel2.TabIndex = 5;
            // 
            // panel1
            // 
            this.panel1.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Margin = new System.Windows.Forms.Padding(4);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(45, 265);
            this.panel1.TabIndex = 4;
            // 
            // panelSachGoiY
            // 
            this.panelSachGoiY.BackColor = System.Drawing.Color.White;
            this.panelSachGoiY.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.panelSachGoiY.BorderRadius = 30;
            this.panelSachGoiY.BorderStyle = System.Drawing.Drawing2D.DashStyle.Dash;
            this.panelSachGoiY.BorderThickness = 10;
            this.panelSachGoiY.Controls.Add(this.panel19);
            this.panelSachGoiY.Controls.Add(this.panel26);
            this.panelSachGoiY.Controls.Add(this.panel30);
            this.panelSachGoiY.Controls.Add(this.panel35);
            this.panelSachGoiY.Controls.Add(this.panel36);
            this.panelSachGoiY.FillColor = System.Drawing.Color.White;
            this.panelSachGoiY.Location = new System.Drawing.Point(35, 289);
            this.panelSachGoiY.Margin = new System.Windows.Forms.Padding(35, 6, 20, 4);
            this.panelSachGoiY.Name = "panelSachGoiY";
            this.panelSachGoiY.Size = new System.Drawing.Size(1687, 265);
            this.panelSachGoiY.TabIndex = 3;
            // 
            // panel19
            // 
            this.panel19.Controls.Add(this.panel20);
            this.panel19.Controls.Add(this.panel21);
            this.panel19.Controls.Add(this.panel22);
            this.panel19.Controls.Add(this.panel23);
            this.panel19.Controls.Add(this.pictureRequestBook);
            this.panel19.Controls.Add(this.panel24);
            this.panel19.Controls.Add(this.panel25);
            this.panel19.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel19.Location = new System.Drawing.Point(166, 0);
            this.panel19.Margin = new System.Windows.Forms.Padding(4);
            this.panel19.Name = "panel19";
            this.panel19.Size = new System.Drawing.Size(1355, 265);
            this.panel19.TabIndex = 9;
            // 
            // panel20
            // 
            this.panel20.Controls.Add(this.lblNoiDungRequest);
            this.panel20.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel20.Location = new System.Drawing.Point(217, 109);
            this.panel20.Margin = new System.Windows.Forms.Padding(4);
            this.panel20.Name = "panel20";
            this.panel20.Size = new System.Drawing.Size(1138, 144);
            this.panel20.TabIndex = 6;
            // 
            // lblNoiDungRequest
            // 
            this.lblNoiDungRequest.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblNoiDungRequest.Font = new System.Drawing.Font("Segoe UI Semibold", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNoiDungRequest.Location = new System.Drawing.Point(0, 0);
            this.lblNoiDungRequest.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblNoiDungRequest.Name = "lblNoiDungRequest";
            this.lblNoiDungRequest.Size = new System.Drawing.Size(1138, 144);
            this.lblNoiDungRequest.TabIndex = 0;
            this.lblNoiDungRequest.Text = "Anh vợ nay dởm ác";
            // 
            // panel21
            // 
            this.panel21.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel21.Location = new System.Drawing.Point(217, 84);
            this.panel21.Margin = new System.Windows.Forms.Padding(4);
            this.panel21.Name = "panel21";
            this.panel21.Size = new System.Drawing.Size(1138, 25);
            this.panel21.TabIndex = 5;
            // 
            // panel22
            // 
            this.panel22.Controls.Add(this.lblTacGiaRequest);
            this.panel22.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel22.Location = new System.Drawing.Point(217, 46);
            this.panel22.Margin = new System.Windows.Forms.Padding(4);
            this.panel22.Name = "panel22";
            this.panel22.Size = new System.Drawing.Size(1138, 38);
            this.panel22.TabIndex = 4;
            // 
            // lblTacGiaRequest
            // 
            this.lblTacGiaRequest.AutoSize = true;
            this.lblTacGiaRequest.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.lblTacGiaRequest.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTacGiaRequest.Location = new System.Drawing.Point(0, 10);
            this.lblTacGiaRequest.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblTacGiaRequest.Name = "lblTacGiaRequest";
            this.lblTacGiaRequest.Size = new System.Drawing.Size(222, 28);
            this.lblTacGiaRequest.TabIndex = 1;
            this.lblTacGiaRequest.Text = "Tác giả: Mạch Gia Huy";
            // 
            // panel23
            // 
            this.panel23.Controls.Add(this.lblTuaDeRequest);
            this.panel23.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel23.Location = new System.Drawing.Point(217, 12);
            this.panel23.Margin = new System.Windows.Forms.Padding(4);
            this.panel23.Name = "panel23";
            this.panel23.Size = new System.Drawing.Size(1138, 34);
            this.panel23.TabIndex = 3;
            // 
            // lblTuaDeRequest
            // 
            this.lblTuaDeRequest.AutoSize = true;
            this.lblTuaDeRequest.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.lblTuaDeRequest.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTuaDeRequest.Location = new System.Drawing.Point(0, 2);
            this.lblTuaDeRequest.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblTuaDeRequest.Name = "lblTuaDeRequest";
            this.lblTuaDeRequest.Size = new System.Drawing.Size(193, 32);
            this.lblTuaDeRequest.TabIndex = 0;
            this.lblTuaDeRequest.Text = "ĐÂY LÀ TỰA ĐỀ";
            // 
            // pictureRequestBook
            // 
            this.pictureRequestBook.Dock = System.Windows.Forms.DockStyle.Left;
            this.pictureRequestBook.Location = new System.Drawing.Point(0, 12);
            this.pictureRequestBook.Margin = new System.Windows.Forms.Padding(4);
            this.pictureRequestBook.Name = "pictureRequestBook";
            this.pictureRequestBook.Size = new System.Drawing.Size(217, 241);
            this.pictureRequestBook.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureRequestBook.TabIndex = 2;
            this.pictureRequestBook.TabStop = false;
            // 
            // panel24
            // 
            this.panel24.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel24.Location = new System.Drawing.Point(0, 253);
            this.panel24.Margin = new System.Windows.Forms.Padding(4);
            this.panel24.Name = "panel24";
            this.panel24.Size = new System.Drawing.Size(1355, 12);
            this.panel24.TabIndex = 1;
            // 
            // panel25
            // 
            this.panel25.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel25.Location = new System.Drawing.Point(0, 0);
            this.panel25.Margin = new System.Windows.Forms.Padding(4);
            this.panel25.Name = "panel25";
            this.panel25.Size = new System.Drawing.Size(1355, 12);
            this.panel25.TabIndex = 0;
            // 
            // panel26
            // 
            this.panel26.Controls.Add(this.panel27);
            this.panel26.Controls.Add(this.panel28);
            this.panel26.Controls.Add(this.panel29);
            this.panel26.Dock = System.Windows.Forms.DockStyle.Right;
            this.panel26.Location = new System.Drawing.Point(1521, 0);
            this.panel26.Margin = new System.Windows.Forms.Padding(4);
            this.panel26.Name = "panel26";
            this.panel26.Size = new System.Drawing.Size(121, 265);
            this.panel26.TabIndex = 8;
            // 
            // panel27
            // 
            this.panel27.Controls.Add(this.btnRightRequestBook);
            this.panel27.Dock = System.Windows.Forms.DockStyle.Right;
            this.panel27.Location = new System.Drawing.Point(48, 98);
            this.panel27.Margin = new System.Windows.Forms.Padding(4);
            this.panel27.Name = "panel27";
            this.panel27.Size = new System.Drawing.Size(73, 69);
            this.panel27.TabIndex = 6;
            // 
            // btnRightRequestBook
            // 
            this.btnRightRequestBook.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.btnRightRequestBook.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.btnRightRequestBook.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.btnRightRequestBook.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.btnRightRequestBook.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnRightRequestBook.FillColor = System.Drawing.Color.PaleTurquoise;
            this.btnRightRequestBook.Font = new System.Drawing.Font("Segoe UI", 26.25F);
            this.btnRightRequestBook.ForeColor = System.Drawing.Color.Black;
            this.btnRightRequestBook.Image = global::QuanLiThuVienUeh.Properties.Resources.Right;
            this.btnRightRequestBook.ImageSize = new System.Drawing.Size(40, 40);
            this.btnRightRequestBook.Location = new System.Drawing.Point(0, 0);
            this.btnRightRequestBook.Margin = new System.Windows.Forms.Padding(4, 4, 45, 4);
            this.btnRightRequestBook.Name = "btnRightRequestBook";
            this.btnRightRequestBook.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle;
            this.btnRightRequestBook.Size = new System.Drawing.Size(73, 69);
            this.btnRightRequestBook.TabIndex = 1;
            this.btnRightRequestBook.Click += new System.EventHandler(this.btnRightRequestBook_Click);
            // 
            // panel28
            // 
            this.panel28.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel28.Location = new System.Drawing.Point(0, 0);
            this.panel28.Margin = new System.Windows.Forms.Padding(4);
            this.panel28.Name = "panel28";
            this.panel28.Size = new System.Drawing.Size(121, 98);
            this.panel28.TabIndex = 0;
            // 
            // panel29
            // 
            this.panel29.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel29.Location = new System.Drawing.Point(0, 167);
            this.panel29.Margin = new System.Windows.Forms.Padding(4);
            this.panel29.Name = "panel29";
            this.panel29.Size = new System.Drawing.Size(121, 98);
            this.panel29.TabIndex = 1;
            // 
            // panel30
            // 
            this.panel30.Controls.Add(this.panel31);
            this.panel30.Controls.Add(this.panel32);
            this.panel30.Controls.Add(this.panel34);
            this.panel30.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel30.Location = new System.Drawing.Point(45, 0);
            this.panel30.Margin = new System.Windows.Forms.Padding(4);
            this.panel30.Name = "panel30";
            this.panel30.Size = new System.Drawing.Size(121, 265);
            this.panel30.TabIndex = 7;
            // 
            // panel31
            // 
            this.panel31.Controls.Add(this.btnLeftRequestBook);
            this.panel31.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel31.Location = new System.Drawing.Point(0, 98);
            this.panel31.Margin = new System.Windows.Forms.Padding(4);
            this.panel31.Name = "panel31";
            this.panel31.Size = new System.Drawing.Size(73, 69);
            this.panel31.TabIndex = 6;
            // 
            // btnLeftRequestBook
            // 
            this.btnLeftRequestBook.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.btnLeftRequestBook.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.btnLeftRequestBook.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.btnLeftRequestBook.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.btnLeftRequestBook.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnLeftRequestBook.FillColor = System.Drawing.Color.PaleTurquoise;
            this.btnLeftRequestBook.Font = new System.Drawing.Font("Segoe UI", 26.25F);
            this.btnLeftRequestBook.ForeColor = System.Drawing.Color.Black;
            this.btnLeftRequestBook.Image = global::QuanLiThuVienUeh.Properties.Resources.Left;
            this.btnLeftRequestBook.ImageSize = new System.Drawing.Size(40, 40);
            this.btnLeftRequestBook.Location = new System.Drawing.Point(0, 0);
            this.btnLeftRequestBook.Margin = new System.Windows.Forms.Padding(45, 4, 4, 4);
            this.btnLeftRequestBook.Name = "btnLeftRequestBook";
            this.btnLeftRequestBook.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle;
            this.btnLeftRequestBook.Size = new System.Drawing.Size(73, 69);
            this.btnLeftRequestBook.TabIndex = 2;
            this.btnLeftRequestBook.Click += new System.EventHandler(this.btnLeftRequestBook_Click);
            // 
            // panel32
            // 
            this.panel32.Controls.Add(this.panel33);
            this.panel32.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel32.Location = new System.Drawing.Point(0, 0);
            this.panel32.Margin = new System.Windows.Forms.Padding(4);
            this.panel32.Name = "panel32";
            this.panel32.Size = new System.Drawing.Size(121, 98);
            this.panel32.TabIndex = 0;
            // 
            // panel33
            // 
            this.panel33.Controls.Add(this.label5);
            this.panel33.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel33.Location = new System.Drawing.Point(0, 0);
            this.panel33.Margin = new System.Windows.Forms.Padding(4);
            this.panel33.Name = "panel33";
            this.panel33.Size = new System.Drawing.Size(121, 46);
            this.panel33.TabIndex = 0;
            // 
            // label5
            // 
            this.label5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label5.Font = new System.Drawing.Font("Segoe UI Semibold", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(95)))), ((int)(((byte)(105)))));
            this.label5.Location = new System.Drawing.Point(0, 0);
            this.label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(121, 46);
            this.label5.TabIndex = 0;
            this.label5.Text = "GỢI Ý";
            this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panel34
            // 
            this.panel34.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel34.Location = new System.Drawing.Point(0, 167);
            this.panel34.Margin = new System.Windows.Forms.Padding(4);
            this.panel34.Name = "panel34";
            this.panel34.Size = new System.Drawing.Size(121, 98);
            this.panel34.TabIndex = 1;
            // 
            // panel35
            // 
            this.panel35.Dock = System.Windows.Forms.DockStyle.Right;
            this.panel35.Location = new System.Drawing.Point(1642, 0);
            this.panel35.Margin = new System.Windows.Forms.Padding(4);
            this.panel35.Name = "panel35";
            this.panel35.Size = new System.Drawing.Size(45, 265);
            this.panel35.TabIndex = 5;
            // 
            // panel36
            // 
            this.panel36.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel36.Location = new System.Drawing.Point(0, 0);
            this.panel36.Margin = new System.Windows.Forms.Padding(4);
            this.panel36.Name = "panel36";
            this.panel36.Size = new System.Drawing.Size(45, 265);
            this.panel36.TabIndex = 4;
            // 
            // lblTimer
            // 
            this.lblTimer.Enabled = true;
            this.lblTimer.Interval = 10000;
            this.lblTimer.Tick += new System.EventHandler(this.lblTimer_Tick);
            // 
            // ff_Home
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1540, 832);
            this.Controls.Add(this.flowLayoutPanel1);
            this.Controls.Add(this.panelThongTin);
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "ff_Home";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form1";
            this.flowLayoutPanel1.ResumeLayout(false);
            this.panelSachMoi.ResumeLayout(false);
            this.panel11.ResumeLayout(false);
            this.panel18.ResumeLayout(false);
            this.panel16.ResumeLayout(false);
            this.panel16.PerformLayout();
            this.panel15.ResumeLayout(false);
            this.panel15.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBook)).EndInit();
            this.panel7.ResumeLayout(false);
            this.panel8.ResumeLayout(false);
            this.panel4.ResumeLayout(false);
            this.panel3.ResumeLayout(false);
            this.panel5.ResumeLayout(false);
            this.panel14.ResumeLayout(false);
            this.panelSachGoiY.ResumeLayout(false);
            this.panel19.ResumeLayout(false);
            this.panel20.ResumeLayout(false);
            this.panel22.ResumeLayout(false);
            this.panel22.PerformLayout();
            this.panel23.ResumeLayout(false);
            this.panel23.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureRequestBook)).EndInit();
            this.panel26.ResumeLayout(false);
            this.panel27.ResumeLayout(false);
            this.panel30.ResumeLayout(false);
            this.panel31.ResumeLayout(false);
            this.panel32.ResumeLayout(false);
            this.panel33.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panelThongTin;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel1;
        private Guna.UI2.WinForms.Guna2CircleButton btnRightNewBook;
        private Guna.UI2.WinForms.Guna2Panel panelSachMoi;
        private Guna.UI2.WinForms.Guna2CircleButton btnLeftNewBook;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Panel panel11;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.Panel panel8;
        private System.Windows.Forms.Panel panel9;
        private System.Windows.Forms.Panel panel10;
        private System.Windows.Forms.PictureBox pictureBook;
        private System.Windows.Forms.Panel panel13;
        private System.Windows.Forms.Panel panel12;
        private System.Windows.Forms.Panel panel14;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel16;
        private System.Windows.Forms.Panel panel15;
        private System.Windows.Forms.Label lblTuaDe;
        private System.Windows.Forms.Panel panel18;
        private System.Windows.Forms.Label lblNoiDung;
        private System.Windows.Forms.Panel panel17;
        private System.Windows.Forms.Label lblTacGia;
        private Guna.UI2.WinForms.Guna2Panel panelSachGoiY;
        private System.Windows.Forms.Panel panel19;
        private System.Windows.Forms.Panel panel20;
        private System.Windows.Forms.Label lblNoiDungRequest;
        private System.Windows.Forms.Panel panel21;
        private System.Windows.Forms.Panel panel22;
        private System.Windows.Forms.Label lblTacGiaRequest;
        private System.Windows.Forms.Panel panel23;
        private System.Windows.Forms.Label lblTuaDeRequest;
        private System.Windows.Forms.PictureBox pictureRequestBook;
        private System.Windows.Forms.Panel panel24;
        private System.Windows.Forms.Panel panel25;
        private System.Windows.Forms.Panel panel26;
        private System.Windows.Forms.Panel panel27;
        private Guna.UI2.WinForms.Guna2CircleButton btnRightRequestBook;
        private System.Windows.Forms.Panel panel28;
        private System.Windows.Forms.Panel panel29;
        private System.Windows.Forms.Panel panel30;
        private System.Windows.Forms.Panel panel31;
        private Guna.UI2.WinForms.Guna2CircleButton btnLeftRequestBook;
        private System.Windows.Forms.Panel panel32;
        private System.Windows.Forms.Panel panel33;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Panel panel34;
        private System.Windows.Forms.Panel panel35;
        private System.Windows.Forms.Panel panel36;
        private System.Windows.Forms.Timer lblTimer;
    }
}