﻿namespace QuanLiThuVienUeh.nguoidung
{
    partial class ffc_ThongTinSachChiTiet
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ffc_ThongTinSachChiTiet));
            this.label_NhaXuatBanInfo = new System.Windows.Forms.Label();
            this.label_NhaXuatBan = new System.Windows.Forms.Label();
            this.label_NgonNguInfo = new System.Windows.Forms.Label();
            this.label_PhienBanInfo = new System.Windows.Forms.Label();
            this.label_NamXuatBanInfo = new System.Windows.Forms.Label();
            this.label_TheLoaiInfo = new System.Windows.Forms.Label();
            this.label_TacGiaInfo = new System.Windows.Forms.Label();
            this.label_IDInfo = new System.Windows.Forms.Label();
            this.label_NgonNgu = new System.Windows.Forms.Label();
            this.label_PhienBan = new System.Windows.Forms.Label();
            this.label_NamXuatBan = new System.Windows.Forms.Label();
            this.label_TheLoai = new System.Windows.Forms.Label();
            this.label_TacGia = new System.Windows.Forms.Label();
            this.label_ID = new System.Windows.Forms.Label();
            this.label_TenSach = new System.Windows.Forms.Label();
            this.textBox_GioiThieu = new System.Windows.Forms.TextBox();
            this.pictureBox_UehLogoIcon = new System.Windows.Forms.PictureBox();
            this.pictureBox_Avatar = new System.Windows.Forms.PictureBox();
            this.label_GioiThieu = new System.Windows.Forms.Label();
            this.button_Booking = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_UehLogoIcon)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_Avatar)).BeginInit();
            this.SuspendLayout();
            // 
            // label_NhaXuatBanInfo
            // 
            this.label_NhaXuatBanInfo.AutoSize = true;
            this.label_NhaXuatBanInfo.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label_NhaXuatBanInfo.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_NhaXuatBanInfo.ForeColor = System.Drawing.Color.Black;
            this.label_NhaXuatBanInfo.Location = new System.Drawing.Point(659, 287);
            this.label_NhaXuatBanInfo.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_NhaXuatBanInfo.Name = "label_NhaXuatBanInfo";
            this.label_NhaXuatBanInfo.Size = new System.Drawing.Size(29, 32);
            this.label_NhaXuatBanInfo.TabIndex = 41;
            this.label_NhaXuatBanInfo.Text = "...";
            // 
            // label_NhaXuatBan
            // 
            this.label_NhaXuatBan.AutoSize = true;
            this.label_NhaXuatBan.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label_NhaXuatBan.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_NhaXuatBan.ForeColor = System.Drawing.Color.Black;
            this.label_NhaXuatBan.Location = new System.Drawing.Point(407, 287);
            this.label_NhaXuatBan.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_NhaXuatBan.Name = "label_NhaXuatBan";
            this.label_NhaXuatBan.Size = new System.Drawing.Size(162, 32);
            this.label_NhaXuatBan.TabIndex = 40;
            this.label_NhaXuatBan.Text = "Nhà xuất bản:";
            // 
            // label_NgonNguInfo
            // 
            this.label_NgonNguInfo.AutoSize = true;
            this.label_NgonNguInfo.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label_NgonNguInfo.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_NgonNguInfo.ForeColor = System.Drawing.Color.Black;
            this.label_NgonNguInfo.Location = new System.Drawing.Point(659, 143);
            this.label_NgonNguInfo.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_NgonNguInfo.Name = "label_NgonNguInfo";
            this.label_NgonNguInfo.Size = new System.Drawing.Size(29, 32);
            this.label_NgonNguInfo.TabIndex = 38;
            this.label_NgonNguInfo.Text = "...";
            // 
            // label_PhienBanInfo
            // 
            this.label_PhienBanInfo.AutoSize = true;
            this.label_PhienBanInfo.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label_PhienBanInfo.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_PhienBanInfo.ForeColor = System.Drawing.Color.Black;
            this.label_PhienBanInfo.Location = new System.Drawing.Point(659, 388);
            this.label_PhienBanInfo.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_PhienBanInfo.Name = "label_PhienBanInfo";
            this.label_PhienBanInfo.Size = new System.Drawing.Size(29, 32);
            this.label_PhienBanInfo.TabIndex = 37;
            this.label_PhienBanInfo.Text = "...";
            // 
            // label_NamXuatBanInfo
            // 
            this.label_NamXuatBanInfo.AutoSize = true;
            this.label_NamXuatBanInfo.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label_NamXuatBanInfo.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_NamXuatBanInfo.ForeColor = System.Drawing.Color.Black;
            this.label_NamXuatBanInfo.Location = new System.Drawing.Point(659, 340);
            this.label_NamXuatBanInfo.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_NamXuatBanInfo.Name = "label_NamXuatBanInfo";
            this.label_NamXuatBanInfo.Size = new System.Drawing.Size(29, 32);
            this.label_NamXuatBanInfo.TabIndex = 36;
            this.label_NamXuatBanInfo.Text = "...";
            // 
            // label_TheLoaiInfo
            // 
            this.label_TheLoaiInfo.AutoSize = true;
            this.label_TheLoaiInfo.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label_TheLoaiInfo.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_TheLoaiInfo.ForeColor = System.Drawing.Color.Black;
            this.label_TheLoaiInfo.Location = new System.Drawing.Point(659, 239);
            this.label_TheLoaiInfo.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_TheLoaiInfo.Name = "label_TheLoaiInfo";
            this.label_TheLoaiInfo.Size = new System.Drawing.Size(29, 32);
            this.label_TheLoaiInfo.TabIndex = 35;
            this.label_TheLoaiInfo.Text = "...";
            // 
            // label_TacGiaInfo
            // 
            this.label_TacGiaInfo.AutoSize = true;
            this.label_TacGiaInfo.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label_TacGiaInfo.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_TacGiaInfo.ForeColor = System.Drawing.Color.Black;
            this.label_TacGiaInfo.Location = new System.Drawing.Point(659, 188);
            this.label_TacGiaInfo.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_TacGiaInfo.Name = "label_TacGiaInfo";
            this.label_TacGiaInfo.Size = new System.Drawing.Size(29, 32);
            this.label_TacGiaInfo.TabIndex = 34;
            this.label_TacGiaInfo.Text = "...";
            // 
            // label_IDInfo
            // 
            this.label_IDInfo.AutoSize = true;
            this.label_IDInfo.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label_IDInfo.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_IDInfo.ForeColor = System.Drawing.Color.Black;
            this.label_IDInfo.Location = new System.Drawing.Point(148, 356);
            this.label_IDInfo.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_IDInfo.Name = "label_IDInfo";
            this.label_IDInfo.Size = new System.Drawing.Size(29, 32);
            this.label_IDInfo.TabIndex = 33;
            this.label_IDInfo.Text = "...";
            // 
            // label_NgonNgu
            // 
            this.label_NgonNgu.AutoSize = true;
            this.label_NgonNgu.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label_NgonNgu.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_NgonNgu.ForeColor = System.Drawing.Color.Black;
            this.label_NgonNgu.Location = new System.Drawing.Point(407, 143);
            this.label_NgonNgu.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_NgonNgu.Name = "label_NgonNgu";
            this.label_NgonNgu.Size = new System.Drawing.Size(128, 32);
            this.label_NgonNgu.TabIndex = 31;
            this.label_NgonNgu.Text = "Ngôn ngữ:";
            // 
            // label_PhienBan
            // 
            this.label_PhienBan.AutoSize = true;
            this.label_PhienBan.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label_PhienBan.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_PhienBan.ForeColor = System.Drawing.Color.Black;
            this.label_PhienBan.Location = new System.Drawing.Point(407, 388);
            this.label_PhienBan.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_PhienBan.Name = "label_PhienBan";
            this.label_PhienBan.Size = new System.Drawing.Size(126, 32);
            this.label_PhienBan.TabIndex = 30;
            this.label_PhienBan.Text = "Phiên bản:";
            // 
            // label_NamXuatBan
            // 
            this.label_NamXuatBan.AutoSize = true;
            this.label_NamXuatBan.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label_NamXuatBan.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_NamXuatBan.ForeColor = System.Drawing.Color.Black;
            this.label_NamXuatBan.Location = new System.Drawing.Point(407, 340);
            this.label_NamXuatBan.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_NamXuatBan.Name = "label_NamXuatBan";
            this.label_NamXuatBan.Size = new System.Drawing.Size(169, 32);
            this.label_NamXuatBan.TabIndex = 29;
            this.label_NamXuatBan.Text = "Năm xuất bản:";
            // 
            // label_TheLoai
            // 
            this.label_TheLoai.AutoSize = true;
            this.label_TheLoai.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label_TheLoai.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_TheLoai.ForeColor = System.Drawing.Color.Black;
            this.label_TheLoai.Location = new System.Drawing.Point(407, 239);
            this.label_TheLoai.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_TheLoai.Name = "label_TheLoai";
            this.label_TheLoai.Size = new System.Drawing.Size(104, 32);
            this.label_TheLoai.TabIndex = 28;
            this.label_TheLoai.Text = "Thể loại:";
            // 
            // label_TacGia
            // 
            this.label_TacGia.AutoSize = true;
            this.label_TacGia.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label_TacGia.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_TacGia.ForeColor = System.Drawing.Color.Black;
            this.label_TacGia.Location = new System.Drawing.Point(407, 188);
            this.label_TacGia.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_TacGia.Name = "label_TacGia";
            this.label_TacGia.Size = new System.Drawing.Size(91, 32);
            this.label_TacGia.TabIndex = 27;
            this.label_TacGia.Text = "Tác giả:";
            // 
            // label_ID
            // 
            this.label_ID.AutoSize = true;
            this.label_ID.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label_ID.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_ID.ForeColor = System.Drawing.Color.Black;
            this.label_ID.Location = new System.Drawing.Point(35, 356);
            this.label_ID.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_ID.Name = "label_ID";
            this.label_ID.Size = new System.Drawing.Size(99, 32);
            this.label_ID.TabIndex = 26;
            this.label_ID.Text = "ID Sách:";
            // 
            // label_TenSach
            // 
            this.label_TenSach.AutoSize = true;
            this.label_TenSach.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label_TenSach.Font = new System.Drawing.Font("Segoe UI Semibold", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_TenSach.ForeColor = System.Drawing.Color.Black;
            this.label_TenSach.Location = new System.Drawing.Point(407, 80);
            this.label_TenSach.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_TenSach.Name = "label_TenSach";
            this.label_TenSach.Size = new System.Drawing.Size(202, 41);
            this.label_TenSach.TabIndex = 25;
            this.label_TenSach.Text = "Đào Gia Phúc";
            this.label_TenSach.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // textBox_GioiThieu
            // 
            this.textBox_GioiThieu.BackColor = System.Drawing.Color.White;
            this.textBox_GioiThieu.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox_GioiThieu.Enabled = false;
            this.textBox_GioiThieu.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox_GioiThieu.ForeColor = System.Drawing.Color.Black;
            this.textBox_GioiThieu.Location = new System.Drawing.Point(409, 489);
            this.textBox_GioiThieu.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.textBox_GioiThieu.Multiline = true;
            this.textBox_GioiThieu.Name = "textBox_GioiThieu";
            this.textBox_GioiThieu.Size = new System.Drawing.Size(755, 197);
            this.textBox_GioiThieu.TabIndex = 24;
            this.textBox_GioiThieu.Text = "...";
            // 
            // pictureBox_UehLogoIcon
            // 
            this.pictureBox_UehLogoIcon.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox_UehLogoIcon.Image")));
            this.pictureBox_UehLogoIcon.Location = new System.Drawing.Point(41, 15);
            this.pictureBox_UehLogoIcon.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.pictureBox_UehLogoIcon.Name = "pictureBox_UehLogoIcon";
            this.pictureBox_UehLogoIcon.Size = new System.Drawing.Size(88, 58);
            this.pictureBox_UehLogoIcon.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox_UehLogoIcon.TabIndex = 23;
            this.pictureBox_UehLogoIcon.TabStop = false;
            // 
            // pictureBox_Avatar
            // 
            this.pictureBox_Avatar.Location = new System.Drawing.Point(41, 96);
            this.pictureBox_Avatar.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.pictureBox_Avatar.Name = "pictureBox_Avatar";
            this.pictureBox_Avatar.Size = new System.Drawing.Size(264, 240);
            this.pictureBox_Avatar.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox_Avatar.TabIndex = 22;
            this.pictureBox_Avatar.TabStop = false;
            // 
            // label_GioiThieu
            // 
            this.label_GioiThieu.AutoSize = true;
            this.label_GioiThieu.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label_GioiThieu.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_GioiThieu.ForeColor = System.Drawing.Color.Black;
            this.label_GioiThieu.Location = new System.Drawing.Point(407, 438);
            this.label_GioiThieu.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_GioiThieu.Name = "label_GioiThieu";
            this.label_GioiThieu.Size = new System.Drawing.Size(123, 32);
            this.label_GioiThieu.TabIndex = 32;
            this.label_GioiThieu.Text = "Giới thiệu:";
            // 
            // button_Booking
            // 
            this.button_Booking.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(95)))), ((int)(((byte)(105)))));
            this.button_Booking.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button_Booking.FlatAppearance.BorderSize = 0;
            this.button_Booking.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_Booking.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_Booking.ForeColor = System.Drawing.Color.White;
            this.button_Booking.Location = new System.Drawing.Point(41, 410);
            this.button_Booking.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.button_Booking.Name = "button_Booking";
            this.button_Booking.Size = new System.Drawing.Size(165, 59);
            this.button_Booking.TabIndex = 42;
            this.button_Booking.Text = "Booking";
            this.button_Booking.UseVisualStyleBackColor = false;
            this.button_Booking.Click += new System.EventHandler(this.button_Booking_Click);
            // 
            // ffc_ThongTinSachChiTiet
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1199, 782);
            this.Controls.Add(this.button_Booking);
            this.Controls.Add(this.label_NhaXuatBanInfo);
            this.Controls.Add(this.label_NhaXuatBan);
            this.Controls.Add(this.label_NgonNguInfo);
            this.Controls.Add(this.label_PhienBanInfo);
            this.Controls.Add(this.label_NamXuatBanInfo);
            this.Controls.Add(this.label_TheLoaiInfo);
            this.Controls.Add(this.label_TacGiaInfo);
            this.Controls.Add(this.label_IDInfo);
            this.Controls.Add(this.label_GioiThieu);
            this.Controls.Add(this.label_NgonNgu);
            this.Controls.Add(this.label_PhienBan);
            this.Controls.Add(this.label_NamXuatBan);
            this.Controls.Add(this.label_TheLoai);
            this.Controls.Add(this.label_TacGia);
            this.Controls.Add(this.label_ID);
            this.Controls.Add(this.label_TenSach);
            this.Controls.Add(this.textBox_GioiThieu);
            this.Controls.Add(this.pictureBox_UehLogoIcon);
            this.Controls.Add(this.pictureBox_Avatar);
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Name = "ffc_ThongTinSachChiTiet";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "ThongTinSachChiTiet";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_UehLogoIcon)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_Avatar)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label_NhaXuatBanInfo;
        private System.Windows.Forms.Label label_NhaXuatBan;
        private System.Windows.Forms.Label label_NgonNguInfo;
        private System.Windows.Forms.Label label_PhienBanInfo;
        private System.Windows.Forms.Label label_NamXuatBanInfo;
        private System.Windows.Forms.Label label_TheLoaiInfo;
        private System.Windows.Forms.Label label_TacGiaInfo;
        private System.Windows.Forms.Label label_IDInfo;
        private System.Windows.Forms.Label label_NgonNgu;
        private System.Windows.Forms.Label label_PhienBan;
        private System.Windows.Forms.Label label_NamXuatBan;
        private System.Windows.Forms.Label label_TheLoai;
        private System.Windows.Forms.Label label_TacGia;
        private System.Windows.Forms.Label label_ID;
        private System.Windows.Forms.Label label_TenSach;
        private System.Windows.Forms.TextBox textBox_GioiThieu;
        private System.Windows.Forms.PictureBox pictureBox_UehLogoIcon;
        private System.Windows.Forms.PictureBox pictureBox_Avatar;
        private System.Windows.Forms.Label label_GioiThieu;
        private System.Windows.Forms.Button button_Booking;
    }
}