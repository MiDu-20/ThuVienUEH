﻿namespace QuanLiThuVienUeh.nhanvien
{
    partial class ff_DoiMatKhau
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ff_DoiMatKhau));
            this.guna2Panel_Main = new Guna.UI2.WinForms.Guna2Panel();
            this.button_ChangePassword = new System.Windows.Forms.Button();
            this.panel_Password = new System.Windows.Forms.Panel();
            this.textBox_CurrentPassword = new System.Windows.Forms.TextBox();
            this.button_SHCurrentPassword = new System.Windows.Forms.Button();
            this.label_CurrentPassword = new System.Windows.Forms.Label();
            this.label_Username = new System.Windows.Forms.Label();
            this.panel_Username = new System.Windows.Forms.Panel();
            this.textBox_Username = new System.Windows.Forms.TextBox();
            this.button_Login1 = new System.Windows.Forms.Button();
            this.label_DoiMatKhau = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.textBox_NewPassword = new System.Windows.Forms.TextBox();
            this.button_SHNewPassword = new System.Windows.Forms.Button();
            this.label_NewPassword = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.textBox_VerifyPassword = new System.Windows.Forms.TextBox();
            this.button_SHVerifyPassword = new System.Windows.Forms.Button();
            this.label_VerifyPassword = new System.Windows.Forms.Label();
            this.guna2Panel_Main.SuspendLayout();
            this.panel_Password.SuspendLayout();
            this.panel_Username.SuspendLayout();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // guna2Panel_Main
            // 
            this.guna2Panel_Main.BackColor = System.Drawing.Color.White;
            this.guna2Panel_Main.Controls.Add(this.panel2);
            this.guna2Panel_Main.Controls.Add(this.label_VerifyPassword);
            this.guna2Panel_Main.Controls.Add(this.panel1);
            this.guna2Panel_Main.Controls.Add(this.label_NewPassword);
            this.guna2Panel_Main.Controls.Add(this.label_DoiMatKhau);
            this.guna2Panel_Main.Controls.Add(this.button_ChangePassword);
            this.guna2Panel_Main.Controls.Add(this.panel_Password);
            this.guna2Panel_Main.Controls.Add(this.label_CurrentPassword);
            this.guna2Panel_Main.Controls.Add(this.label_Username);
            this.guna2Panel_Main.Controls.Add(this.panel_Username);
            this.guna2Panel_Main.Location = new System.Drawing.Point(4, 2);
            this.guna2Panel_Main.Name = "guna2Panel_Main";
            this.guna2Panel_Main.Size = new System.Drawing.Size(542, 573);
            this.guna2Panel_Main.TabIndex = 0;
            // 
            // button_ChangePassword
            // 
            this.button_ChangePassword.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.button_ChangePassword.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(95)))), ((int)(((byte)(105)))));
            this.button_ChangePassword.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button_ChangePassword.FlatAppearance.BorderSize = 0;
            this.button_ChangePassword.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_ChangePassword.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_ChangePassword.ForeColor = System.Drawing.Color.White;
            this.button_ChangePassword.Location = new System.Drawing.Point(38, 501);
            this.button_ChangePassword.Margin = new System.Windows.Forms.Padding(4);
            this.button_ChangePassword.Name = "button_ChangePassword";
            this.button_ChangePassword.Size = new System.Drawing.Size(471, 47);
            this.button_ChangePassword.TabIndex = 45;
            this.button_ChangePassword.Text = "Change Password";
            this.button_ChangePassword.UseVisualStyleBackColor = false;
            this.button_ChangePassword.Click += new System.EventHandler(this.button_ChangePassword_Click);
            // 
            // panel_Password
            // 
            this.panel_Password.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.panel_Password.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.panel_Password.BackColor = System.Drawing.Color.Gainsboro;
            this.panel_Password.Controls.Add(this.textBox_CurrentPassword);
            this.panel_Password.Controls.Add(this.button_SHCurrentPassword);
            this.panel_Password.Cursor = System.Windows.Forms.Cursors.Hand;
            this.panel_Password.Location = new System.Drawing.Point(38, 210);
            this.panel_Password.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panel_Password.Name = "panel_Password";
            this.panel_Password.Size = new System.Drawing.Size(471, 53);
            this.panel_Password.TabIndex = 44;
            // 
            // textBox_CurrentPassword
            // 
            this.textBox_CurrentPassword.BackColor = System.Drawing.Color.Gainsboro;
            this.textBox_CurrentPassword.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox_CurrentPassword.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox_CurrentPassword.Location = new System.Drawing.Point(7, 10);
            this.textBox_CurrentPassword.Margin = new System.Windows.Forms.Padding(4);
            this.textBox_CurrentPassword.Name = "textBox_CurrentPassword";
            this.textBox_CurrentPassword.Size = new System.Drawing.Size(394, 32);
            this.textBox_CurrentPassword.TabIndex = 5;
            this.textBox_CurrentPassword.UseSystemPasswordChar = true;
            // 
            // button_SHCurrentPassword
            // 
            this.button_SHCurrentPassword.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.button_SHCurrentPassword.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(95)))), ((int)(((byte)(105)))));
            this.button_SHCurrentPassword.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button_SHCurrentPassword.FlatAppearance.BorderSize = 0;
            this.button_SHCurrentPassword.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_SHCurrentPassword.Image = ((System.Drawing.Image)(resources.GetObject("button_SHCurrentPassword.Image")));
            this.button_SHCurrentPassword.Location = new System.Drawing.Point(408, -2);
            this.button_SHCurrentPassword.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.button_SHCurrentPassword.Name = "button_SHCurrentPassword";
            this.button_SHCurrentPassword.Size = new System.Drawing.Size(63, 55);
            this.button_SHCurrentPassword.TabIndex = 3;
            this.button_SHCurrentPassword.UseVisualStyleBackColor = false;
            this.button_SHCurrentPassword.Click += new System.EventHandler(this.button_SHCurrentPassword_Click);
            // 
            // label_CurrentPassword
            // 
            this.label_CurrentPassword.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label_CurrentPassword.AutoSize = true;
            this.label_CurrentPassword.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_CurrentPassword.Location = new System.Drawing.Point(26, 179);
            this.label_CurrentPassword.Name = "label_CurrentPassword";
            this.label_CurrentPassword.Size = new System.Drawing.Size(163, 28);
            this.label_CurrentPassword.TabIndex = 41;
            this.label_CurrentPassword.Text = "Mật khẩu hiện tại";
            // 
            // label_Username
            // 
            this.label_Username.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label_Username.AutoSize = true;
            this.label_Username.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_Username.Location = new System.Drawing.Point(26, 81);
            this.label_Username.Name = "label_Username";
            this.label_Username.Size = new System.Drawing.Size(99, 28);
            this.label_Username.TabIndex = 42;
            this.label_Username.Text = "Username";
            // 
            // panel_Username
            // 
            this.panel_Username.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.panel_Username.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.panel_Username.BackColor = System.Drawing.Color.Gainsboro;
            this.panel_Username.Controls.Add(this.textBox_Username);
            this.panel_Username.Controls.Add(this.button_Login1);
            this.panel_Username.Cursor = System.Windows.Forms.Cursors.Hand;
            this.panel_Username.Location = new System.Drawing.Point(38, 113);
            this.panel_Username.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panel_Username.Name = "panel_Username";
            this.panel_Username.Size = new System.Drawing.Size(471, 53);
            this.panel_Username.TabIndex = 43;
            // 
            // textBox_Username
            // 
            this.textBox_Username.BackColor = System.Drawing.Color.Gainsboro;
            this.textBox_Username.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox_Username.Enabled = false;
            this.textBox_Username.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox_Username.Location = new System.Drawing.Point(4, 10);
            this.textBox_Username.Margin = new System.Windows.Forms.Padding(4);
            this.textBox_Username.Name = "textBox_Username";
            this.textBox_Username.Size = new System.Drawing.Size(397, 32);
            this.textBox_Username.TabIndex = 4;
            // 
            // button_Login1
            // 
            this.button_Login1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.button_Login1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(95)))), ((int)(((byte)(105)))));
            this.button_Login1.FlatAppearance.BorderSize = 0;
            this.button_Login1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_Login1.Image = ((System.Drawing.Image)(resources.GetObject("button_Login1.Image")));
            this.button_Login1.Location = new System.Drawing.Point(408, 0);
            this.button_Login1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.button_Login1.Name = "button_Login1";
            this.button_Login1.Size = new System.Drawing.Size(63, 55);
            this.button_Login1.TabIndex = 3;
            this.button_Login1.UseVisualStyleBackColor = false;
            // 
            // label_DoiMatKhau
            // 
            this.label_DoiMatKhau.AutoSize = true;
            this.label_DoiMatKhau.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_DoiMatKhau.Location = new System.Drawing.Point(25, 20);
            this.label_DoiMatKhau.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_DoiMatKhau.Name = "label_DoiMatKhau";
            this.label_DoiMatKhau.Size = new System.Drawing.Size(203, 37);
            this.label_DoiMatKhau.TabIndex = 49;
            this.label_DoiMatKhau.Text = "ĐỔI MẬT KHẨU";
            this.label_DoiMatKhau.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // panel1
            // 
            this.panel1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.panel1.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.panel1.BackColor = System.Drawing.Color.Gainsboro;
            this.panel1.Controls.Add(this.textBox_NewPassword);
            this.panel1.Controls.Add(this.button_SHNewPassword);
            this.panel1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.panel1.Location = new System.Drawing.Point(38, 312);
            this.panel1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(471, 53);
            this.panel1.TabIndex = 46;
            // 
            // textBox_NewPassword
            // 
            this.textBox_NewPassword.BackColor = System.Drawing.Color.Gainsboro;
            this.textBox_NewPassword.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox_NewPassword.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox_NewPassword.Location = new System.Drawing.Point(7, 10);
            this.textBox_NewPassword.Margin = new System.Windows.Forms.Padding(4);
            this.textBox_NewPassword.Name = "textBox_NewPassword";
            this.textBox_NewPassword.Size = new System.Drawing.Size(394, 32);
            this.textBox_NewPassword.TabIndex = 5;
            this.textBox_NewPassword.UseSystemPasswordChar = true;
            // 
            // button_SHNewPassword
            // 
            this.button_SHNewPassword.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.button_SHNewPassword.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(95)))), ((int)(((byte)(105)))));
            this.button_SHNewPassword.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button_SHNewPassword.FlatAppearance.BorderSize = 0;
            this.button_SHNewPassword.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_SHNewPassword.Image = ((System.Drawing.Image)(resources.GetObject("button_SHNewPassword.Image")));
            this.button_SHNewPassword.Location = new System.Drawing.Point(408, -2);
            this.button_SHNewPassword.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.button_SHNewPassword.Name = "button_SHNewPassword";
            this.button_SHNewPassword.Size = new System.Drawing.Size(63, 55);
            this.button_SHNewPassword.TabIndex = 3;
            this.button_SHNewPassword.UseVisualStyleBackColor = false;
            this.button_SHNewPassword.Click += new System.EventHandler(this.button_SHNewPassword_Click);
            // 
            // label_NewPassword
            // 
            this.label_NewPassword.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label_NewPassword.AutoSize = true;
            this.label_NewPassword.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_NewPassword.Location = new System.Drawing.Point(26, 281);
            this.label_NewPassword.Name = "label_NewPassword";
            this.label_NewPassword.Size = new System.Drawing.Size(133, 28);
            this.label_NewPassword.TabIndex = 45;
            this.label_NewPassword.Text = "Mật khẩu mới";
            // 
            // panel2
            // 
            this.panel2.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.panel2.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.panel2.BackColor = System.Drawing.Color.Gainsboro;
            this.panel2.Controls.Add(this.textBox_VerifyPassword);
            this.panel2.Controls.Add(this.button_SHVerifyPassword);
            this.panel2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.panel2.Location = new System.Drawing.Point(38, 412);
            this.panel2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(471, 53);
            this.panel2.TabIndex = 51;
            // 
            // textBox_VerifyPassword
            // 
            this.textBox_VerifyPassword.BackColor = System.Drawing.Color.Gainsboro;
            this.textBox_VerifyPassword.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox_VerifyPassword.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox_VerifyPassword.Location = new System.Drawing.Point(7, 10);
            this.textBox_VerifyPassword.Margin = new System.Windows.Forms.Padding(4);
            this.textBox_VerifyPassword.Name = "textBox_VerifyPassword";
            this.textBox_VerifyPassword.Size = new System.Drawing.Size(394, 32);
            this.textBox_VerifyPassword.TabIndex = 5;
            this.textBox_VerifyPassword.UseSystemPasswordChar = true;
            // 
            // button_SHVerifyPassword
            // 
            this.button_SHVerifyPassword.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.button_SHVerifyPassword.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(95)))), ((int)(((byte)(105)))));
            this.button_SHVerifyPassword.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button_SHVerifyPassword.FlatAppearance.BorderSize = 0;
            this.button_SHVerifyPassword.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_SHVerifyPassword.Image = ((System.Drawing.Image)(resources.GetObject("button_SHVerifyPassword.Image")));
            this.button_SHVerifyPassword.Location = new System.Drawing.Point(408, -2);
            this.button_SHVerifyPassword.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.button_SHVerifyPassword.Name = "button_SHVerifyPassword";
            this.button_SHVerifyPassword.Size = new System.Drawing.Size(63, 55);
            this.button_SHVerifyPassword.TabIndex = 3;
            this.button_SHVerifyPassword.UseVisualStyleBackColor = false;
            this.button_SHVerifyPassword.Click += new System.EventHandler(this.button_SHVerifyPassword_Click);
            // 
            // label_VerifyPassword
            // 
            this.label_VerifyPassword.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label_VerifyPassword.AutoSize = true;
            this.label_VerifyPassword.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_VerifyPassword.Location = new System.Drawing.Point(26, 381);
            this.label_VerifyPassword.Name = "label_VerifyPassword";
            this.label_VerifyPassword.Size = new System.Drawing.Size(171, 28);
            this.label_VerifyPassword.TabIndex = 50;
            this.label_VerifyPassword.Text = "Nhập lại mật khẩu";
            // 
            // ff_DoiMatKhau
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Gainsboro;
            this.ClientSize = new System.Drawing.Size(547, 576);
            this.Controls.Add(this.guna2Panel_Main);
            this.Name = "ff_DoiMatKhau";
            this.Text = "ff_DoiMatKhau";
            this.guna2Panel_Main.ResumeLayout(false);
            this.guna2Panel_Main.PerformLayout();
            this.panel_Password.ResumeLayout(false);
            this.panel_Password.PerformLayout();
            this.panel_Username.ResumeLayout(false);
            this.panel_Username.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private Guna.UI2.WinForms.Guna2Panel guna2Panel_Main;
        private System.Windows.Forms.Button button_ChangePassword;
        private System.Windows.Forms.Panel panel_Password;
        private System.Windows.Forms.TextBox textBox_CurrentPassword;
        private System.Windows.Forms.Button button_SHCurrentPassword;
        private System.Windows.Forms.Label label_CurrentPassword;
        private System.Windows.Forms.Label label_Username;
        private System.Windows.Forms.Panel panel_Username;
        private System.Windows.Forms.TextBox textBox_Username;
        private System.Windows.Forms.Button button_Login1;
        private System.Windows.Forms.Label label_DoiMatKhau;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.TextBox textBox_VerifyPassword;
        private System.Windows.Forms.Button button_SHVerifyPassword;
        private System.Windows.Forms.Label label_VerifyPassword;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.TextBox textBox_NewPassword;
        private System.Windows.Forms.Button button_SHNewPassword;
        private System.Windows.Forms.Label label_NewPassword;
    }
}