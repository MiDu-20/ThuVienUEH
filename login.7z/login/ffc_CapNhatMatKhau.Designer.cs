﻿namespace QuanLiThuVienUeh.login
{
    partial class ffc_CapNhatMatKhau
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ffc_CapNhatMatKhau));
            this.pictureBox_UehLogo = new System.Windows.Forms.PictureBox();
            this.button_SignIn = new System.Windows.Forms.Button();
            this.panel_Password = new System.Windows.Forms.Panel();
            this.textBox_Password = new System.Windows.Forms.TextBox();
            this.button_SHPassword = new System.Windows.Forms.Button();
            this.label_Password = new System.Windows.Forms.Label();
            this.label_Username = new System.Windows.Forms.Label();
            this.panel_Username = new System.Windows.Forms.Panel();
            this.textBox_Username = new System.Windows.Forms.TextBox();
            this.button_Login1 = new System.Windows.Forms.Button();
            this.label_XinChao = new System.Windows.Forms.Label();
            this.label_Ten = new System.Windows.Forms.Label();
            this.label_ThongBao = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_UehLogo)).BeginInit();
            this.panel_Password.SuspendLayout();
            this.panel_Username.SuspendLayout();
            this.SuspendLayout();
            // 
            // pictureBox_UehLogo
            // 
            this.pictureBox_UehLogo.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.pictureBox_UehLogo.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox_UehLogo.Image")));
            this.pictureBox_UehLogo.Location = new System.Drawing.Point(163, 31);
            this.pictureBox_UehLogo.Margin = new System.Windows.Forms.Padding(5, 5, 5, 5);
            this.pictureBox_UehLogo.Name = "pictureBox_UehLogo";
            this.pictureBox_UehLogo.Size = new System.Drawing.Size(204, 129);
            this.pictureBox_UehLogo.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox_UehLogo.TabIndex = 27;
            this.pictureBox_UehLogo.TabStop = false;
            // 
            // button_SignIn
            // 
            this.button_SignIn.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.button_SignIn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(95)))), ((int)(((byte)(105)))));
            this.button_SignIn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button_SignIn.FlatAppearance.BorderSize = 0;
            this.button_SignIn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_SignIn.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_SignIn.ForeColor = System.Drawing.Color.White;
            this.button_SignIn.Location = new System.Drawing.Point(88, 481);
            this.button_SignIn.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.button_SignIn.Name = "button_SignIn";
            this.button_SignIn.Size = new System.Drawing.Size(373, 47);
            this.button_SignIn.TabIndex = 36;
            this.button_SignIn.Text = "Continue Login";
            this.button_SignIn.UseVisualStyleBackColor = false;
            this.button_SignIn.Click += new System.EventHandler(this.button_SignIn_Click);
            // 
            // panel_Password
            // 
            this.panel_Password.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.panel_Password.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.panel_Password.BackColor = System.Drawing.Color.Gainsboro;
            this.panel_Password.Controls.Add(this.textBox_Password);
            this.panel_Password.Controls.Add(this.button_SHPassword);
            this.panel_Password.Cursor = System.Windows.Forms.Cursors.Hand;
            this.panel_Password.Location = new System.Drawing.Point(88, 389);
            this.panel_Password.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panel_Password.Name = "panel_Password";
            this.panel_Password.Size = new System.Drawing.Size(373, 53);
            this.panel_Password.TabIndex = 35;
            // 
            // textBox_Password
            // 
            this.textBox_Password.BackColor = System.Drawing.Color.Gainsboro;
            this.textBox_Password.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox_Password.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox_Password.Location = new System.Drawing.Point(7, 10);
            this.textBox_Password.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.textBox_Password.Name = "textBox_Password";
            this.textBox_Password.Size = new System.Drawing.Size(297, 32);
            this.textBox_Password.TabIndex = 5;
            this.textBox_Password.UseSystemPasswordChar = true;
            // 
            // button_SHPassword
            // 
            this.button_SHPassword.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.button_SHPassword.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(95)))), ((int)(((byte)(105)))));
            this.button_SHPassword.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button_SHPassword.FlatAppearance.BorderSize = 0;
            this.button_SHPassword.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_SHPassword.Image = ((System.Drawing.Image)(resources.GetObject("button_SHPassword.Image")));
            this.button_SHPassword.Location = new System.Drawing.Point(311, -1);
            this.button_SHPassword.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.button_SHPassword.Name = "button_SHPassword";
            this.button_SHPassword.Size = new System.Drawing.Size(63, 55);
            this.button_SHPassword.TabIndex = 3;
            this.button_SHPassword.UseVisualStyleBackColor = false;
            this.button_SHPassword.Click += new System.EventHandler(this.button_SHPassword_Click);
            // 
            // label_Password
            // 
            this.label_Password.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label_Password.AutoSize = true;
            this.label_Password.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_Password.Location = new System.Drawing.Point(76, 358);
            this.label_Password.Name = "label_Password";
            this.label_Password.Size = new System.Drawing.Size(163, 28);
            this.label_Password.TabIndex = 32;
            this.label_Password.Text = "Update Password";
            // 
            // label_Username
            // 
            this.label_Username.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label_Username.AutoSize = true;
            this.label_Username.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_Username.Location = new System.Drawing.Point(76, 260);
            this.label_Username.Name = "label_Username";
            this.label_Username.Size = new System.Drawing.Size(99, 28);
            this.label_Username.TabIndex = 33;
            this.label_Username.Text = "Username";
            // 
            // panel_Username
            // 
            this.panel_Username.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.panel_Username.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.panel_Username.BackColor = System.Drawing.Color.Gainsboro;
            this.panel_Username.Controls.Add(this.textBox_Username);
            this.panel_Username.Controls.Add(this.button_Login1);
            this.panel_Username.Cursor = System.Windows.Forms.Cursors.Hand;
            this.panel_Username.Location = new System.Drawing.Point(88, 292);
            this.panel_Username.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panel_Username.Name = "panel_Username";
            this.panel_Username.Size = new System.Drawing.Size(373, 53);
            this.panel_Username.TabIndex = 34;
            // 
            // textBox_Username
            // 
            this.textBox_Username.BackColor = System.Drawing.Color.Gainsboro;
            this.textBox_Username.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox_Username.Enabled = false;
            this.textBox_Username.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox_Username.Location = new System.Drawing.Point(4, 10);
            this.textBox_Username.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.textBox_Username.Name = "textBox_Username";
            this.textBox_Username.Size = new System.Drawing.Size(300, 32);
            this.textBox_Username.TabIndex = 4;
            // 
            // button_Login1
            // 
            this.button_Login1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.button_Login1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(95)))), ((int)(((byte)(105)))));
            this.button_Login1.FlatAppearance.BorderSize = 0;
            this.button_Login1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_Login1.Image = ((System.Drawing.Image)(resources.GetObject("button_Login1.Image")));
            this.button_Login1.Location = new System.Drawing.Point(311, -1);
            this.button_Login1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.button_Login1.Name = "button_Login1";
            this.button_Login1.Size = new System.Drawing.Size(63, 55);
            this.button_Login1.TabIndex = 3;
            this.button_Login1.UseVisualStyleBackColor = false;
            // 
            // label_XinChao
            // 
            this.label_XinChao.AutoSize = true;
            this.label_XinChao.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_XinChao.Location = new System.Drawing.Point(107, 187);
            this.label_XinChao.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_XinChao.Name = "label_XinChao";
            this.label_XinChao.Size = new System.Drawing.Size(91, 28);
            this.label_XinChao.TabIndex = 37;
            this.label_XinChao.Text = "Xin chào,";
            // 
            // label_Ten
            // 
            this.label_Ten.AutoSize = true;
            this.label_Ten.Font = new System.Drawing.Font("Segoe UI Semibold", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_Ten.Location = new System.Drawing.Point(197, 178);
            this.label_Ten.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_Ten.Name = "label_Ten";
            this.label_Ten.Size = new System.Drawing.Size(218, 37);
            this.label_Ten.TabIndex = 38;
            this.label_Ten.Text = "SƠN TÙNG MTP";
            // 
            // label_ThongBao
            // 
            this.label_ThongBao.AutoSize = true;
            this.label_ThongBao.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_ThongBao.Location = new System.Drawing.Point(93, 215);
            this.label_ThongBao.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_ThongBao.Name = "label_ThongBao";
            this.label_ThongBao.Size = new System.Drawing.Size(349, 28);
            this.label_ThongBao.TabIndex = 39;
            this.label_ThongBao.Text = "Vui lòng cập nhật mật khẩu để tiếp tục";
            // 
            // ffc_CapNhatMatKhau
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(547, 576);
            this.Controls.Add(this.label_ThongBao);
            this.Controls.Add(this.label_Ten);
            this.Controls.Add(this.label_XinChao);
            this.Controls.Add(this.button_SignIn);
            this.Controls.Add(this.panel_Password);
            this.Controls.Add(this.label_Password);
            this.Controls.Add(this.label_Username);
            this.Controls.Add(this.panel_Username);
            this.Controls.Add(this.pictureBox_UehLogo);
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Name = "ffc_CapNhatMatKhau";
            this.ShowIcon = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "ffc_CapNhatMatKhau";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_UehLogo)).EndInit();
            this.panel_Password.ResumeLayout(false);
            this.panel_Password.PerformLayout();
            this.panel_Username.ResumeLayout(false);
            this.panel_Username.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox_UehLogo;
        private System.Windows.Forms.Button button_SignIn;
        private System.Windows.Forms.Panel panel_Password;
        private System.Windows.Forms.TextBox textBox_Password;
        private System.Windows.Forms.Button button_SHPassword;
        private System.Windows.Forms.Label label_Password;
        private System.Windows.Forms.Label label_Username;
        private System.Windows.Forms.Panel panel_Username;
        private System.Windows.Forms.TextBox textBox_Username;
        private System.Windows.Forms.Button button_Login1;
        private System.Windows.Forms.Label label_XinChao;
        private System.Windows.Forms.Label label_Ten;
        private System.Windows.Forms.Label label_ThongBao;
    }
}