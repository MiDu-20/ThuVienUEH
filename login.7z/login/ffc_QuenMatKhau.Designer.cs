﻿namespace QuanLiThuVienUeh.login
{
    partial class ffc_QuenMatKhau
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ffc_QuenMatKhau));
            this.button_SignIn = new System.Windows.Forms.Button();
            this.label_Username = new System.Windows.Forms.Label();
            this.panel_Username = new System.Windows.Forms.Panel();
            this.textBox_Username = new System.Windows.Forms.TextBox();
            this.button_Login1 = new System.Windows.Forms.Button();
            this.pictureBox_UehLogo = new System.Windows.Forms.PictureBox();
            this.textBox_OTP = new System.Windows.Forms.TextBox();
            this.button_GuiOTP = new System.Windows.Forms.Button();
            this.label_OTP = new System.Windows.Forms.Label();
            this.panel_Username.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_UehLogo)).BeginInit();
            this.SuspendLayout();
            // 
            // button_SignIn
            // 
            this.button_SignIn.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.button_SignIn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(95)))), ((int)(((byte)(105)))));
            this.button_SignIn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button_SignIn.FlatAppearance.BorderSize = 0;
            this.button_SignIn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_SignIn.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_SignIn.ForeColor = System.Drawing.Color.White;
            this.button_SignIn.Location = new System.Drawing.Point(57, 321);
            this.button_SignIn.Name = "button_SignIn";
            this.button_SignIn.Size = new System.Drawing.Size(280, 38);
            this.button_SignIn.TabIndex = 31;
            this.button_SignIn.Text = "Continue Login";
            this.button_SignIn.UseVisualStyleBackColor = false;
            this.button_SignIn.Click += new System.EventHandler(this.button_SignIn_Click);
            // 
            // label_Username
            // 
            this.label_Username.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label_Username.AutoSize = true;
            this.label_Username.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_Username.Location = new System.Drawing.Point(48, 142);
            this.label_Username.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label_Username.Name = "label_Username";
            this.label_Username.Size = new System.Drawing.Size(81, 21);
            this.label_Username.TabIndex = 28;
            this.label_Username.Text = "Username";
            // 
            // panel_Username
            // 
            this.panel_Username.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.panel_Username.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.panel_Username.BackColor = System.Drawing.Color.Gainsboro;
            this.panel_Username.Controls.Add(this.textBox_Username);
            this.panel_Username.Controls.Add(this.button_Login1);
            this.panel_Username.Cursor = System.Windows.Forms.Cursors.Hand;
            this.panel_Username.Location = new System.Drawing.Point(57, 169);
            this.panel_Username.Margin = new System.Windows.Forms.Padding(2);
            this.panel_Username.Name = "panel_Username";
            this.panel_Username.Size = new System.Drawing.Size(280, 43);
            this.panel_Username.TabIndex = 29;
            // 
            // textBox_Username
            // 
            this.textBox_Username.BackColor = System.Drawing.Color.Gainsboro;
            this.textBox_Username.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox_Username.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox_Username.Location = new System.Drawing.Point(3, 8);
            this.textBox_Username.Name = "textBox_Username";
            this.textBox_Username.Size = new System.Drawing.Size(225, 26);
            this.textBox_Username.TabIndex = 4;
            // 
            // button_Login1
            // 
            this.button_Login1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.button_Login1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(95)))), ((int)(((byte)(105)))));
            this.button_Login1.FlatAppearance.BorderSize = 0;
            this.button_Login1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_Login1.Image = ((System.Drawing.Image)(resources.GetObject("button_Login1.Image")));
            this.button_Login1.Location = new System.Drawing.Point(233, -1);
            this.button_Login1.Margin = new System.Windows.Forms.Padding(2);
            this.button_Login1.Name = "button_Login1";
            this.button_Login1.Size = new System.Drawing.Size(47, 45);
            this.button_Login1.TabIndex = 3;
            this.button_Login1.UseVisualStyleBackColor = false;
            // 
            // pictureBox_UehLogo
            // 
            this.pictureBox_UehLogo.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.pictureBox_UehLogo.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox_UehLogo.Image")));
            this.pictureBox_UehLogo.Location = new System.Drawing.Point(116, 8);
            this.pictureBox_UehLogo.Margin = new System.Windows.Forms.Padding(4);
            this.pictureBox_UehLogo.Name = "pictureBox_UehLogo";
            this.pictureBox_UehLogo.Size = new System.Drawing.Size(153, 105);
            this.pictureBox_UehLogo.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox_UehLogo.TabIndex = 26;
            this.pictureBox_UehLogo.TabStop = false;
            // 
            // textBox_OTP
            // 
            this.textBox_OTP.BackColor = System.Drawing.Color.White;
            this.textBox_OTP.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox_OTP.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox_OTP.Location = new System.Drawing.Point(57, 241);
            this.textBox_OTP.Name = "textBox_OTP";
            this.textBox_OTP.Size = new System.Drawing.Size(146, 35);
            this.textBox_OTP.TabIndex = 32;
            // 
            // button_GuiOTP
            // 
            this.button_GuiOTP.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.button_GuiOTP.BackColor = System.Drawing.Color.White;
            this.button_GuiOTP.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button_GuiOTP.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(95)))), ((int)(((byte)(105)))));
            this.button_GuiOTP.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_GuiOTP.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_GuiOTP.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(95)))), ((int)(((byte)(105)))));
            this.button_GuiOTP.Location = new System.Drawing.Point(237, 238);
            this.button_GuiOTP.Name = "button_GuiOTP";
            this.button_GuiOTP.Size = new System.Drawing.Size(100, 38);
            this.button_GuiOTP.TabIndex = 33;
            this.button_GuiOTP.Text = "Gửi OTP";
            this.button_GuiOTP.UseVisualStyleBackColor = false;
            this.button_GuiOTP.Click += new System.EventHandler(this.button_GuiOTP_Click);
            // 
            // label_OTP
            // 
            this.label_OTP.AutoSize = true;
            this.label_OTP.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label_OTP.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_OTP.Location = new System.Drawing.Point(271, 279);
            this.label_OTP.Name = "label_OTP";
            this.label_OTP.Size = new System.Drawing.Size(38, 21);
            this.label_OTP.TabIndex = 34;
            this.label_OTP.Text = "OTP";
            // 
            // ffc_QuenMatKhau
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(387, 395);
            this.Controls.Add(this.label_OTP);
            this.Controls.Add(this.button_GuiOTP);
            this.Controls.Add(this.textBox_OTP);
            this.Controls.Add(this.button_SignIn);
            this.Controls.Add(this.label_Username);
            this.Controls.Add(this.panel_Username);
            this.Controls.Add(this.pictureBox_UehLogo);
            this.Name = "ffc_QuenMatKhau";
            this.ShowIcon = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "ffc_QuenMatKhau";
            this.panel_Username.ResumeLayout(false);
            this.panel_Username.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_UehLogo)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button button_SignIn;
        private System.Windows.Forms.Label label_Username;
        private System.Windows.Forms.Panel panel_Username;
        private System.Windows.Forms.TextBox textBox_Username;
        private System.Windows.Forms.Button button_Login1;
        private System.Windows.Forms.PictureBox pictureBox_UehLogo;
        private System.Windows.Forms.TextBox textBox_OTP;
        private System.Windows.Forms.Button button_GuiOTP;
        private System.Windows.Forms.Label label_OTP;
    }
}